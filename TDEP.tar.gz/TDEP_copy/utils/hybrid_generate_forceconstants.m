#!/Applications/Mathematica.app/Contents/MacOS/MathematicaScript -script
<< PLMathematicaUtils`

WriteString[$Output, " \n"];
WriteString[$Output, "Starting Mathematica script to reduce symmetry \n"];


(* Read the control file from Fortran *)
ctrl = Import["mathoutfile.controlfile", "Table"];
npairs=First@ctrl[[1]];
cutoff2=First@ctrl[[2]];
cutoff3=First@ctrl[[3]];
cutoff4=First@ctrl[[4]];
dofirst=First@ctrl[[5]];
magnetic=First@ctrl[[6]];

uc=MakePoscar[Import["infile.ucposcar","Table"]];
ss=MakePoscar[Import["infile.ssposcar","Table"]];

(* The symmetry operations *)
ops = loReadSymmetryOperationsFromFile;

(* Get first order force constants *)
If[dofirst==1,
    WriteString[$Output, "First order force constants \n"];
    sfc = loBuildUniqueSingletForceconstant;
    uk1=loCountUnknown[{0, 0, 0, sfc}];
    WriteString[$Output, " ...          first order generated, unknowns "<> ToString[uk1] <>"\n"];

    sfc = loSingletPointSymmetryUnique[sfc,ops];
    uk1=loCountUnknown[{0, 0, 0, sfc}];
    WriteString[$Output, " ...           space group symmetry, unknowns "<> ToString[uk1] <>"\n"];
];

(* Fix second order stuff *)
If[cutoff2>0,
    WriteString[$Output, "Second order force constants \n"];
    nfc = loBuildUniquePairForceconstant;
    uk2=loCountUnknown[{0, 0, 0, nfc[[2]]}];
    WriteString[$Output, " ...         second order generated, unknowns "<> ToString[uk2] <>"\n"];

    nfc = loPointSymmetryUnique[nfc, ops];
    uk2=loCountUnknown[{0, 0, 0, nfc[[2]]}];
    WriteString[$Output, " ...           space group symmetry, unknowns "<> ToString[uk2] <>"\n"];

    nfc = loTransposeSymmetryUnique[nfc, ops];
    uk2=loCountUnknown[{0, 0, 0, nfc[[2]]}];
    WriteString[$Output, " ...         transposition symmetry, unknowns "<> ToString[uk2] <>"\n"];

    nfc = loUniqueAcousticSumRules[nfc];
    uk2=loCountUnknown[{0, 0, 0, nfc[[2]]}];
    WriteString[$Output, " ...                      sum rules, unknowns "<> ToString[uk2] <>"\n"];
    nfc = Simplify[nfc];

    (* Get the Huang invariances *)
    CA = loHuangInvarianceUnique[nfc, ops];

];

If[cutoff3>0,
    WriteString[$Output, " \n"];
    WriteString[$Output, "Third order force constants \n"];

    ntfc=loBuildUniqueTripletForceconstant;
    uk3=loCountUnknown[{0,0,0,ntfc[[3]]}];
    WriteString[$Output, " ...          third order generated, unknowns "<> ToString[uk3] <>"\n"];

    ntfc=loTripletTransposeSymmetryUnique[ntfc,ops];
    uk3=loCountUnknown[{0,0,0,ntfc[[3]]}];
    WriteString[$Output, " ...         transposition symmetry, unknowns "<> ToString[uk3] <>"\n"];

    ntfc=loTripletPointSymmetryUnique[ntfc,ops];
    uk3=loCountUnknown[{0,0,0,ntfc[[3]]}];
    WriteString[$Output, " ...           space group symmetry, unknowns "<> ToString[uk3] <>"\n"];

    ntfc=loTripletASR[ntfc];
    uk3=loCountUnknown[{0,0,0,ntfc[[3]]}];
    WriteString[$Output, " ...                      sum rules, unknowns "<> ToString[uk3] <>"\n"];
    ntfc = Simplify[ntfc];
    WriteString[$Output, " \n"];
,
    WriteString[$Output, " \n"];
];

If[cutoff4>0,
    WriteString[$Output, " \n"];
    WriteString[$Output, "Fourth order force constants \n"];

    nffc=loBuildUniqueQuartetForceconstant;
    uk4=loCountUnknown[{0,0,0,nffc[[4]]}];
    WriteString[$Output, " ...         fourth order generated, unknowns "<> ToString[uk4] <>"\n"];

    nffc=loQuartetTransposeSymmetryUnique[nffc,ops];
    uk4=loCountUnknown[{0,0,0,nffc[[4]]}];
    WriteString[$Output, " ...         transposition symmetry, unknowns "<> ToString[uk4] <>"\n"];

    nffc=loQuartetPointSymmetryUnique[nffc,ops];
    uk4=loCountUnknown[{0,0,0,nffc[[4]]}];
    WriteString[$Output, " ...           space group symmetry, unknowns "<> ToString[uk4] <>"\n"];
    
    nffc=loQuartetASR[nffc];
    uk4=loCountUnknown[{0,0,0,nffc[[4]]}];
    WriteString[$Output, " ...                      sum rules, unknowns "<> ToString[uk4] <>"\n"];
    nffc = Simplify[nffc];
    WriteString[$Output, " \n"];
,
    WriteString[$Output, " \n"];
];

If[magnetic==1,
    WriteString[$Output, " \n"];
    WriteString[$Output, "Magnetic exchange parameters \n"];
    jij=loBuildUniquePairJij;
    ukm=loCountUnknown[{0,0,0,jij[[2]]}];
    WriteString[$Output, " ...                  Jij generated, unknowns "<> ToString[ukm] <>"\n"];
    jij = loPointSymmetryUnique[jij, ops];
    ukm=loCountUnknown[{0,0,0,jij[[2]]}];
    WriteString[$Output, " ...                    space group, unknowns "<> ToString[ukm] <>"\n"];
];

(* Figured out the symmetry stuff *)

WriteString[$Output, "Mapping the force constants \n"];


If[dofirst==1,
    sing = loBuildStandardSingletFormat[sfc, ops];
    WriteString[$Output, " ...           built unitcell firstorder forceconstant\n"];
    forces1 = loNewFirstOrderGetForceExpression[sfc,ops];
    WriteString[$Output, " ...                       generated firstorder forces\n"];
];

If[cutoff2>0,
    par = loBuildStandardPairFormat[nfc, ops];
    WriteString[$Output, " ...          built unitcell secondorder forceconstant\n"];
    lfc = loBuildLargePairFormat[nfc, ops];
    WriteString[$Output, " ...         built supercell secondorder forceconstant\n"];
    forces2 = loNewSecondOrderGetForceExpression[lfc];
    WriteString[$Output, " ...                      generated secondorder forces\n"];
    (* Maybe the magnetic stuff *)
    If[magnetic==1,
        ljij = loBuildLargePairFormat[jij, ops];
        magneticEnergy=loSecondMagneticEnergyExpression[ljij];
    ];
];

If[cutoff3>0,
    tria = loBuildStandardTripletFormat[ntfc, ops];
    WriteString[$Output, " ...           built unitcell thirdorder forceconstant\n"];
    ltria = loBuildLargeTripletFormat[ntfc, ops];
    WriteString[$Output, " ...          built supercell thirdorder forceconstant\n"];
    forces3 = loNewThirdOrderGetForceExpression[ltria];
    WriteString[$Output, " ...                       generated thirdorder forces\n"];
];

If[cutoff4>0,
    tet = loBuildStandardQuartetFormat[nffc, ops];
    WriteString[$Output, " ...          built unitcell fourthorder forceconstant\n"];
    ltet = loBuildLargeQuartetFormat[nffc, ops];
    WriteString[$Output, " ...         built supercell fourthorder forceconstant\n"];
    forces4 = loNewFourthOrderGetForceExpression[ltet];
    WriteString[$Output, " ...                      generated fourthorder forces\n"];
];


(* Add all forces and forceconstants together *)
forceconstants={};
na=Total[NumberOfElements[ss]];
forces=ConstantArray[0,3*na];

If[dofirst==1,
    forces=Table[forces[[i]]+forces1[[i]],{i,1,3*na}];
    AppendTo[forceconstants,sing[[4]]];
];

If[cutoff2 > 0,
    forces=Table[forces[[i]]+forces2[[i]],{i,1,3*na}];
    AppendTo[forceconstants,par[[4]]];
];
If[cutoff3 > 0,
    forces=Table[forces[[i]]+forces3[[i]],{i,1,3*na}];
    AppendTo[forceconstants,tria[[4]]];
];
If[cutoff4 > 0,
    forces=Table[forces[[i]]+forces4[[i]],{i,1,3*na}];
    AppendTo[forceconstants,tet[[4]]];
];

(* Write code*)
WriteString[$Output, " \n"];
WriteString[$Output, "Writing code \n"];
WriteString[$Output, " \n"];
loNewWriteCoefficients[forceconstants,forces,0];

If[dofirst==1,
    loNewFirstOrderWritePhis[sing,cutoff2, uc];
    ,
    loDumpEmptyFirstorder[];
];

If[cutoff2 > 0,
    loNewSecondOrderWritePhis[par, cutoff2, uc, npairs];
    If[Length[CA]==0,
        loDumpEmptyHuang[];
    ,
        loDumpHuang[CA];
    ];
];
If[cutoff3 > 0,
    loNewThirdOrderWritePhis[tria, cutoff3, uc, 1];
    ,
    loDumpEmptyThirdorder[];
];
If[cutoff4 > 0,
    loNewFourthOrderWritePhis[tet, cutoff4, uc, 1];
    ,
    loDumpEmptyFourthorder[];
];

(* Maybe magnetic stuff *)
If[magnetic==1,
    loWriteMagneticCoefficients[{jij[[2]]}, magneticEnergy];
    parjij = loBuildStandardPairMagFormat[jij, ops];
    loNewSecondOrderWriteMagPhis[parjij, cutoff2, uc, npairs];
,
    loDumpEmptyMagnetism[];
    loDumpEmptySecondorderMag[];
];

(* If it's an alloy expansion, fix it here *)
If[npairs>0,
    (* Expand the force constants into pairs *)
    WriteString[$Output, " \n"];
    WriteString[$Output, "Expanding pair force constants for alloys \n"];
    alloypair = ConstantArray[0, npairs];
    For[i = 1, i <= npairs, i++,
        alloypair[[i]] =  nfc /. loReturnRulesForUnknown[nfc, "al" <> ToString[i] <> "f"];
    ];
    WriteString[$Output, " ...                built unitcell alloy forceconstant\n"];
    alloyLfc=loBuildLargePairFormatAlloyExpansion[alloypair, ops];
    WriteString[$Output, " ...               built supercell alloy forceconstant\n"];
    alloyForces2 = loNewSecondOrderGetForceExpression[alloyLfc]; 
    WriteString[$Output, " ...                            generated alloy forces\n"];
    WriteString[$Output, " \n"];
    WriteString[$Output, "Writing even more code \n"];
    WriteString[$Output, " \n"];    
    loNewWriteCoefficients[alloypair,alloyForces2,npairs];
,
    (*If not an alloy, dump an empty*)
    loDumpEmptyAlloy[];
];

WriteString[$Output, "Done! \n"];

