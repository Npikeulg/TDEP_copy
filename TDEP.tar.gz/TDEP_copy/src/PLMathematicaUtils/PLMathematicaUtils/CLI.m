(* Mathematica package *)


Begin["PLMathematicaUtils`"];

ProcessArgs::usage="args=ProcessArgs[opts, Rest@$ScriptCommandLine]

opts = {
   {\"-a\" | \"--alfa\", \"Set a = <num>\", Function[{x}, a = First@x; Shift[]]},
   {\"-b\" | \"--beta\", \"Set b = 2\", Function[{x}, b = True;]}
   };
";

End[];


ProcessArgs[opts_, argv_] := Module[{match, args},
   args = argv;
   Shift[] := args = Rest@args;
   While[Length[args] > 0 && Or @@ Map[StringMatchQ[args[[1]], #] &, opts[[All, 1]]],
    match = Position[Map[StringMatchQ[args[[1]], #] &, opts[[All, 1]]], True][[1, 1]];
    args = Rest@args;
    opts[[match, 3]][args];
    ];
   args
   ];