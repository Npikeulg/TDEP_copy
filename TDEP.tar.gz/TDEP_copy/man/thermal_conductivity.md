
### Short description

Calculates the lattice thermal conductivity from the iterative solution of the phonon Boltzmann equation. In addition, cumulative plots and raw data dumps of intermediate values are available.

### Command line options:




Optional switches:

* `--readiso`  
    default value .false.  
    Read the isotope distribution from `infile.isotopes`. The format is specified [here](../page/files.html#infile.isotopes).

* `--qpoint_grid value#1 value#2 value#3`, `-qg value#1 value#2 value#3`  
    default value 26 26 26  
    Density of q-point mesh for Brillouin zone integrations.

* `--integrationtype value`, `-it value`, value in: `1,2,3,4`  
    default value 2  
    Type of integration for the phonon DOS. 1 is Gaussian, 2 adaptive Gaussian and 3 Tetrahedron.

* `--sigma value`  
    default value 1.0  
    Global scaling factor for adaptive Gaussian smearing.

* `--threshold value`  
    default value 4.0  
    Consider a Gaussian distribution to be 0 after this many standard deviations.

* `--readqmesh`  
    default value .false.  
    Read the q-point mesh from file. To generate a q-mesh file, see the genkpoints utility.

* `--temperature value`  
    default value -1  
    Evaluate thermal conductivity at a single temperature.

* `--temperature_range value#1 value#2 value#3`  
    default value 100 300 5  
    Series of temperatures for thermal conductivity. Specify min, max and the number of points.

* `--logtempaxis`  
    default value .false.  
    Space the temperature points logarithmically instead of linearly.

* `--tau_boundary value`  
    default value -1  
    Add a constant boundary scattering term to the lifetimes.

* `--max_mfp value`  
    default value -1  
    Add a limit on the mean free path as an approximation of domain size.

* `--dumpgrid`  
    default value .false.  
    Write files with q-vectors, frequencies, eigenvectors and group velocities for a grid.

* `--thinfilm`  
    default value .false.  
    Calculate the suppression of kappa from in a thin film.

* `--noisotope`  
    default value .false.  
    Do not consider isotope scattering.

* `--correctionlevel value`  
    default value 6  
    How agressively things are corrected due to broken symmetries.

* `--scftol value`  
    default value 1E-5  
    What tolerance to converge the self-consistent cycle to.

* `--help`, `-h`  
    Print this help message

* `--version`, `-v`  
    Print version
### Examples

`mpirun thermal_conductivity --temperature 300` 

`mpirun thermal_conductivity -qg 15 15 15 --temperature_range 200 600 50` 

`mpirun thermal_conductivity --integrationtype 2 -qg 30 30 30 --max_mfp 1E-6` 
