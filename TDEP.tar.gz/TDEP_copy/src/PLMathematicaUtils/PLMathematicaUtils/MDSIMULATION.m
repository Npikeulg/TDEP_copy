(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
MDSIMULATION::usage="Represent a MDSimulation, SIMULATION[meta, poscar, stat, positions, forces, magnetic]";
Meta::usage="";
Poscar::usage="";
Positions::usage="";
Forces::usage="";
Magnetic::usage="";
Stat::usage="";
ShowMovie::usage="";
OffsetDirectPositions::usage="";
OffsetDirectPositionsPBC::usage="";
RemovePBC::usage="";
SetPoscar::usage="";

Displacements::usage="Displacements[simulation]"

MakeMDSimulation::usage="";
MakeMDSimulation::filenotfound="Could not find file: `1`"
MakeMDSimulation::inconsistent="Inconsistent meta and ssposcar"
End[];

MDSIMULATION /: Meta[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_]] := meta;
MDSIMULATION /: Poscar[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_]] := poscar;
MDSIMULATION /: Stat[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_]] := stat;
MDSIMULATION /: Positions[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_]] := positions;
MDSIMULATION /: Forces[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_]] := forces;
MDSIMULATION /: Magnetic[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_]] := magnetic;

MDSIMULATION /: 
  Positions[ MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], t_] := positions[[t]];
MDSIMULATION /: 
  Forces[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], t_] := forces[[t]];
MDSIMULATION /: 
  Magnetic[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], t_] := magnetic[[t]];
MDSIMULATION /: 
  Stat[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], "TotalEnergy"] :=
  stat[[All, {2, 3}]];
MDSIMULATION /: 
  Stat[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], "PotentialEnergy"] :=
  stat[[All, {2, 4}]];
MDSIMULATION /: 
  Stat[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], "KineticEnergy"] :=
  stat[[All, {2, 5}]];
MDSIMULATION /: 
  Stat[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], "Temperature"] :=
  stat[[All, {2, 6}]];
MDSIMULATION /: 
  Stat[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], "Pressure"] :=
  stat[[All, {2, 7}]];
MDSIMULATION /: 
  Stat[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], "Stresses"] :=
  {stat[[All,{2, 8}]],stat[[All, {2, 9}]],stat[[All, {2, 10}]],
  	stat[[All, {2, 11}]],stat[[All, {2, 12}]],stat[[All, {2, 13}]]};

MDSIMULATION /: SetPoscar[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], newPoscar_] := 
  MDSIMULATION[meta, newPoscar, stat, positions, forces, magnetic];

MakeMDSimulation[computer_String, dir_String, opts : 
    OptionsPattern[{
    	Options[ImportSSHData],
    	MetaFile->"infile.meta",
    	StatFile->"infile.stat",
    	PoscarFile->"infile.ssposcar",
    	PosFile->"infile.positions",
    	ForceFile->"infile.forces",
    	MagneticFile->"infile.magnetic",
    	Slim->False
    	}]
    	] :=
    Module[{meta,poscar,stat,pos,force,magnetic,getdata},
    	getdata[file_] := Module[{size}, 
    		If[FileExistsQSSH[computer, dir<>"/"<>file,
    			Evaluate@FilterRules[{opts}, Options[ImportSSH]]]
    			,
    			size=ImportSSH[computer,"ls -s1h "<>dir<>"/"<>file, 
    				Evaluate@FilterRules[{opts}, Options[ImportSSH]]][[1,1]];
				PrintTemporary["Kernel: "<>ToString[$KernelID]<> " :: "<>StringSplit[dir,"/"][[-1]]<>"/" <> file <> " size: " <> size];
	
    			ImportSSH[computer,"cat "<>dir<>"/"<>file, 
    				Evaluate@FilterRules[{opts}, Options[ImportSSH]]]
    			,
    			Message[MakeMDSimulation::filenotfound, dir<>"/"<>file];
    			{}
    		]
    	];
    	
    	meta = Check[getdata[OptionValue[MetaFile]],
    		PrintTemporary["Kernel: "<>ToString[$KernelID]<>" :: "<>StringSplit[dir,"/"][[-1]]<> " No metafile, aborting"];
    		Return[{}],{MakeMDSimulation::filenotfound}];
 
    	poscar = Check[getdata[OptionValue[PoscarFile]],Return[{}],{MakeMDSimulation::filenotfound}];
    	stat = Check[Developer`ToPackedArray[getdata[OptionValue[StatFile]],Real],Return[{}],{MakeMDSimulation::filenotfound}];
    	
    	meta = MakeMeta[meta];
    	poscar = MakePoscar[poscar];
    	
    	If[!OptionValue[Slim],
    		pos  = Check[Developer`ToPackedArray[getdata[OptionValue[PosFile]],Real],Return[{}],{MakeMDSimulation::filenotfound}];
    		force = Check[Developer`ToPackedArray[getdata[OptionValue[ForceFile]],Real],Return[{}],{MakeMDSimulation::filenotfound}];
    		magnetic = Quiet[
    			Check[Developer`ToPackedArray[getdata[OptionValue[MagneticFile]],Real],
					PrintTemporary["Kernel: "<>ToString[$KernelID]<>" :: "<>StringSplit[dir,"/"][[-1]]<>" No magnetic file, assuming non-magnetic calulation"];{},
						{MakeMDSimulation::filenotfound}],
    			MakeMDSimulation::filenotfound];
			pos = Partition[pos,NumberOfAtoms[meta]];
			force = Partition[force,NumberOfAtoms[meta]];
			magnetic = Partition[magnetic,NumberOfAtoms[meta]];
    		,
    		pos={};
    		force={};
    		magnetic={};
    	];
	
		If[NumberOfAtoms[meta]!=Total[NumberOfElements[poscar]],
			Message[MakeMDSimulation::inconsistent];
		];
		
    	    	
		MDSIMULATION[meta, poscar, stat, pos, force, magnetic]
	];
 
MDSIMULATION /: ShowMovie[MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_],
	opts:OptionsPattern[{
    	Options[Draw]
   	}]]:=
	Manipulate[ Draw[ SetDirectPositions[ poscar, positions[[i]]],Evaluate@FilterRules[{opts}, Options[Draw]]],
		 {{i,1,"Time Step"},1,Length[positions],1}];
  
MDSIMULATION /: OffsetDirectPositions[ MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_], offset_] :=
		MDSIMULATION[meta, poscar, stat, Map[# + offset &, positions, {2}], forces, magnetic];

MDSIMULATION /: 
  OffsetDirectPositionsPBC[
   MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, 
    magnetic_], offset_] := 
  MDSIMULATION[meta, poscar, stat, 
   Map[Mod[# + offset, 1] &, positions, {2}], forces, magnetic];

MDSIMULATION /: RemovePBC[ MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_],
	opts:OptionsPattern[{StartFromPoscar->False}] ] :=
		MDSIMULATION[meta, poscar, stat, 
			Developer`ToPackedArray[If[OptionValue[StartFromPoscar],
				UndoPBC[Join[{poscar//DirectPositions},positions]][[2;;]],
				UndoPBC[positions]]],
			 forces, magnetic
		];
Options[RemovePBC] = {StartFromPoscar->False}; 
  
MDSIMULATION /: Displacements[  MDSIMULATION[meta_META, poscar_POSCAR, stat_, positions_, forces_, magnetic_] ] :=
    Map[ Map[Function[{r}, LatticeConstant[poscar]*r.Base[poscar]], # - DirectPositions[poscar] ] &
     ,
     Positions[ RemovePBC[MDSIMULATION[meta, poscar, stat, positions, forces, magnetic]  ,StartFromPoscar -> True]]
];

  
  
  
  
  
