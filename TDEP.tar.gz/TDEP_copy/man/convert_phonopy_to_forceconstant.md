
### Short description

Generates a forceconstant file from phonopy data.

### Command line options:




Optional switches:

* `-fc value`  
    default value FORCE_CONSTANTS  
    Specify the filename for the phonopy FORCE_CONSTANTS file.

* `-fb value`  
    default value BORN  
    Specify the filename for the phonopy BORN file.

* `-fuc value`  
    default value infile.ucposcar  
    Specify the filename for unitcell file.

* `-fss value`  
    default value infile.ssposcar  
    Specify the filename for the supercell file.

* `--truncate`  
    default value .false.  
    Truncate the realspace IFCs.

* `--help`, `-h`  
    Print this help message

* `--version`, `-v`  
    Print version
