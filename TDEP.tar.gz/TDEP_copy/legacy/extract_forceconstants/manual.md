author: Olle Hellman
display: none
graph: none
{!man/extract_forceconstants.md!}

### Longer summary

The program will read [infile.ucposcar](../page/files.html#infile.ucposcar)

### Maybe some plots?

Have a plot or two.
