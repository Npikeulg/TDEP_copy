#!/software/apps/python/3.4.1/snic-1/bin/python3

from network import Landscape

pel = Landscape()
pel.build_net()

pel.plot_degreedist(method='gp')
