(* Mathematica package *)


Begin["PLMathematicaUtils`"];

TextureTransformFunction3D::usage="{texdata, tf, stats} = TextureTransformFunction3D[texdata], Dim[texdata]={nx,ny,nz}"  
TextureZoomTransformFunction3D::usage="{zoomtexdata, tf, stats}= TextureTransformFunction3D[texdata, range], Dim[texdata]={nx,ny,nz}, range should be within [0,1] i.e. {{0.3,0.4},{0.3,0.4},{0.3,0.4}}"  
TextureZoomInterpolateTransformFunction3D::usage="{interpolzoomtexdata, tf, stats} = TextureTransformFunction3D[texdata, range, mag], Dim[texdata]={nx,ny,nz}, range should be within [0,1] and mag an integer larger then 1 i.e. {2,2,2}"  
DrawTexture3D::usage="DrawTexture3D[texdata, tf, Base->{{3.0,0,0},{0,3.0,0},{0,0,5.0}}, ImageSize->300]"

End[];


TextureTransformFunction3D[texdata_] := Module[{nx, ny, nz,f},
  nx = Dimensions[texdata][[1]];
  ny = Dimensions[texdata][[2]];
  nz = Dimensions[texdata][[3]];
  (*Transform to texture coordinates*)
  
  f=AffineTransform[N[{{{0, 0, 1}, {0, -1, 0}, {1, 0, 0}}, {0 + 1/(nz*2), 1 - 1/(2*ny), 0 + 1/(2*nx)}}]];
  
  {Developer`ToPackedArray[texdata],f,{{nx, ny, nz, nx*ny*nz}}}
  ]

TextureZoomTransformFunction3D[texdata_, range_] := 
 Module[{nx, ny, nz, nxz, nyz, nzz, tr, h, f, texzoom},
  nx = Dimensions[texdata][[1]];
  ny = Dimensions[texdata][[2]];
  nz = Dimensions[texdata][[3]];
  
  tr = {
    {Floor[range[[1, 1]]*nx] + 1, Ceiling[range[[1, 2]]*nx]},
    {Floor[range[[2, 1]]*ny] + 1, Ceiling[range[[2, 2]]*ny]},
    {Floor[range[[3, 1]]*nz] + 1, Ceiling[range[[3, 2]]*nz]}};
  
  texzoom = 
   Developer`ToPackedArray[texdata[[tr[[1, 1]] ;; tr[[1, 2]], tr[[2, 1]] ;; tr[[2, 2]], 
    tr[[3, 1]] ;; tr[[3, 2]]]]];
  nxz = Dimensions[texzoom][[1]];
  nyz = Dimensions[texzoom][[2]];
  nzz = Dimensions[texzoom][[3]];
  
  h = AffineTransform[N[{{
       {nx/nxz, 0, 0},
       {0, ny/nyz, 0},
       {0, 0, nz/nzz}},
      {-nx/nxz*range[[1, 1]],
       -ny/nyz*range[[2, 1]],
       -nz/nzz*range[[3, 1]]}
      }]];
  
  f = AffineTransform[
    N[{{{0, 0, 1}, {0, -1, 0}, {1, 0, 0}}, {0 + 1/(nzz*2), 
       1 - 1/(2*nyz), 0 + 1/(2*nxz)}}]];
  
  {texzoom, f[h[#]] &, {{nx, ny, nz, nx*ny*nz}, {nxz, nyz, nzz, nxz*nyz*nzz}, tr}}
  ]

TextureZoomInterpolateTransformFunction3D[texdata_, range_, mag_, 
  opts : OptionsPattern[{Options[ListInterpolation]}]
  ] := Module[{nx, ny, nz, nxz, nyz, nzz, tr, h, f, texzoom, ip},
  nx = Dimensions[texdata][[1]];
  ny = Dimensions[texdata][[2]];
  nz = Dimensions[texdata][[3]];
  
  tr = {
    {Floor[range[[1, 1]]*nx] + 1, Ceiling[range[[1, 2]]*nx]},
    {Floor[range[[2, 1]]*ny] + 1, Ceiling[range[[2, 2]]*ny]},
    {Floor[range[[3, 1]]*nz] + 1, Ceiling[range[[3, 2]]*nz]}};
  
  tr={
  	If[tr[[1,2]]-tr[[1,1]]<=1,
  	{Max[tr[[1,1]]-1,1],Min[tr[[1,2]]+1,nx]},
  	tr[[1]]],
  	If[tr[[2,2]]-tr[[2,1]]<=1,
  	{Max[tr[[2,1]]-1,1],Min[tr[[2,2]]+1,ny]},
  	tr[[2]]],
  	If[tr[[3,2]]-tr[[3,1]]<=1,
  	{Max[tr[[3,1]]-1,1],Min[tr[[3,2]]+1,nz]},
  	tr[[nz]]]
  	};
  	  
  texzoom = 
   texdata[[tr[[1, 1]] ;; tr[[1, 2]], tr[[2, 1]] ;; tr[[2, 2]], 
    tr[[3, 1]] ;; tr[[3, 2]]]];
  
  ip = ListInterpolation[texzoom, 
    Evaluate@FilterRules[{opts}, Options[ListInterpolation]]];
  SetSharedFunction[ip];
  SetSharedVariable[texzoom];
  texzoom = Developer`ToPackedArray[ParallelTable[ip[x, y, z],
    {x, 1, Dimensions[texzoom][[1]], 1.0/mag[[1]]},
    {y, 1, Dimensions[texzoom][[2]], 1.0/mag[[2]]},
    {z, 1, Dimensions[texzoom][[3]], 1.0/mag[[3]]}]];
  
  nxz = Dimensions[texzoom][[1]];
  nyz = Dimensions[texzoom][[2]];
  nzz = Dimensions[texzoom][[3]];
  
  h = AffineTransform[N[{{
       {nx*mag[[1]]/nxz, 0, 0},
       {0, ny*mag[[2]]/nyz, 0},
       {0, 0, nz*mag[[3]]/nzz}},
      {-nx*mag[[1]]/nxz*range[[1, 1]],
       -ny*mag[[2]]/nyz*range[[2, 1]],
       -nz*mag[[3]]/nzz*range[[3, 1]]}
      }]];
  
  f = AffineTransform[
    N[{{{0, 0, 1}, {0, -1, 0}, {1, 0, 0}}, {0 + 1/(nzz*2), 
       1 - 1/(2*nyz), 0 + 1/(2*nxz)}}]];
  
  {texzoom, 
   f[h[#]] &, {{nx, ny, nz, nx*ny*nz}, {nxz, nyz, nzz, nxz*nyz*nzz},tr}}
  ]
  
  DrawTexture3D[texdata_, tf_,
  	opts : OptionsPattern[{
  		Options[Graphics3D],
  		Base->{{1.0,0,0},{0,1.0,0},{0,0,1.0}}
  		}]] := Manipulate[
  Graphics3D[
   {Texture[texdata],
    Opacity[Dynamic[o]],
    Dynamic[
     Polygon[#.OptionValue[Base], VertexTextureCoordinates -> Map[tf, #]] & /@ {
       {{x, 0, 0}, {x, 1, 0}, {x, 1, 1}, {x, 0, 1}},
       {{0, y, 0}, {1, y, 0}, {1, y, 1}, {0, y, 1}},
       {{0, 0, z}, {1, 0, z}, {1, 1, z}, {0, 1, z}}
       }
     ]
    },Evaluate@FilterRules[{opts}, Options[Graphics3D]], RotationAction -> "Clip", 
   Lighting -> "Neutral"], {{x, 0.426,"x"}, 0, 1}, {{y, 0.408,"y"}, 0, 
   1}, {{z, 0.256,"z"}, 0, 1}, {{o, 0.95, "opacity"}, 0, 1}]
   
   