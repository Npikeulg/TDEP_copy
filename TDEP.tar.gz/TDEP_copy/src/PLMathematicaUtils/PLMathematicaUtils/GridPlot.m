(* Mathematica package *)


Begin["PLMathematicaUtils`"];

GridPlot::usage="GridPlot[plots, {width, height},{{left margin, right margin},{bottom margin, top margin}, in between margin}, options]
Draw a grid of plots
Example:
	GridPlot[Table[ListPlot[Table[Sin[i*x + j], {x, 0, 10, 0.1}], PlotRangePadding -> {3.0, 0.3}],
   			{i, 1, 3}, {j, 1, 3}], {600, 400}, {{30, 4}, {30, 4}, 0}]
Parameters information
	plots:  a 2-D grid of plots
	width:  the total width, or a list of column widths
	height: the total height, of a list of row heights
	options: any graphics option, passed on to all plots.   		
"; 		
 
  		

End[];



Options[GridPlot] = {
   Options[Graphics]};

GridPlot[plots_, {xtot_, ytot_}, {{ml_, mr_}, {mb_, mt_}, mp_: 0}, 
  opts : OptionsPattern[{Options[Graphics]}]] := 
 Module[{px, py, plotSizeX, plotSizeY, sizes, posTR, i, j, xtotl, 
   ytotl}, {py, px} = Dimensions[plots];
  xtotl = If[Head[xtot] === List, Total[xtot], xtot];
  ytotl = If[Head[ytot] === List, Total[ytot], ytot];
  
  plotSizeX = 
   Table[Round[(xtotl - (ml + mr) - (px - 1)*mp)*
      If[Head[xtot] === List, xtot[[i]]/xtotl, 1/px]], {i, 1, px}];
  plotSizeY = 
   Table[Round[(ytotl - (mt + mb) - (py - 1)*mp)*
      If[Head[ytot] === List, ytot[[i]]/ytotl, 1/py]], {i, 1, py}];
  
  
  sizes = 
   Table[{plotSizeX[[j]] + If[j == 1, ml, mp] + If[j == px, mr, mp], 
     plotSizeY[[i]] + If[i == 1, mt, mp] + If[i == py, mb, mp]}, {i, 
     1, py}, {j, 1, px}];
  posTR = {Accumulate[sizes[[1, All, 1]]], 
    Accumulate[Reverse@sizes[[All, 1, 2]]]};
  
  Graphics[Table[
    Inset[Show[plots[[i, j]],
      ImageSize -> sizes[[i, j]],
      ImageMargins -> 0.0,
      PlotRangeClipping -> True,
      AspectRatio -> plotSizeY[[i]]/plotSizeX[[j]],
      ImagePadding -> (If[
   			OptionValue[ImagePadding] === All, 
   				{{If[j == 1, ml, mp], If[j == px, mr, mp]}, {If[i == py, mb, mp], If[i == 1, mt, mp]}},
    			OptionValue[ImagePadding]]),
      Evaluate@FilterRules[{opts}, Options[Graphics]]
      ], {posTR[[1, j]], posTR[[2, py + 1 - i]]}, {Right, Top}, 
     sizes[[i, j]]],
    {i, 1, py}, {j, 1, px}],
   ImageSize -> {posTR[[1, -1]], posTR[[2, -1]]},
   AspectRatio -> posTR[[2, -1]]/posTR[[1, -1]],
   PlotRange -> {{0, posTR[[1, -1]]}, {0, posTR[[2, -1]]}}, 
   ImagePadding -> {{0, 0}, {0, 0}}]];
 