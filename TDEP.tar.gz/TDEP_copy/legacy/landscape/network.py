#!/software/apps/python/3.4.1/snic-1/bin/python3

import scipy
import queue
import sys
import pylab
import subprocess
import pickle
from progress import Progress
from pdb import set_trace

class Node:
  """A node/vertex in a network.
  Connected to all nodes in the set self.neighbours
  """

  def __init__(self,name):
    self.neighbours = set()
    self.name = name
    self.parent = None
    self.depth = 0
    self.leaf = False
    self.root = False

  def __repr__(self):
    return repr(self.name)

  def __hash__(self):
    return hash(self.__repr__())

  def __eq__(self,other):
    if isinstance(other,Node):
      return self.name == other.name
    else:
      return False

  def __ne__(self,other):
    return (not self.__eq__(other))

  def add_neighbour(self,neighbour):
    """Add a neighbouring node"""
    self.neighbours.add(neighbour)

  def rem_neighbour(self,neighbour):
    """Remove a neighbouring node"""
    self.neighbours.remove(neighbour)

  def degree(self):
    """Compute the degree (number of neighbours)"""
    return len(self.neighbours)

class Structure(Node):
  """An inherent structure on the PEL. Contains extra information: energy,
  fingerprint.
  """

  def __init__(self,name,energy,fingerprint):
    super(Structure,self).__init__(name)
    self.energy = energy
    self.fp = fingerprint
    self.nat = len(self.fp)

  def fp_compare(self,other):
    """Compare fingerprints of two structures. Difference is defined as:
    fp_diff = |fp1 - fp2|/sqrt(natoms)
    """
    diff = self.fp - other.fp
    return (1./scipy.sqrt(self.nat))*scipy.sqrt(scipy.dot(diff,diff))

class Edge:
  """An edge in a network, connecting two nodes.
  Betweenness is defined as the number of geodesics passing through
  an edge.
  """

  def __init__(self,node1,node2):
    self.e = set()
    self.e.add(node1)
    self.e.add(node2)
    self.between = 0
    if node1==node2:  # An edge must connect two unique nodes
      raise Exception('node1 == node2!')

  def __repr__(self):
    l = list(self.e)
    return "Edge({0},{1})".format(*sorted(l))

  def __hash__(self):
    return hash(self.__repr__())

  def __eq__(self,other):
    if isinstance(other,Edge):
      return self.e == other.e
    else:
      return False

  def __ne__(self,other):
    return (not self.__eq__(other))

class Network:
  """A complex network, comprised of nodes/vertices connected by edges"""

  def __init__(self):
    self.n_nodes = 0
    self.n_edges = 0
    self.nodes = {}
    self.edges = {}

  def add_node(self,name):
    """Add an unconnected node to the network"""
    self.n_nodes=self.n_nodes+1
    self.nodes[name] = Node(name)

  def add_edge(self,node1,node2):
    """Add an edge connecting two nodes to the network"""
    if not node1 == node2:
      self.nodes[node1].add_neighbour(node2)
      self.nodes[node2].add_neighbour(node1)
      e = Edge(node1,node2)
      if not e in self.edges:
        self.edges[repr(e)] = e
        self.n_edges += 1

  def rem_edge(self,node1,node2):
    """Remove an edge from the network"""
    if not node1 == node2:
      self.n_edges -= 1
      self.nodes[node1].rem_neighbour(node2)
      self.nodes[node2].rem_neighbour(node1)
      e = Edge(node1,node2)
      del self.edges[repr(e)]

  def get_adj_mat(self):
    """Compute the adjacency matrix A. A_{ij} = 1 if nodes i and j are
    neighbours, otherwise A_{ij} = 0.
    """
    self.adj_mat = scipy.zeros((self.n_nodes,self.n_nodes))
    for i,node in enumerate(self.nodes):
      for j in node.neighbours:
        self.adj_mat[i,j] = 1
        self.adj_mat[j,i] = 1

  def get_max_degree(self):
    """Find the degree of the most connected node in the network
    """
    return max([node.degree() for node in self.nodes.values()])

  def get_degree_dist(self):
    """Compute the degree distribution
    """
    max_degree = self.get_max_degree()
    degrees = scipy.array([node.degree() for node in self.nodes.values()])
    b = scipy.arange(0,max_degree+1)
    hist,bin_edges = scipy.histogram(degrees,bins=b)
    return (hist,bin_edges)

  def plot_degreedist(self,fname="ddist",method="gp"):
    """plot the degree distribution and try fitting a function
    """
    hist,bin_edges = self.get_degree_dist()

    nbins = scipy.size(hist)
    bin_centres = scipy.zeros(nbins)
    i = 0
    while i < nbins:
      bin_centres[i] = (bin_edges[i] + bin_edges[i+1])/2.
      i += 1

    if method == "mpl":
      pylab.plot(bin_centres, hist)
      pylab.xlabel('Degree',size=18)
      pylab.ylabel('Frequency',size=18)
      pylab.savefig(fname+".eps",bbox_inches='tight')
    elif method == "gp":
      with open(fname+".gp", "w") as f:
        f.write("set term postscript enhanced eps color font 'Helvetica,18'\n")
        f.write("set output '{}.eps'\n".format(fname))
        f.write("set xlabel 'Frequency'\n")
        f.write("set ylabel 'Degree'\n")
        f.write("set xrange [1:]\n")
        f.write("set yrange [1:]\n")
        f.write("set logscale xy\n")
        f.write("p '-' w p pt 6 ps 1 not\n")
        for i,degree in enumerate(hist):
          f.write("{0:<8.3f}{1:<8d}\n".format(bin_centres[i],degree))

  def bfs(self,startnode):
    """Perform a breadth-first search (BFS) starting from startnode.
    This generates geodesics to all other connected nodes, in the
    form of a tree, stored in the network using the node.parent,
    node.leaf and node.root attributes.
    """
    q = queue.Queue()
    q.put(startnode)
    self.nodes[startnode].root = True
    visited = set()
    visited.add(startnode)
    while True:
      if q.empty():
        break
      else:
        current = q.get()
        for neighbour in self.nodes[current].neighbours:
          nchildren = 0
          if not neighbour in visited:
            nchildren += 1
            q.put(neighbour)
            self.nodes[neighbour].parent = current
            self.nodes[neighbour].depth = self.nodes[current].depth + 1
            visited.add(neighbour)
        if nchildren == 0:
          self.nodes[current].leaf = True

  def add_betweenness(self):
    """Add the betweenness calculated from a bfs search. Uses betweenness values
    stored on nodes, which are zeroed in between searches.
    """
    for key in self.nodes:
      self.nodes[key].between = 0

    q = queue.Queue()
    nleaves = 0
    for key in self.nodes:
      if self.nodes[key].leaf:
        nleaves += 1
        q.put(key)
        self.nodes[key].between = 1

    while True:
      if q.empty:
        break
      else:
        key = q.get()
        print(key)
        q.put(self.nodes[key].parent)
        self.nodes[parent].between += self.nodes[key].between

    for key in self.nodes:
      if not self.nodes[key].root:
        e = Edge(key,self.nodes[key].parent)
        self.edges[repr(e)].between += self.nodes[key].between

  def calc_betweenness(self):
    print("Calculating betweenness")
    pbar = Progress(self.n_nodes,otype='abs',disptext="Reading file")
    i = 0
    for key in self.nodes:
      self.bfs(key)
      self.add_betweenness()
      i += 1
      pbar.update(i)

  def dfs(self,startnode):
    """Perform a depth-first search (DFS) starting from startnode.
    Save results in the form of a tree.
    """
    stack = []
    stack.append(startnode)
    visited = set()
    while stack:
      current = stack.pop()
      if not current in visited:
        visited.add(current)
        for n in self.nodes[current].neighbours:
          stack.append(n)

  def get_betw_mat(self):
    """Save the betweenness in the form of a n_node x n_node matrix
    """
    self.betw_mat = scipy.zeros((self.n_nodes,self.n_nodes),dtype=int)
    for key in self.edges:
      node1 = self.edges[key].e[0]
      node2 = self.edges[key].e[1]
      self.betw_mat[node1,node2] = edge.between

# Load/save NOT correctly implemented yet!!
  def save_net(self,fname="adj_mat.p"):
    """Save an instance of the adjacency matrix to file fname
    """
    with open(fname,'wb') as outfile:
      pickle.dump(self.adj_mat, outfile)

  def load_net(self,fname="network.p"):
    """Load an adjacency matrix saved in file fname, reconstruct the network.
    """
    with open(fname,'rb') as infile:
      self.adj_mat = pickle.load(infile)

class Landscape(Network):
  """The network defining the potential energy landscape (PEL). Any point
  in the PEL is mapped to a local minimum by performing a geometry
  optimization. A local minimum (inherent structure) is a node on this 
  network. A transition pathway between two minima is an edge.
  """

  def __init__(self,fp_thresh=0.01):
    super(Landscape,self).__init__()
    self.fp_thresh = fp_thresh

  def add_node(self,name,energy,fingerprint,fromnode):
    """Add a structure to the PEL. Use the fingerprint to determine whether
    the structure is unique. Add a transition pathway to fromnode.
    """
    if self.n_nodes == 0:
      first = True
    else:
      first = False

    newstruc = Structure(name,energy,fingerprint)
    unique = True
    for node in self.nodes:
      fp_diff = self.nodes[node].fp_compare(newstruc)
      if fp_diff < self.fp_thresh:
        unique = False
        tonode = node
#        self.add_edge(tonode,fromnode)
        break
    if unique == True:
      self.nodes[newstruc.name] = newstruc
      if not first:
        tonode = newstruc.name
      else:
        tonode = 0
      self.n_nodes = self.n_nodes+1
    if not first:
      self.add_edge(tonode,fromnode)
    return tonode

  def build_net(self,fpfile="fp.dat"):
    """Map a PEL to a network.
    Use list of fingerprints generated from Monte Carlo or molecular dynamics
    simulation (one line per fp) in fp.dat. A transition is implied between
    subsequent fingerprints (e.g. an edge should be added between fingerprints
    1 and 2, 2 and 3, 3 and 4 etc.
    """
    # count lines in fingerprint file
    cmd = "wc -l {}".format(fpfile)
    proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
    proc.wait()
    nlines = int(proc.stdout.read().strip().split()[0])

    pbar = Progress(nlines,otype='abs',disptext="Reading {}".format(fpfile))
    fp_arr = []
    i = 1
    with open('fp.dat', 'r') as infile:
      for line in infile:
        arr = scipy.fromstring(line.strip(),sep=' ')
        fp_arr.append(arr)
        pbar.update(i)
        i += 1

    fromnode = 0
    pbar2 = Progress(nlines,otype='abs',disptext="Building network")
    i = 1
    for j,fp in enumerate(fp_arr):
      fromnode = self.add_node(j,1.,fp,fromnode)
      pbar2.update(i)
      i += 1

if __name__ == '__main__':
  """Test code
  """
  pel = Landscape()
  pel.build_net()

  pel.plot_degreedist(method='gp')
