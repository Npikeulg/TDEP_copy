import sys

class Progress:
  """Display the progress of a loop in stdout
  """

  def __init__(self,nloops,**kwparams):
    """Mandatory argument: nloops = total number of loops
    Optional arguments:
    otype     = output type (bar or absolute),
    barlength = length of progress bar (characters)
    disptext  = text to display by progress bar
    """
    self.nloops = nloops
    if 'otype' in kwparams:
      self.otype = kwparams['otype']
    else:
      self.otype = 'bar'

    if 'barlength' in kwparams:
      self.b = kwparams['barlength']
    else:
      self.b = 10

    if 'disptext' in kwparams:
      self.dtext = kwparams['disptext']
    else:
      self.dtext = "Progress"

  def get_progress(self,current):
    """Get loop progress as a float between 0.0 and 1.0
    """
    return 1.-float(self.nloops - current)/float(self.nloops)

  def update(self,loopno):
    """Update the progress according to the otype
    """
    if not isinstance(loopno,int):
      print("Error: loopno must be an int\r\n")
      sys.exit(0)
    if self.otype == 'bar':
      self.update_bar(loopno)
    elif self.otype == 'abs':
      self.update_abs(loopno)
    else:
      print("Invalid otype")
      sys.exit(0)

  def update_bar(self,loopno):
    """Print progress to stdout as a progress bar and percentage
    """
    progress = self.get_progress(loopno)
    status = ""
    if progress < 0.:
      progress = 0
      status = "Halt.\r\n"
    if progress >= 1.:
      progress = 1.
      status = "Done.\r\n"
    completion = int(round(self.b*progress))
    text = "\r{0}: [{1}] {2:3.0f}% {3}".format(self.dtext, "#"*completion \
            + "-"*(self.b-completion), progress*100, status)
    sys.stdout.write(text)
    sys.stdout.flush()

  def update_abs(self,loopno):
    """Get loop progress as an absolute value and percentage
    """
    status = "..."
    if not isinstance(loopno,int):
      loopno = 0
      status = "Error: loopno must be an int\r\n"
    if loopno < 0:
      loopno = 0
      status = "Halt.\r\n"
    if loopno >= self.nloops:
      loopno = self.nloops
      status = "... Done.\r\n"
    pc = self.get_progress(loopno)*100.
    text = "\r{0}: loop {1} of {2} ({3:3.0f}%)".format(self.dtext, loopno,
                                                    self.nloops, pc, status)
    sys.stdout.write(text)
    sys.stdout.flush()
