(* ::Package:: *)

(* Mathematica package *)


(* META *) 

Begin["PLMathematicaUtils`"];

META::usage="META[...] represent a simulation meta data";

MakeMeta::usage="MakeMETA[data]";

NumberOfAtoms::usage="";
NumberOfTimeSteps::usage="";
TimeStep::usage="";
Smearing::usage="";
Sigma::usage="";
Temperature::usage="";

SetNumberOfAtoms::usage="";
SetNumberOfTimeSteps::usage="";
SetTimeStep::usage="";
SetSmearing::usage="";
SetSigma::usage="";
SetTemperature::usage="";


End[];

MakeMeta[data_] := Module[{},
   META[data[[1, 1]], data[[2, 1]], data[[3, 1]], data[[4, 1]], data[[5, 1]], 
    data[[6, 1]]]
   ];
   
META /: NumberOfAtoms[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_]] := atoms;
META /: NumberOfTimeSteps[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_]] := ionsteps;
META /: TimeStep[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_]] := timestep;
META /: Smearing[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_]] := smearing;
META /: Sigma[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_]] := sigma;
META /: Temperature[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_]] := temp;


META /: SetNumberOfAtoms[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_], newAtoms_] :=
META[newAtoms, ionsteps, timestep, temp, smearing, sigma];
META /: SetNumberOfTimeSteps[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_], newIonsteps_] :=
  META[atoms, newIonsteps, timestep, temp, smearing, sigma];
META /: SetTimeStep[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_], newTimestep_] := 
  META[atoms, ionsteps, newTimestep, temp, smearing, sigma];
META /: SetSmearing[ META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_], newSmearing_] :=
  META[atoms, ionsteps, timestep, temp, newSmearing, sigma];
META /: SetSigma[META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_], newSigma_] :=
  META[atoms, ionsteps, timestep, temp, smearing, newSigma];
META /: SetTemperature[META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_], newTemp_] :=
  META[atoms, ionsteps, timestep, newTemp, smearing, sigma];

META /: MakeBoxes[
  META[atoms_, ionsteps_, timestep_, temp_, smearing_, sigma_], form_] := 
 If[! NumberQ[atoms],
  RowBox[{"META", "[", 
    RowBox[{MakeBoxes[atoms, form], ",", MakeBoxes[ionsteps, form], ",", 
      MakeBoxes[timestep, form], ",", MakeBoxes[temp, form], ",", 
      MakeBoxes[smearing, form], ",", MakeBoxes[sigma, form]}], "]"}],
  InterpretationBox[
   FrameBox[GridBox[{
      {StyleBox["META", 14], ""},
      {StyleBox["Atoms", 12], atoms},
      {StyleBox["Ion Time steps", 12], ionsteps},
      {StyleBox["Time step", 12], timestep},
      {StyleBox["Temperature", 12], temp},
      {StyleBox["Smering", 12], smearing},
      {StyleBox["Sigma", 12], sigma}
      }, ColumnLines -> True, ColumnAlignments -> Left, 
     RowLines -> {True, False, False, False, False, False}]]
   ,
   META[atoms, ionsteps, timestep, temp, smearing, sigma],
   Editable -> False
   ]];
