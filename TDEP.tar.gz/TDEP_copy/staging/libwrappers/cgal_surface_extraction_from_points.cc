#include <iostream>
#include <array>

#include <CGAL/Scale_space_surface_reconstruction_3.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/IO/read_off_points.h>

typedef CGAL::Exact_predicates_inexact_constructions_kernel     Kernel;
typedef CGAL::Scale_space_surface_reconstruction_3< Kernel >    Reconstruction;

typedef Reconstruction::Point                                   Point;
typedef std::vector< Point >                                    Point_collection;
typedef Reconstruction::Triple_const_iterator                   Triple_iterator;
typedef Reconstruction::Triple                                  Triple;

extern "C"{
    // Extract a surface from a set of oriented points 
    void lo_cgaldum_surface_extraction_from_points(const int &np, const double *r, 
                                                   int &shellind,int &ntri, int *&triangles){
        //
        std::cout << "Entering c++ " << std::endl;
        // stuff the points into something
        Point_collection points;
        int l=0;
        for(int j=0;j<np;j++){
            points.push_back( Point(r[l+0],r[l+1],r[l+2]) );
            l+=3;
        }
        std::cout << "Added points " << std::endl;
        std::cerr << "done: " << points.size() << " points." << std::endl;

        // Construct the mesh in a scale space.
        Reconstruction reconstruct( 40, 200 );
        reconstruct.reconstruct_surface( points.begin(), points.end(), 8 );
        std::cerr << "Reconstruction done:" << std::endl;
        // advance it
        reconstruct.increase_scale( 10 );

        //
        std::cout << "Number of triangles:" << reconstruct.number_of_triangles() << std::endl;
        std::cout << "Number of shells:" << reconstruct.number_of_shells() << std::endl;

        // Since I don't understand c++, this is how I get the actual number out of the object
        Triple trip;
        // tell them what shell I care about
//        std::size_t shell=0;
//        shell=shell+shellind;
        // some place to store the triangles
        triangles = new int[reconstruct.number_of_triangles()*3];

        l=-1;
        ntri=0;
        for( Triple_iterator it = reconstruct.surface_begin(); it != reconstruct.surface_end(); ++it ){
            ntri++;
            trip=*it;
            for(int j=0; j<3; j++){
                l++;
                triangles[l]=trip[j]+1;
            }
        }
        std::cout << "I found:" << ntri << " triangles" << std::endl;
    

////        // Write the reconstruction.
////        std::cerr << "Neighborhood radius^2 = " << reconstruct.neighborhood_squared_radius() << std::endl;
//        unsigned ll;
//        for( std::size_t shell = 0; shell < reconstruct.number_of_shells(); ++shell ) {
//            std::cerr << "Shell " << shell << std::endl;
//            for( Triple_iterator it = reconstruct.shell_begin( shell ); it != reconstruct.shell_end( shell ); ++it ){
//                trip=*it;
//                ll=trip[0];
//                //ll=Triple::get<0>(it);
//                std::cout << trip << std::endl; // We write a '3' in front so that it can be assembled into an OFF file
//                }
//        }
//
      //  std::cerr << "Done." << std::endl;
      //  return EXIT_SUCCESS;

    }
}

