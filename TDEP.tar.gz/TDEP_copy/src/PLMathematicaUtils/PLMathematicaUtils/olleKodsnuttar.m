(* ::Package:: *)

Begin["PLMathematicaUtils`"];
coeffCodeTemplate0::usage=""
coeffCodeTemplate1::usage=""
coeffCodeTemplate2::usage=""
magCoeffCodeTemplate0::usage=""
magCoeffCodeTemplate1::usage=""
magCoeffCodeTemplate2::usage=""
alloyCoeffCodeTemplate0::usage=""
alloyCoeffCodeTemplate1::usage=""
alloyCoeffCodeTemplate2::usage=""
FirstPhiCodeTemplate0::usage=""
FirstPhiCodeTemplate1::usage=""
FirstPhiCodeTemplate2::usage=""
SecondPhiCodeTemplate0::usage=""
SecondPhiCodeTemplate1::usage=""
SecondPhiCodeTemplate2::usage=""
ThirdPhiCodeTemplate0::usage=""
ThirdPhiCodeTemplate1::usage=""
ThirdPhiCodeTemplate2::usage=""
FourthPhiCodeTemplate0::usage=""
FourthPhiCodeTemplate1::usage=""
FourthPhiCodeTemplate2::usage=""
HuangCodeTemplate0::usage=""
HuangCodeTemplate1::usage=""
HuangCodeTemplate2::usage=""
End[];

(* Fortran code snippets to be used later *)

coeffCodeTemplate0 = "module coeff_force
    use constants
    
    <USE>
    
    contains
    
    subroutine force_coefficients_from_u(C,u)
    real(flyt),intent(in),dimension(:,:)::u
    real(flyt),intent(inout),dimension(:,:)::C
    
    <CALLSUBS>
    
    end subroutine
  end module
  ";

coeffCodeTemplate1 = "module coeff_force<NUM>
    use constants
    contains
    
    subroutine force_coefficients_from_u<NUM>(C,u)
    real(flyt),intent(in),dimension(:,:)::u
    real(flyt),intent(out),dimension(:,:)::C
    real(flyt) :: x,y
    y=1.0_flyt  

  ";

coeffCodeTemplate2 = "
      end subroutine
  end module
  ";

magCoeffCodeTemplate0 = "module mag_coeff_force
    use constants
    
    <USE>
    
    contains

    function do_magnetic_stuff() result(magstuff)
        logical :: magstuff
        magstuff=.true.
    end function
    
    subroutine magnetic_coefficients_from_u(C,u)
    real(flyt),intent(in),dimension(:,:)::u
    real(flyt),intent(inout),dimension(:)::C
    
    <CALLSUBS>
    
    end subroutine
  end module
  ";

magCoeffCodeTemplate1 = "module mag_coeff_force<NUM>
    use constants
    contains
    
    subroutine magnetic_coefficients_from_u<NUM>(C,u)
    real(flyt),intent(in),dimension(:,:)::u
    real(flyt),intent(out),dimension(:)::C
    real(flyt) :: x

  ";

magCoeffCodeTemplate2 = "
      end subroutine
  end module
  ";

alloyCoeffCodeTemplate0 = "module alloy_coeff_force
    use constants
    
    <USE>
    
    contains
    
    subroutine alloy_force_coefficients_from_u(C,u)
    real(flyt),intent(in),dimension(:,:)::u
    real(flyt),intent(inout),dimension(:,:)::C
    
    C=0.0_flyt
    <CALLSUBS>
    
    end subroutine
  end module
  ";

alloyCoeffCodeTemplate1 = "module alloy_coeff_force<NUM>
    use constants
    contains
    
    subroutine alloy_force_coefficients_from_u<NUM>(C,u)
    real(flyt),intent(in),dimension(:,:)::u
    real(flyt),intent(out),dimension(:,:)::C
    real(flyt) :: x,y
    y=1.0_flyt  

  ";

alloyCoeffCodeTemplate2 = "
      end subroutine
  end module
  ";

FirstPhiCodeTemplate0 = "module first_remap_forceconstant
    use constants
    use helpers
    use type_forceconstant_firstorder
    
    <USE>
    
    implicit none
    save
    contains
    
    subroutine get_firstforceconstant_uniques(phis)
        integer,intent(out) :: phis
        phis=<PHIS>
    end subroutine

    subroutine get_firstforceconstant_from_phi(phi,fc)
    type(lo_forceconstant_firstorder),intent(inout)::fc
    real(flyt),dimension(:),intent(in)::phi
    !
    integer::na_uc
    !
    fc%na=<NUC>
    allocate(fc%atom(fc%na))
    
    <CALLSUBS>
    
    end subroutine
  end module
  ";

FirstPhiCodeTemplate1 = "module first_remap_forceconstant<NUM>
    use constants
    use helpers
    use type_forceconstant_firstorder
    implicit none
    save
    contains
      
    subroutine get_firstforceconstant_from_phi<NUM>(phi,fc)
    type(lo_forceconstant_firstorder),intent(inout)::fc
    real(flyt),dimension(:),intent(in)::phi
    !
  ";

FirstPhiCodeTemplate2 = "  
    end subroutine
  end module
  ";

SecondPhiCodeTemplate0 = "module second_remap_forceconstant
    use constants
    use helpers
    use type_forceconstant_secondorder
    
    <USE>
    
    implicit none
    save
    contains
    
    subroutine get_secondforceconstant_uniques(phis)
        integer,intent(out) :: phis
        phis=<PHIS>
    end subroutine

    subroutine is_it_alloy_expansion(alloyexpansion,npairs)
        logical, intent(out) :: alloyexpansion
        integer, intent(out) :: npairs
        !
        npairs=<NPAIRS>
        if ( npairs .gt. 0 ) then
            alloyexpansion=.true.
        else
            alloyexpansion=.false.
        endif
    end subroutine
    
    subroutine get_secondforceconstant_from_phi(phi,fc)
    type(lo_forceconstant_secondorder),intent(inout)::fc
    real(flyt),dimension(:),intent(in)::phi
    !
    integer::na_uc
    !
    fc%cutoff=<CUTOFF>_flyt
    fc%na=<NUC>
    allocate(fc%atom(fc%na))
    
    <CALLSUBS>
    
    end subroutine
  end module
  ";

SecondPhiCodeTemplate1 = "module second_remap_forceconstant<NUM>
    use constants
    use helpers
    use type_forceconstant_secondorder
    implicit none
    save
    contains
      
    subroutine get_secondforceconstant_from_phi<NUM>(phi,fc)
    type(lo_forceconstant_secondorder),intent(inout)::fc
    real(flyt),dimension(:),intent(in)::phi
    !
  ";

SecondPhiCodeTemplate2 = "  
    end subroutine
  end module
  ";

SecondPhiMagCodeTemplate0 = "module second_mag_remap_forceconstant
    use constants
    use helpers
    use type_forceconstant_secondorder
    
    <USE>
    
    implicit none
    save
    contains
    
    subroutine get_secondforceconstant_mag_uniques(phis)
        integer,intent(out) :: phis
        phis=<PHIS>
    end subroutine
    
    subroutine get_secondforceconstant_mag_from_phi(phi,fc)
    type(lo_forceconstant_secondorder),intent(inout)::fc
    real(flyt),dimension(:),intent(in)::phi
    !
    integer::na_uc
    !
    fc%cutoff=<CUTOFF>_flyt
    fc%na=<NUC>
    allocate(fc%atom(fc%na))
    
    <CALLSUBS>
    
    end subroutine
  end module
  ";

SecondPhiMagCodeTemplate1 = "module second_remap_forceconstant_mag<NUM>
    use constants
    use helpers
    use type_forceconstant_secondorder
    implicit none
    save
    contains
      
    subroutine get_secondforceconstant_mag_from_phi<NUM>(phi,fc)
    type(lo_forceconstant_secondorder),intent(inout)::fc
    real(flyt),dimension(:),intent(in)::phi
    !
  ";

SecondPhiMagCodeTemplate2 = "  
    end subroutine
  end module
  ";

ThirdPhiCodeTemplate0 = "module third_remap_forceconstant
      use constants
      use helpers
      use type_forceconstant_thirdorder
      
      <USE>
      
      implicit none
      save
      contains
      
      subroutine get_thirdforceconstant_uniques(phis)
      integer,intent(out) :: phis
      phis=<PHIS>
      end subroutine
      
      subroutine get_thirdforceconstant_from_phi(phi,fc)
      type(lo_forceconstant_thirdorder),intent(inout)::fc
      real(flyt),dimension(:),intent(in)::phi
      !
      integer::na_uc
      !
      fc%cutoff=<CUTOFF>_flyt
      fc%na=<NUC>
      allocate(fc%atom(fc%na))
      
      <CALLSUBS>
      
      end subroutine
    end module
    ";

ThirdPhiCodeTemplate1 = "module third_remap_forceconstant<NUM>
    use constants
    use helpers
    use type_forceconstant_thirdorder
    implicit none
    save
    contains
      
    subroutine get_thirdforceconstant_from_phi<NUM>(phi,fc)
    type(lo_forceconstant_thirdorder),intent(inout)::fc
    real(flyt),dimension(:),intent(in)::phi
    !
  ";

ThirdPhiCodeTemplate2 = "
      end subroutine
  end module
  ";


FourthPhiCodeTemplate0 = "module fourth_remap_forceconstant
      use constants
      use helpers
      use type_forceconstant_fourthorder
      
      <USE>
      
      implicit none
      save
      contains
      
      subroutine get_fourthforceconstant_uniques(phis)
      integer,intent(out) :: phis
      phis=<PHIS>
      end subroutine
      
      subroutine get_fourthforceconstant_from_phi(phi,fc)
      type(lo_forceconstant_fourthorder),intent(inout)::fc
      real(flyt),dimension(:),intent(in)::phi
      !
      integer::na_uc
      !
      fc%cutoff=<CUTOFF>_flyt
      fc%na=<NUC>
      allocate(fc%atom(fc%na))
      
      <CALLSUBS>
      
      end subroutine
    end module
    ";

FourthPhiCodeTemplate1 = "module fourth_remap_forceconstant<NUM>
    use constants
    use helpers
    use type_forceconstant_fourthorder
    implicit none
    save
    contains
      
    subroutine get_fourthforceconstant_from_phi<NUM>(phi,fc)
    type(lo_forceconstant_fourthorder),intent(inout)::fc
    real(flyt),dimension(:),intent(in)::phi
    !
  ";

FourthPhiCodeTemplate2 = "
      end subroutine
  end module
  ";

HuangCodeTemplate0 = "module huang_invariance
      use constants
      
      <USE>
      
      implicit none
      contains

      subroutine huang_invariance_nonzeros(n)
         integer, intent(out) :: n
         n=<COUNTER>
      end subroutine
      
      subroutine get_huang_invariance_matrix(C)
      real(flyt), intent(out), dimension(:,:) :: C
      C=0.0_flyt 
      <CALLSUBS>
      
      end subroutine
    end module
    ";

HuangCodeTemplate1 = "module huang_invariance_<NUM>
    use constants
    implicit none
    contains
      
    subroutine get_huanginvariance<NUM>(C)
    real(flyt), dimension(:,:), intent(inout) :: C
    !
  ";

HuangCodeTemplate2 = "
      end subroutine
  end module
  ";
