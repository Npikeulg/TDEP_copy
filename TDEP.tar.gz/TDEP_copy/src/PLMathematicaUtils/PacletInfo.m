(* Paclet Info File *)

(* created 2011.02.07*)

Paclet[
  Name -> "PLMathematicaUtils",
  Version -> "0.0.1",
  MathematicaVersion -> "6+",
  Extensions -> {
    {"Documentation", Language -> "English"}
}]