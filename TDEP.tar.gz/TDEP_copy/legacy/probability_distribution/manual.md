author: Olle Hellman
display: none
graph: none
{!man/probability_distribution.md!}

### Longer summary

To visualize how atoms are distributed around their ideal positions we calculate the probability density distribution. It is a direct and convenient way to get a feeling for how a system evolves during a simulation. The distribution of atoms is given in a histogram. 

We start by expressing all atomic positions \(\mathbf{r}_i(t)\) in cartesian coordinates.  The coordinates of each position are multiplied with the inverse basis of a unitcell, so new coordinates share the basis vectors of the unitcell. The user can specify the file storing the unit cell, but by default we use the program will read infile.ucposcar. We use a modulus of "1" along each axis to get all the coordinates in one unitcell. We divide the volume of the unit cell into small bins \(n\) on a grid and increment the tally for each bin for each atom it contains. This procedure is repeated for all timesteps. Once this is done for all time steps we get the probability, \(P(n)\), to find an atom in the nth bin. In determining \(P(n)\ for all n bins, we have obtained a probalitiy density distribution of atoms. 


####Input files
* [infile.ucposcar](../page/files.html#infile.ucposcar)
* [infile.ucposcar](../page/files.html#infile.ssposcar)
* [infile.positions](../page/files.html#infile.positions)
* [infile.meta](../page/files.html#infile.meta)



###Output files
 
* outfile.probdens_xy
* outfile.probdens_xz
* outfile.probdens_yz
* outfile.probdens_projections.gnuplot
* outfile.probdens.element_1
* outfile.probdens.element_2
* outfile.probdens_inviwo_element_1.raw
* outfile.probdens_inviwo_element_1.dat
* outfile.probdens_inviwo_element_2.raw
* outfile.probdens_inviwo_element_2.dat
* outfile.probdens_inviwo.raw
* outfile.probdens_inviwo.dat

This is an example of output files for PbS. 

We go into details of each file.

#### outfile.probdens_xy, outfile.probdens_xz, outfile.probdens_yz

This is 2D projected density on xy,xz,yz planes. The first and the second colomns are the {x,y}, {x,z}, {yz} fractional coordinates respectively. The third column is the projected probability. These output files contain information on all atoms given in the unit cell.

```
   1.2500000000000001E-002   1.2500000000000001E-002   0.19560000000000002
   1.2500000000000002E-002   3.7499999999999999E-002   1.2000000000000001E-003
   1.2499999999999997E-002   6.2500000000000014E-002   0.0000000000000000
        ...						  ...		               ...
		...						  ...		               ...
		...						  ...		               ...
   
```
#### outfile.probdens.element_1, outfile.probdens.element_2
These files contain the positions of all the atoms in fractional coordinates

#### outfile.probdens_inviwo_element_1.dat and outfile.probdens_inviwo_element_1.raw

These files contain information in inviwo format that could be used to plot a 3D probability distribution.





@todo Add fancy figure with projections and 3D plot from inviwo; also in outfile.probdens.S the fourth colomn is always zero, which is bin write(u,*) real(v2),bin(i,j,k,ii). Also add a link to inviwo maybe? 
