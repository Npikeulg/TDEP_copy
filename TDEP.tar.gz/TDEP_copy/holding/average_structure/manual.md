author: Olle Hellman
display: none
graph: none
propnamelink: <a href="../program/eosfit.html">eosfit</a>
propname: EOSfit
{!man/eosfit.md!}

### Longer summary

Nothing special about this, just a small tool to conveniently fit various equations of state to volume-energy data. I will add more analytical forms as soon as I find any practical use for them.

# Birch-Murnaghan

Starting with the substitution

$$
x = \frac{1}{V^{2/3}}
$$

we write the energy as a function of volume as

$$
E = A_0 + A_1 x + A_2 x^2 + A_3 x^3
$$

The coefficients of the polynomial can be used to express more familiar quantities:

$$
\begin{align}
  V_0 & = \frac{1}{A_1^{3/2}}
  \sqrt{
    -4A_2^2 + 9A_1A_2A_3 \pm \sqrt{(A_2^2-3A_1A_3)(4A_2^2-3A_1A_3)}
  } \\
  E_0 & = A_0+ \frac{A_1}{V_0^{2/3}}
  +\frac{A_2}{V_0^{4/3}}+\frac{A_3}{V_0^2} \\
  B_0  & = \frac{10A_1}{9V_0^{5/3}} + \frac{28 A_2}{9 V_0^{7/3}} + \frac{6 A_3}{V_0^3} \\
  B_0' & = \frac{
        243 A_3 + 98 A_2 V_0^{2/3} + 25 A_1 V_0^{4/3}
      }{
        81 A_3 + 42 A_2 V_0^{2/3} + 15 A_1 V_0^{4/3}
      }
\end{align}
$$

These are the equilibrium volume, energy, bulk modulus and logarithmic derivative of the bulk modulus. The polynomial coefficients can be obtained via the inverse relationship:

$$
\begin{align}
A_0 & = E_0 + \frac{54B_0V_0-9B_0B_0'V_0}{16} \\
A_1 & = \frac{9}{16} \frac{ B_0 (3B_0'-16) }{ V_0^{3/5}} \\
A_2 & = -\frac{9}{16} \frac{B_0(3B_0'-14)}{V_0^{3/7}}  \\
A_3 & = \frac{9}{16} \left( B_0 B_0' V_0^3 -4B_0 V_0^3 \right)
\end{align}
$$

The reason I chose this formulation is that given a set of volumes and energies, you can apply the coordinate transformation from $V$ to $x$ and the problem is transformed into fitting a polynomial, as opposed to the nonlinear problem you would get by trying to fit $V-E$ relationships directly.

In this formulation the pressure is given by

$$
P = -\frac{dE}{dV} =  \frac{2A_1}{3V^{5/3}} + \frac{4A_2}{3V^{7/3}} + \frac{2A_3}{V^3}
$$

and bulk modulus by

$$
B = -V\frac{dP}{dV} = \frac{10A_1}{9V^{5/3}} + \frac{28A_2}{9V^{7/3}} + \frac{6A_3}{V^3}
$$

# Birch-Murnaghan in two dimensions

Sometimes you have to minimize the energy in more than one dimension. I generalized the Birch-Murnaghan equation of state to include a shape-parameter $\eta$:

$$
E = A_0 + A_1 x + A_2 x^2 + A_3 x^3 + B_1 \eta +B_2 x \eta + B_3 \eta^2 + B_4 \eta^2 x + B_5 \eta x^2
$$

Here I use $\eta$ to represent a shape parameter, usually the $c/a$ ratio. As above, I used the substitution $x=V^{-2/3}$ to make the problem easier to fit numerically.

This formulation has some advantages. At constant volume (constant $x$), 
