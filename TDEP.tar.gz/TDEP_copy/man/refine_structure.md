
### Short description

Small utility to ensure that the input structure satisfies all symmetries to high precision.

### Command line options:




Optional switches:

* `--tolerance value`, `-t value`  
    default value 1E-5  
    Tolerance for the initial symmetry check. Try making it looser if you do not get the desired symmetry.

* `--unitcell value`, `-uc value`  
    default value infile.ucposcar  
    Filename for the unitcell to refine.

* `--supercell value`, `-ss value`  
    default value none  
    Filename for supercell to refine.

* `--prototype value`, `-pf value`  
    default value none  
    Prototype unitcell where you know the symmetry is correct.

* `--help`, `-h`  
    Print this help message

* `--version`, `-v`  
    Print version
### Examples

`refine_structure` 
