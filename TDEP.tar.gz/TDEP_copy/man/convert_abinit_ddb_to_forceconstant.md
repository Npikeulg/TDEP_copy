
### Short description

Generates a forceconstant file from abinit DDB files.

### Command line options:




Optional switches:

* `--qpoint_grid value#1 value#2 value#3`, `-qg value#1 value#2 value#3`  
    default value -1 -1 -1  
    Phonon q-point mesh used in Abinit.

* `--files value#1 [value#2...]`, `-f value#1 [value#2...]`  
    DDB filename.

* `--truncate`  
    default value .false.  
    Truncate the realspace IFCs.

* `--help`, `-h`  
    Print this help message

* `--version`, `-v`  
    Print version
