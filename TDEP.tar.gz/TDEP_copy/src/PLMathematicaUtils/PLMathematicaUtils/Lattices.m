(* Mathematica package *)

PLData["Lattices"] := {
   {1, "Cubic P", "sc"  ,
    Symbol["a"]*{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}
    },
   {2, "Cubic F", "fcc",
    (Symbol["a"]/2) {{0, 1, 1}, {1, 0, 1}, {1, 1, 0}}
    },
   {3, "Cubic I", "bcc",
    (Symbol["a"]/2) {{1, 1, 1}, {-1, 1, 1}, {-1, -1, 1}}
    },
   {4, "Hexagonal and Trigonal P", "",
    Symbol["a"] {{1, 0, 0}, {-1/2, Sqrt[3]/2, 0}, {0, 0, Symbol["c"]/Symbol["a"]}}
    },
   {5, "Trigonal R", "",
    Symbol["a"] {{Sqrt[1 - Cos[\[Alpha]]]/Sqrt[
       2], -(Sqrt[1 - Cos[\[Alpha]]]/Sqrt[6]), Sqrt[
       1 + 2 Cos[\[Alpha]]]/Sqrt[3]}, {0, 
       Sqrt[2/3] Sqrt[1 - Cos[\[Alpha]]], Sqrt[1 + 2 Cos[\[Alpha]]]/
       Sqrt[3]}, {-(Sqrt[1 - Cos[\[Alpha]]]/Sqrt[2]), -(Sqrt[
        1 - Cos[\[Alpha]]]/Sqrt[6]), Sqrt[1 + 2 Cos[\[Alpha]]]/Sqrt[
       3]}}
    },
   {6, "Tetragonal P", "st",
    Symbol["a"] {{1, 0, 0}, {0, 1, 0}, {0, 0, Symbol["c"]/Symbol["a"]}}
    },
   {7, "Tetragonal I", "bct",
    (Symbol["a"]/2) {{1, -1, Symbol["c"]/Symbol["a"]}, {1, 1, Symbol["c"]/Symbol["a"]}, {-1, -1, Symbol["c"]/Symbol["a"]}}
    },
   {8, "Orthorhombic P", "",
    {{Symbol["a"], 0, 0} {0, Symbol["b"], 0}, {0, 0, Symbol["c"]}}
    },
   {9, "Orthorhombic base-centered", "bco",
    {{Symbol["a"]/2, Symbol["b"]/2, 0}, {-Symbol["a"]/2, Symbol["b"]/2, 0}, {0, 0, Symbol["c"]}}
    },
   {10, "Orthorhombic face-centered", "",
    {{Symbol["a"]/2, 0, Symbol["c"]/2}, {Symbol["a"]/2, Symbol["b"]/2, 0}, {0, Symbol["b"]/2, Symbol["c"]/2}}
    },
   {11, "Orthorhombic body-centered", "",
    {{Symbol["a"]/2, Symbol["b"]/2, Symbol["c"]/2}, {-Symbol["a"]/2, Symbol["b"]/2, Symbol["c"]/2}, {-Symbol["a"]/2, -Symbol["b"]/2, Symbol["c"]/2}}
    },
   {12, "Monoclinic P", "",
    {{Symbol["a"], 0, 0}, {Symbol["b"]*Cos[Symbol["\[Gamma]"]], Symbol["b"]*Sin[Symbol["\[Gamma]"]], 0}, {0, 0, Symbol["b"]}}
    },
   {13, "Monoclinic base-centered", "",
    {{Symbol["a"]/2, 0, -Symbol["c"]/2}, {Symbol["b"]*Cos[Symbol["\[Gamma]"]], Symbol["b"]*Sin[Symbol["\[Gamma]"]], 0}, {Symbol["a"]/2, 0, Symbol["c"]/2}}
    },
   {14, "Triclinic", "",
    {{Symbol["a"], 0, 0}, {Symbol["b"]*Cos[Symbol["\[Gamma]"]], Symbol["b"]*Sin[Symbol["\[Gamma]"]], 
      0}, {Symbol["c"]*Cos[Symbol["\[Beta]"]], 
      Symbol["c"]*(Cos[Symbol["\[Alpha]"]] - Cos[Symbol["\[Beta]"]] Cos[Symbol["\[Gamma]"]])/Sin[Symbol["\[Gamma]"]], 
      Symbol["c"]*Sqrt[1 + 2*Cos[Symbol["\[Alpha]"]] Cos[Symbol["\[Beta]"]] Cos[Symbol["\[Gamma]"]] - 
          Cos[Symbol["\[Alpha]"]]^2 - Cos[Symbol["\[Beta]"]]^2 - Cos[Symbol["\[Gamma]"]]^2]/
        Sin[Symbol["\[Gamma]"]]}}
    }
   };