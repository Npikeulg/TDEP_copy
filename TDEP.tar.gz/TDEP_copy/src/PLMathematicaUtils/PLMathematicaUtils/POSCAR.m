(* Mathematica package *)

(* POSCAR *)
Begin["PLMathematicaUtils`"];

POSCAR::usage="POSCAR[...] represent a structure

Definition:
POSCAR[Name
 Lattice const,
 Base,
 Elements, 
 Number of elements,
 Positions in diret cooridnates,
 Velocities,
 Selectiv dynamics
]

Example:
POSCAR[\"TiN primitiv\",
 4.2542,
 {
  {0., 1./2, 1./2},
  {1./2, 0., 1./2},
  {1./2, 1./2, 0.}
 }, 
 {\"Ti\", \"N\"},
 {1, 1},
 {
  {0., 0., 0.},
  {0.5, 0.5, 0.5}
 },
 {
  {0, 0, 0},
  {0, 0, 0}
 },
 {}
]

";

Name::usage="Return name";
Base::usage="Return base";
LatticeConstant::usage="Return lattice constant";
Elements::usage="Return elements";
NumberOfElements::usage="Return Number of elements";
DirectPositions::usage="DirectPositions[poscar]: Return positions in direct coordinates
DirectPositions[poscar, i]: Return position i in direct coordinates";
Velocities::usage="Velocities[poscar] return all velocities
Velocities[poscar, i]: return velocity i";
Positions::usage="Positions[poscar]: Return positions
Positions[poscar, i]: Return position i";
CellVolume::usage="Return the cell volume";

SetName::usage="SetName[poscar, name] set a new name";
SetBase::usage="SetBase[poscar, base] set a new base";
SetLatticeConstant::usage="SetLatticeConstant[poscar, latticeconstant] set a new lattice constant";
SetElements::usage="SetElements[poscar, elements] set new list of elements";
SetNumberOfElements::usage="SetNumberOfElements[poscar, numberofelements] set new list of number of elements";
SetDirectPositions::usage="SetDirectPositions[poscar, positions] set a new list of positions in direct coordinates";
SetVelocities::usage="SetVelocities[poscar, velocities] set a new list of velocities";
SetPositions::usage="SetPositions[poscar, positions] set a new list of positions";

MakePoscar::usage="MakePoscar[data], Where data is a table imported vasp poscar
Example:
MakePoscar[Import[POSCAR,\"Table\"]]
";
MakePoscar::dynflags = "Error: Parsing the dynflags";
MakePoscar::positions = "Error: Problem parsing positions";
MakePoscar::noindata = "Error: Problem parsing the data";

Draw::usage="Draw[poscar, options] draw the structure
Example:
Draw[poscar]

Options:
  Indices -> False, 
  UnitCell -> True, 
  Radius -> {}, 
  Colors -> {}, 
  UnitCellRadius -> 0.1,
  UnitCellColor -> White,
  Magnetic -> {}, 
  MagneticDirection -> {0, 0, 1}, 
  MagneticScale -> 0.5
  Any Graphics3D option 
";

DrawInteractive::usage="DrawInteractive[poscar, options] Draw the structure with selectable atoms
Example:
DrawInteractive[poscar]

Options: 
  Indices -> False, 
  UnitCell -> True, 
  Radius -> {},
  Colors -> {}, 
  UnitCellRadius -> 0.1,
  UnitCellColor -> White,
  Magnetic -> {},
  MagneticDirection->{0, 0, 1},
  MagneticScale->0.5,
  Selected->{}
  ClickedFunction->Function[{index,position},1]
  Any Graphics3D option 
";


Replicate::usage="Replicate[poscar,{nx,ny,nz} Replicate structure in x y z direction";
WriteToString::usage="WriteToString[POSCAR, Format->{20,16}, Printvelocites->False]"

End[];

POSCAR /: Name[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := name;
POSCAR /: Base[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := bas;
POSCAR /: LatticeConstant[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := a;
POSCAR /: Elements[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := elem;
POSCAR /: Elements[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], i_] := 
	Module[{list = Rest[FoldList[Plus, 0, nelem]]},
 		Which@@Flatten@Table[{i <= list[[k]], elem[[k]]}, {k, 1, Length[elem]}]
 	];
POSCAR /: NumberOfElements[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := nelem;
POSCAR /: DirectPositions[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := pos;
POSCAR /: DirectPositions[n_][ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := pos[[n]];
POSCAR /: DirectPositions[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_],n_] := pos[[n]];
POSCAR /: Velocities[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := vel;
POSCAR /: Velocities[n_][ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := vel[[n]];
POSCAR /: Velocities[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_],n_] := vel[[n]];
POSCAR /: Positions[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := a*pos.bas;
POSCAR /: Positions[n_][ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_]] := a*pos[[n]].bas;
POSCAR /: Positions[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_],n_] := a*pos[[n]].bas;

POSCAR /: CellVolume[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_] ]:=
	Dot[bas[[1]], Cross[bas[[2]], bas[[3]]]]*a^3

POSCAR /: SetName[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], 
   newName_] := POSCAR[newName, a, bas, elem, nelem, pos, vel, dyn];
POSCAR /: SetBase[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], newBas_] :=
  POSCAR[name, a, newBas, elem, nelem, pos, vel, dyn];
POSCAR /: SetLatticeConstant[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], newA_] := 
POSCAR[name, If[newA<0,(Abs[newA]/Dot[bas[[1]], Cross[bas[[2]], bas[[3]]]])^(1/3),newA], bas, elem, nelem, pos, vel, dyn];
POSCAR /: SetElements[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], newElem_] := 
POSCAR[name, a, bas, newElem, nelem, pos, vel, dyn];
POSCAR /: SetNumberOfElements[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_],  newNelem_] := 
  POSCAR[name, a, bas, elem, newNelem, pos, vel, dyn];
POSCAR /: SetDirectPositions[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], newPos_] :=
  POSCAR[name, a, bas, elem, nelem, newPos, vel, dyn];
POSCAR /: SetDirectPositions[n_][ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], newPos_] := 
	Module[{},
   	pos[[n]] = newPos;
   	POSCAR[name, a, bas, elem, nelem, pos, vel, dyn]
   	];
POSCAR /: SetVelocities[ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], newVel_] :=
  POSCAR[name, a, bas, elem, nelem, pos, newVel, dyn];
POSCAR /: SetVelocities[n_][ POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], newVel_] := 
	Module[{},
   	vel[[n]] = newVel;
   	POSCAR[name, a, bas, elem, nelem, pos, vel, dyn]
   	];

MakePoscar[datain_, opts : OptionsPattern[{VASP4->False}] ] := 
  Module[{data,name, a, bas, elem, nelem, pos, vel, dyn, type, start},
  	data = datain;
   If[Length[data] < 9,
    Message[MakePoscar::noindata];
    Return["Error: No data"];
    ];
   If[OptionValue[VASP4], data = Insert[data,Table["XX",{Length[data[[6]]]}],6] ]; 
   name = data[[1, 1]];
   a = data[[2, 1]];
   bas = data[[{3, 4, 5}]];
   elem = data[[6]];
   nelem = data[[7]];
   type = StringTake[data[[8, 1]], 1];
   start = 0;
   If[a < 0,
    a = (Abs[a]/Dot[bas[[1]], Cross[bas[[2]], bas[[3]]]])^(1/3);
    ];
   If[type == "s" || type == "S",
    type = StringTake[data[[9]], 1];
    start = 10;
    If[Dimensions[data[[start ;; start + Total[nelem] - 1]]][[2]] == 6,
     dyn = data[[start ;; start + Total[nelem] - 1, {4, 5, 6}]],
     Message[MakePoscar::dynflags];
     ];
    ,
    dyn = {};
    start = 9;
    ];
   If[Dimensions[data][[1]] >= start + Total[nelem] - 1,
    pos = data[[start ;; start + Total[nelem] - 1, {1, 2, 3}]],
    Message[MakePoscar::positions];
    ];
   If[type != "d" && type != "D",
    pos = pos.Inverse[bas]
    ];
   start = start + Total[nelem] + 1;
   If[Dimensions[data][[1]] >= start + Total[nelem] - 1,
    vel = data[[start ;; start + Total[nelem] - 1, {1, 2, 3}]],
    vel = Table[{0, 0, 0}, {Total[nelem]}];
    ];
   pos = Developer`ToPackedArray[pos];
   vel = Developer`ToPackedArray[vel];
   POSCAR[name, a, bas, elem, nelem, pos, vel, dyn]
   ];

POSCAR /: 
 MakeBoxes[POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], 
  form_] := If[! NumberQ[a],
  RowBox[{"POSCAR", "[", 
    RowBox[{MakeBoxes[name, form], ",", MakeBoxes[a, form], ",", 
      MakeBoxes[bas, form], ",", MakeBoxes[elem, form], ",", 
      MakeBoxes[nelem, form], ",", MakeBoxes[pos, form], ",", 
      MakeBoxes[vel, form], ",", MakeBoxes[dyn, form]}], "]"}],
  InterpretationBox[
   FrameBox[GridBox[{
      {StyleBox["POSCAR", 14], ""},
      {StyleBox["Name", 12], name},
      {StyleBox["Lattice Constant", 12], a},
      {StyleBox["Elements", 12], RowBox[elem]},
      {StyleBox["Number of Elements", 12], RowBox[nelem]}
      }, ColumnLines -> True, ColumnAlignments -> Left, 
     RowLines -> {True, False, False, False, False}]]
   ,
   POSCAR[name, a, bas, elem, nelem, pos, vel, dyn],
   Editable -> False
   ]
   ];

POSCAR /: 
  Draw[POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], 
   opts : OptionsPattern[{
   	Lighting->"Neutral",
   	Boxed->False,
   	SetOptions[Graphics3D, Lighting -> "Neutral"],
   	Indices -> False, 
  	UnitCell -> True, 
  	Radius -> {}, 
  	Colors -> {}, 
  	UnitCellRadius -> 0.1,
  	UnitCellColor -> White,
  	Magnetic -> {}, 
  	MagneticDirection -> {0, 0, 1}, 
  	MagneticScale -> 0.5 
    }]] :=
  Module[{typelist, TypeFromIndex, DrawAtom, colors, rad, corners, 
    box, xyzCorners, DrawMag},
   typelist = Rest@FoldList[Plus, 0, nelem];
   TypeFromIndex[i_] := 
    Which @@ 
     Flatten@Table[{i <= typelist[[k]], k}, {k, 1, 
        Length[typelist]}];
   
	If[OptionValue[Colors] == {}, 
  		colors = ElementData[#, "IconColor"] & /@ elem, 
  		colors = OptionValue[Colors]
  	];
	If[OptionValue[Radius] == {}, 
  		rad = ((If[Head[#] === Real, #, 150]) &[ElementData[#, "AtomicRadius"]]/1000*4) & /@ elem, 
  		rad = OptionValue[Radius]
  	];
   
   corners = Tuples[{0, 1}, 3];
   box = {{1, 2}, {1, 3}, {1, 5}, {2, 4}, {2, 6}, {3, 4}, {3, 7}, {4, 
      8}, {5, 6}, {5, 7}, {6, 8}, {7, 8}};
   xyzCorners = a*#.bas & /@ corners;
   
   DrawAtom[apos_, index_] := {
     colors[[TypeFromIndex[First@index]]],
     Sphere[a*apos.bas, rad[[TypeFromIndex[First@index]]]]
   };
     
   DrawMag[mpos_, magnitude_] := {
  	 If[magnitude > 0, Green, Red], 
   	 Arrowheads[If[Abs@magnitude > 1, 0.04, 0.04*Abs[magnitude]]],
     Arrow[Tube[{a*mpos.bas - magnitude*OptionValue[MagneticDirection]*OptionValue[MagneticScale]*0.4, 
      a*mpos.bas + magnitude*OptionValue[MagneticDirection]*OptionValue[MagneticScale]*0.6}]]
   };
   
   Graphics3D[
    {
     MapIndexed[DrawAtom, pos],
    If[OptionValue[UnitCell],
     	{OptionValue[UnitCellColor],
      {EdgeForm[],
      	Cylinder[{xyzCorners[[#[[1]]]], xyzCorners[[#[[2]]]]}, 
         OptionValue[UnitCellRadius]] & /@ box},
         Sphere[#,OptionValue[UnitCellRadius]]&/@xyzCorners
         },
      {}],
     If[OptionValue[Indices],
      MapIndexed[
       Text[Framed[Style[First@#2, 12], FrameMargins -> 2, 
          Background -> LightGreen], a*#1.bas] &, pos],
      {}],
      If[OptionValue[Magnetic]!={},
     	MapIndexed[
       		DrawMag[#1,OptionValue[Magnetic][[First@#2]]]&,pos
       	],
      {}]
      
     },
    Evaluate@FilterRules[{opts}, Options[Graphics3D]]
    ]
   ];

Options[Draw]={
   	Lighting->"Neutral",
   	Boxed->False,
   	SetOptions[Graphics3D, Lighting -> "Neutral"],
   	Indices -> False, 
  	UnitCell -> True, 
  	Radius -> {}, 
  	Colors -> {}, 
  	UnitCellRadius -> 0.1,
  	UnitCellColor -> White,
  	Magnetic -> {}, 
  	MagneticDirection -> {0, 0, 1}, 
  	MagneticScale -> 0.5 
    };


POSCAR /: 
  DrawInteractive[POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], 
   opts : OptionsPattern[{
   	Options[Graphics3D], 
   	Indices -> False, 
    UnitCell -> True, 
    Radius -> {},
    Colors -> {}, 
    UnitCellRadius -> 0.1,
    UnitCellColor -> White,
    Magnetic -> {},
    MagneticDirection->{0, 0, 1},
    MagneticScale->0.5,
    Selected->{},
    ClickedFunction->Function[{index,position},1]
    }]] :=
  
  Module[{typelist, TypeFromIndex, DrawAtom, colors, rad, corners, 
    box, xyzCorners, DrawMag, selected},
   typelist = Rest@FoldList[Plus, 0, nelem];
   TypeFromIndex[i_] := 
    Which @@ 
     Flatten@Table[{i <= typelist[[k]], k}, {k, 1, 
        Length[typelist]}];
   
	If[OptionValue[Colors] == {}, 
  		colors = ElementData[#, "IconColor"] & /@ elem, 
  		colors = OptionValue[Colors]
  	];
	If[OptionValue[Radius] == {}, 
  		rad = ((If[Head[#] === Real, #, 150]) &[ElementData[#, "AtomicRadius"]]/1000*4) & /@ elem, 
  		rad = OptionValue[Radius]
  	];
   
   corners = Tuples[{0, 1}, 3];
   box = {{1, 2}, {1, 3}, {1, 5}, {2, 4}, {2, 6}, {3, 4}, {3, 7}, {4, 
      8}, {5, 6}, {5, 7}, {6, 8}, {7, 8}};
   xyzCorners = a*#.bas & /@ corners;
   
   selected = OptionValue[Selected];
   
   DrawAtom[apos_, index_] := Module[{col1 = colors[[TypeFromIndex[First@index]]], col2=Red, 
   									 label = If[MemberQ[selected, index], ToString[index], ""],
   									 color = If[MemberQ[selected, index], Red,colors[[TypeFromIndex[First@index]]]]},
   	EventHandler[{
     Dynamic[color],
     Sphere[a*apos.bas, rad[[TypeFromIndex[First@index]]]],
     Dynamic[Text[Style[label, 16, FontColor -> Black], a*apos.bas]]
   	},
   	{"MouseClicked" :> (
   		label = If[label == "", 
   			AppendTo[selected, First@index];
   			color=col2;
   			ToString[First@index]
   			, 
    		selected = DeleteCases[selected, First@index];
    		color=col1;
    		 ""];
    	OptionValue[ClickedFunction][First@index,a*apos.bas];
   )}, PassEventsDown -> True 	]
   ];
     
   DrawMag[mpos_, magnitude_] := {
  	 If[magnitude > 0, Green, Red], 
   	 Arrowheads[If[Abs@magnitude > 1, 0.04, 0.04*Abs[magnitude]]],
     Arrow[Tube[{a*mpos.bas - magnitude*OptionValue[MagneticDirection]*OptionValue[MagneticScale]*0.4, 
      a*mpos.bas + magnitude*OptionValue[MagneticDirection]*OptionValue[MagneticScale]*0.6}]]
   };
   
   
   Print["Selected:",Dynamic[
   	selected
   	]];
   	  
   Graphics3D[
    {
     MapIndexed[DrawAtom, pos],
    If[OptionValue[UnitCell],
     	{OptionValue[UnitCellColor],
      {Cylinder[{xyzCorners[[#[[1]]]], xyzCorners[[#[[2]]]]}, 
         OptionValue[UnitCellRadius]] & /@ box},
         Sphere[#,OptionValue[UnitCellRadius]]&/@xyzCorners
         },
      {}],
     If[OptionValue[Indices],
      MapIndexed[
       Text[Framed[Style[First@#2, 12], FrameMargins -> 2, 
          Background -> LightGreen], a*#1.bas] &, pos],
      {}],
      If[OptionValue[Magnetic]!={},
     	MapIndexed[
       		DrawMag[#1,OptionValue[Magnetic][[First@#2]]]&,pos
       	],
      {}]
      
     },
    Evaluate@FilterRules[{opts}, Options[Graphics3D]]
    ]
   ];
   
Options[DrawInteractive]={
   	Options[Graphics3D], 
   	Indices -> False, 
    UnitCell -> True, 
    Radius -> {},
    Colors -> {}, 
    UnitCellRadius -> 0.1,
    UnitCellColor -> White,
    Magnetic -> {},
    MagneticDirection->{0, 0, 1},
    MagneticScale->0.5,
    Selected->{},
    ClickedFunction->Function[{index,position},1]
    };


POSCAR /: Replicate[POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], vec_List ] :=
  Module[{newBase, newNelem, newPos, posPerElem},
   newBase = bas*vec;
   newNelem = nelem*Times @@ vec;
   
   newPos = Map[#/vec &, pos];
   posPerElem = 
    Take[newPos, #] & /@ 
     Partition[
      Riffle[Rest@FoldList[Plus, 0, nelem] - nelem + 1, 
       Rest@FoldList[Plus, 0, nelem]], 2];
   
   newPos = Flatten[Table[
      Table[
       Map[# + {i, j, k}/vec &, epos]
       , {i, 0, vec[[1]] - 1}, {j, 0, vec[[2]] - 1}, {k, 0, 
        vec[[3]] - 1}
       ]
      , {epos, posPerElem}
      ], 4];

   POSCAR[name, a, newBase, elem, newNelem, newPos, vel, dyn]
   ];

Options[WriteToString]={Format -> {20, 16}, 
      PrintVelocities -> True,
      VASP4->False};


POSCAR /: WriteToString[
   POSCAR[name_, a_, bas_, elem_, nelem_, pos_, vel_, dyn_], 
   opts : OptionsPattern[{Format -> {20, 16}, 
      PrintVelocities -> True,
      VASP4->False}]] :=
  Module[{res, format},
   format = OptionValue[Format];
   res = name <> "\n" <> 
     TableToString[a, 2, format] <> "\n" <>
     TableToString[bas, 4, format] <> "\n" <>
     If[OptionValue[VASP4],"","  " <> StringJoin[Riffle[elem, " "]] <> "\n"] <>
     "  " <> 
     StringJoin[Riffle[ToString /@ nelem, " "]] <> "\n" <>
     If[Length[dyn] > 0, "S \n", ""] <> "Direct \n" <>
  
     If[Dimensions[pos] == Dimensions[dyn],
      TableToString[Join[pos, dyn, 2], 1, format],
      TableToString[pos, 1, format]
      ] <> "\n" <>
     
     If[Dimensions[pos] == Dimensions[vel] && 
       OptionValue[PrintVelocities],
      "Cartesian \n" <>
       TableToString[vel, 1, format]
      ,
      ""
      ];
   res
   ];