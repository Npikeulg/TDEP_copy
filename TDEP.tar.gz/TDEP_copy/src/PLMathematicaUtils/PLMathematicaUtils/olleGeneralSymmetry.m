(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loSingletTranslationalSymmetry::usage=""
loGeneralTransposeSymmetry::usage=""
loGeneralRigidTranslationSymmetry::usage=""
loGeneralPointGroupSymmetry::usage=""
loGeneralNonrigidTranslationalSymmetry::usage=""
loGeneralAcousticSumRules::usage=""
loGeneralRigidTranslationSymmetryWithPermutations::usage=""
loGeneralPointGroupSymmetryWithPermutations::usage=""
End[];

loSingletTranslationalSymmetry[fc_, star_, uc_] := Module[
   {symops, na, symrot, a1, a2, cList, i, m1, m2, rls},
   
   symops = loReturnValidSymmetryOperations[uc];
   forceconstants = fc;
   na = Dimensions[fc][[1]];
   
   For[a1 = 1, a1 <= na, a1++,
    For[a2 = a1, a2 <= na, a2++,
      (* get the list of connecting operations *)
      
      cList = star[[8]][[a1, a2]];
      
      For[i = 1, i <= Length[cList], i++,
       m1 = forceconstants[[a1]];
       m2 = 
        loApplySymopToTensor[forceconstants[[a2]], 
         symops[[cList[[i]]]], 1];
       rls = Flatten[Solve[m1 == m2]];
       forceconstants = forceconstants /. rls;
       ];
      ];
    ];
   forceconstants
   ];

loGeneralAcousticSumRules[fc_] := Module[
   {forceconstants, na, order, fcsum, clusterList, i, j, a1, zeroterm,
     rng},
   
   newfc = fc;
   forceconstants = fc[[4]];
   na = Dimensions[fc][[2]];
   order = Length[fc[[1, 1]][[1]]];
   zeroterm = ConstantArray[0, {order, 3}];
   For[a1 = 1, a1 <= na, a1++,
    (* Where is the zero term? *)
    
    j = First@Flatten[Position[fc[[1, a1]], zeroterm]];
    rng = Delete[Range[Length[fc[[1, a1]]]], j];
    fcsum = Sum[forceconstants[[a1, i]], {i, rng}];
    forceconstants[[a1, j]] = -fcsum;
    ];
   
   newfc[[4]] = forceconstants;
   newfc
   ];

loGeneralNonrigidTranslationalSymmetry[fc_, star_, uc_] := 
  Module[{forceconstants, na, symops, order, a1, a2, nc, nv, 
    matchingOperations, p, op, rotatedClusters, matchtable, i, j, m1, 
    m2, solutions},

   newfc = fc;
   forceconstants = fc[[4]];
   na = Dimensions[fc][[2]];
   symops = loReturnValidSymmetryOperations[uc];
   order = Length[fc[[1, 1]][[1]]];
   
   For[a1 = 1, a1 <= na, a1++,
    For[a2 = a1 + 1, a2 <= na, a2++,
      If[star[[6, a1]] == star[[6, a2]],
        nc = Length[fc[[1, a1]]];
        nv = Length[star[[7, a1]]];
        matchingOperations = symops[[           
           Flatten[
            Position[
             Table[Length[
                Union[star[[7, a1]], 
                 loRotateKvalisortVector[#, symops[[i]]] & /@ 
                  star[[7, a2]], 
                 SameTest -> loKvalisortVectorTest]] == nv, {i, 1, 
               Length[symops]}], True]]
           ]];
        (*Now I have a list of operations that turn star 1 into star 2*)
        For[p = 1, p <= Min[48, Length[matchingOperations]], p++,
         op = matchingOperations[[p]];
         rotatedClusters = 
          loClusterRotateKvalisort[#, op] & /@ fc[[3, a2]];
         matchtable = 
          Position[
           Table[loClusterMatchKvalisort[fc[[3, a1]][[i]], 
             rotatedClusters[[j]]], {i, 1, nc}, {j, 1, nc}], True];
         If[Length[matchtable] == nc,
          For[i = 1, i <= Length[matchtable], i++,
            m1 = forceconstants[[a1, matchtable[[i, 1]]]];
            
            m2 = loApplySymopToTensor[
              forceconstants[[a2, matchtable[[i, 2]]]], op, order];
            solutions = Flatten[Solve[m1 == m2]];
            forceconstants = forceconstants /. solutions;
            ];
          ];
         ];
        ];
      ];
    ];
   newfc[[4]] = forceconstants;
   newfc];

loGeneralPointGroupSymmetry[fc_, symops_] := Module[
   {na, a1, a2, nc, order, c1, c2, m1, m2, solutions, forceconstants, 
    symrot, rotatedClusters, s, op, matchtable, i, j},
   
   newfc = fc;
   forceconstants = fc[[4]];
   na = Dimensions[fc][[2]];
   symrot = Union[symops[[;; , 1]]];
   order = Length[fc[[1, 1]][[1]]];
   
   For[a1 = 1, a1 <= na, a1++,
    nc = Length[fc[[1, a1]]];
    For[s = 1, s <= Min[48, Length[symrot]], s++,
     op = symrot[[s]];
     rotatedClusters = loClusterRotateKvalisort[#, op] & /@ fc[[3, a1]];
     matchtable = Position[Table[loClusterMatchKvalisort[fc[[3, a1]][[i]],rotatedClusters[[j]]],{i, 1, nc}, {j, 1, nc}], True];
     (* alla måste matcha, tror jag *)
     
     For[i = 1, i <= Length[matchtable], i++,
      m1 = forceconstants[[a1, matchtable[[i, 1]]]];
      m2 = loApplySymopToTensor[forceconstants[[a1, matchtable[[i, 2]]]], op, order];
      solutions = Flatten[Solve[m1 == m2]];
      forceconstants = forceconstants /. solutions;
      ];
     ];
    ];
   newfc[[4]] = forceconstants;
   newfc
   ];

loGeneralTransposeSymmetry[fc_] := Module[
   {na, order, forceconstants, a1, a2, m1, m2, c1, c2, nc1, 
    nc2, solutions, perms, p},
   
   na = Dimensions[fc][[2]];
   newfc = fc;
   order = Length[fc[[1, 1]][[1]]];
   forceconstants = fc[[4]];
   
   For[a1 = 1, a1 <= na, a1++,
    For[a2 = 1, a2 <= na, a2++,
      nc1 = Length[fc[[1, a1]]];
      nc2 = Length[fc[[1, a2]]];
      For[c1 = 1, c1 <= nc1, c1++,
       For[c2 = 1, c2 <= nc2, c2++,
         perms = loReturnPermutationOfIndices[fc[[5, a1]][[c1]], fc[[5, a2]][[c2]], order];
         For[p = 1, p <= Length[perms], p++,
          m1 = forceconstants[[a1, c1]];
          m2 = TensorTranspose[forceconstants[[a2, c2]], perms[[p]]];
          solutions = Flatten[Solve[m1 == m2]];
          forceconstants = forceconstants /. solutions;
          ];
         ];
       ];
      ];
    ];
   newfc[[4]] = forceconstants;
   newfc
   ];

loGeneralRigidTranslationSymmetry[fc_] := Module[
   {na, a1, a2, nc1, nc2, c1, c2, m1, m2, solutions, 
    forceconstants,
    shifts, match, i},
   newfc = fc;
   forceconstants = fc[[4]];
   na = Dimensions[fc][[2]];
   
   For[a1 = 1, a1 <= na, a1++,
    For[a2 = 1, a2 <= na, a2++,
      nc1 = Length[fc[[1, a1]]];
      nc2 = Length[fc[[1, a2]]];
      For[c1 = 1, c1 <= nc1, c1++,
       For[c2 = 1, c2 <= nc2, c2++,
         (* The possible rigid shifts *)         
         shifts = Union[fc[[3, a2]][[c2]], SameTest -> loKvalisortVectorTest];
         (* See if I match something *)        
         match = Apply[Or, Flatten[Table[
             loClusterMatchKvalisort[
              fc[[3, a1]][[c1]],
              loClusterShiftKvalisort[fc[[3, a2]][[c2]], shifts[[i]]]
              ]
             , {i, 1, Length[shifts]}]]];
         (* And if it matches, I apply it! *)
         If[match,
          m1 = forceconstants[[a1, c1]];
          m2 = forceconstants[[a2, c2]];
          solutions = Flatten[Solve[m1 == m2]];
          forceconstants = forceconstants /. solutions;
          ];
         ];
       ];
      ];
    ];
   newfc[[4]] = forceconstants;
   newfc
   ];

loGeneralPointGroupSymmetryWithPermutations[fc_, symops_, cluster_] :=
   Module[{na, a1, nc, c1, c2, m1, m2, solutions, forceconstants, match, i, cl1, cl2,
    op, symrot, s, p, order, baseshift, rotatedClusterIndices, perms},
   newfc = fc;
   forceconstants = fc[[4]];
   na = Dimensions[fc][[2]];
   symrot = Union[symops[[;; , 1]]];
   order = Length[fc[[1, 1]][[1]]];
   
   For[a1 = 1, a1 <= na, a1++,
    nc = Length[fc[[1, a1]]];
    baseshift = -cluster[[1, cluster[[3]][[a1]]]];
    
    For[c1 = 1, c1 <= nc, c1++,
     For[c2 = c1, c2 <= nc, c2++,
       (*The possible rigid shifts*)
       cl1 = fc[[3, a1]][[c1]];
       For[s = 1, s <= Min[48, Length[symrot]], s++,
        op = symrot[[s]];
        cl2 = loClusterRotateKvalisort[fc[[3, a1]][[c2]], op];
        (*See if I match something*)
        
        match = loClusterMatchKvalisort[cl1, cl2];
        (*And if it matches,I apply it!*)
        If[match,
         (* First, rotate the matrix *)
         
         m1 = forceconstants[[a1, c1]];
         m2 = loApplySymopToTensor[forceconstants[[a1, c2]], op, order];
         (* Apply the basic equality *)
         
         solutions = Flatten[Solve[m1 == m2]];
         forceconstants = forceconstants /. solutions;
         
         (* Then check the transpositions that matches! *)
         
         rotatedClusterIndices = loFindClusterIndices[cl2, cluster, baseshift];
         perms = loReturnPermutationOfIndices[fc[[5, a1]][[c2]], rotatedClusterIndices, order];
         For[p = 1, p <= Length[perms], p++,
          solutions=Flatten[Solve[m1==TensorTranspose[m2,perms[[p]]]]];          
          forceconstants = forceconstants /. solutions;
          ];
         
         ];
        ];
       ];
     ];
    ];
   newfc[[4]] = forceconstants;
   newfc
   ];

loGeneralRigidTranslationSymmetryWithPermutations[fc_, cluster_] := 
  Module[
   {na, a1, a2, nc1, nc2, c1, c2, m1, m2, solutions, forceconstants, 
    shifts, match, i, shiftedCluster, shiftedClusterIndices, 
    baseshift1, baseshift2, p, perms, order, s},
   
   newfc = fc;
   forceconstants = fc[[4]];
   na = Dimensions[fc][[2]];
   order = Length[fc[[1, 1]][[1]]];
   
   For[a1 = 1, a1 <= na, a1++,
    baseshift1 = -cluster[[1, cluster[[3]][[a1]]]];
    nc1 = Length[fc[[1, a1]]];
    For[c1 = 1, c1 <= nc1, c1++,
     (* Find possible shifts *)
     
     shifts = 
      Union[fc[[3, a1]][[c1]], SameTest -> loKvalisortVectorTest];
     For[s = 1, s <= Length [shifts], s++,
      (* shift cluster 1 *)
      
      shiftedCluster = 
       loClusterShiftKvalisort[fc[[3, a1]][[c1]], shifts[[s]]];
      shiftedClusterIndices = 
       loFindClusterIndices[shiftedCluster, cluster, baseshift1];
      (* I want to compare this to all other clusters *)
      
      For[a2 = 1, a2 <= na, a2++,
       nc2 = Length[fc[[1, a2]]];
       For[c2 = 1, c2 <= nc2, c2++,
        (* There is no need to match clusters,  I just have to find a permutation of indices *)
        
        perms = loReturnPermutationOfIndices[shiftedClusterIndices, 
          fc[[5, a2]][[c2]], order];
        (* 
        Not terribly shure wich of the matrices should be transposed, 
        but well well *)
        m1 = forceconstants[[a1, c1]];
        m2 = forceconstants[[a2, c2]];
        For[p = 1, p <= Length[perms], p++,
         solutions = 
          Flatten[Solve[TensorTranspose[m2, perms[[p]]] == m1]];
         forceconstants = forceconstants /. solutions;
         ];
        ];
       ];
      (* slut på shift av cluster 1 *)
      ];
     ];
    ];
   newfc[[4]] = forceconstants;
   newfc];
