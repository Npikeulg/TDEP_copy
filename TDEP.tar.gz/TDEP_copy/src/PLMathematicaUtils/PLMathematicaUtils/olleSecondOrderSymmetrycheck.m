(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loSecondOrderTransposeSymmetry::usage=""
loPairRigidTranslationSymmetryWithPermutations::usage=""
loPairPermutationsThatMakesThemMatch::usage=""
loBuildPairSymmetryConnectionListWithBornCharges::usage=""
loApplyPointAndTranslationalSymmetry::usage=""
loElectrostaticRigidTranslation::usage=""
End[];

loSecondOrderTransposeSymmetry[pair_] := Module[
   {na, forceconstants, a1, v1, m1, m2, solutions},
   
   na = Dimensions[pair][[2]];
   newpairs = pair;
   forceconstants = pair[[4]];
   (*Enkla transponeringen Dij=Dji*)
   For[a1 = 1, a1 <= na, a1++,
    For[v1 = 1, v1 <= Length[pair[[1, a1]]], v1++,
      m1 = forceconstants[[a1, v1]];
      m2 = TensorTranspose[forceconstants[[a1, v1]], {2, 1}];
      solutions = Flatten[Solve[m1 == m2]];
      forceconstants = forceconstants /. solutions;
      ];
    ];
   newpairs[[4]] = forceconstants;
   newpairs
   ];

loPairPermutationsThatMakesThemMatch[p1_, p2_] := Module[
   {perms, i},
   (*perms={{1,2,3},{1,3,2}};*)(*perms={{1,2,3},{1,3,2},{3,2,1},{2,1,
   3}};*)
   perms = Permutations[{1, 2}];
   i = Flatten[
     Position[
      SquaredEuclideanDistance[p1, p2[[#]]] < 10^-4 & /@ perms, True]];
   perms[[i]]
   ];

loPairRigidTranslationSymmetryWithPermutations[fc_, cluster_] := 
  Module[
   {na, a1, a2, nc1, nc2, c1, c2, m1, m2, solutions, forceconstants, 
    shifts, match, i,
    shiftedCluster, shiftedClusterIndices, baseshift1, baseshift2, p, 
    perms, order, s},
   newfc = fc;
   l = {};
   forceconstants = fc[[4]];
   na = Dimensions[fc][[2]];
   order = Length[fc[[1, 1]][[1]]];
   For[a1 = 1, a1 <= na, a1++,
    baseshift1 = -cluster[[1, cluster[[3]][[a1]]]];
    nc1 = Length[fc[[1, a1]]];
    For[c1 = 1, c1 <= nc1, c1++,
     (*Find possible shifts*)
     
     shifts = 
      Union[fc[[3, a1]][[c1]], SameTest -> loKvalisortVectorTest];
     For[s = 1, s <= Length[shifts], s++,
      (*shift cluster 1*)
      
      shiftedCluster = 
       loClusterShiftKvalisort[fc[[3, a1]][[c1]], shifts[[s]]];
      AppendTo[l, shiftedCluster];
      For[a2 = 1, a2 <= na, a2++,
       nc2 = Length[fc[[1, a2]]];
       For[c2 = 1, c2 <= nc2, c2++,
        (* Which permutation of the thingys will make them the same? *)
        perms = 
         loPairPermutationsThatMakesThemMatch[shiftedCluster, 
          fc[[3, a2]][[c2]]];
        m1 = forceconstants[[a1, c1]];
        m2 = forceconstants[[a2, c2]];
        For[p = 1, p <= Length[perms], p++,
         solutions = 
          Flatten[Solve[TensorTranspose[m2, perms[[p]]] == m1]];
         forceconstants = forceconstants /. solutions;
         ];
        ];
       ];
      ];
     ];
    ];
   newfc[[4]] = forceconstants;
   newfc
   ];

loBuildPairSymmetryConnectionListWithBornCharges[star_, symops_, 
   allSymops_, Z_] := Module[
   {na, speclist, a1, a2, i, j, nv, l1, l2, vectors,
    indices, symbols, borncharges, matchTable, matches,
    loApplySymopToSpeclist, loCompareSpecs},
   
   (* some functions to compare and so on *)
   
   loApplySymopToSpeclist[l_, op_] := Module[
     {n},
     n = Length[l];
     ll = 
      Table[{l[[i, 1]].op, l[[i, 2]], 
        loApplySymopToTensor[l[[i, 3]], op, 2]}, {i, 1, n}]
     ];
   
   loCompareSpecs[s1_, s2_] := Module[
     {},
     a = SquaredEuclideanDistance[s1[[1]], s2[[1]]] < 10^-4;
     b = s1[[2]] == s2[[2]];
     c = SameQ[s1[[3]], s2[[3]]];
     a == True && b == True && c == True
     ];
   
   na = Length[star[[1]]];
   
   (* build the specification list *)
   (* it's a list with vector, 
   species, Z *)
   speclist = ConstantArray[{}, {na}];
   For[a1 = 1, a1 <= na, a1++,
    nv = Length[star[[1, a1]]];
    vectors = star[[2, a1]];
    indices = star[[1, a1]];
    symbols = star[[3, a1]];
    borncharges = Table[Z[[indices[[i]]]], {i, 1, nv}];
    speclist[[a1]] = 
     Table[{vectors[[i]], symbols[[i]], borncharges[[i]]}, {i, 1, nv}];
    ];
   
   (* Compare them *)
   matchList = ConstantArray[{}, {na, na}];
   For[a1 = 1, a1 <= na, a1++,
    l1 = speclist[[a1]];
    For[a2 = a1, a2 <= na, a2++,
     If[Length[speclist[[a1]]] == Length[speclist[[a2]]] && 
        star[[4, a1]] == star[[4, a2]],
       (* No need to test if the number of vectors are not the same *)
       (* and if the starting element is not the same *)      
       (* If a1=a2, then we should check only the valid operations *)

         If[a1 == a2,
         For[k = 1, k <= Length[symops], k++,
           l2 = loApplySymopToSpeclist[speclist[[a2]], symops[[k, 1]]];
           nv = Length[l1];
           
           matchTable = 
            Table[loCompareSpecs[l1[[i]], l2[[j]]], {i, 1, nv}, {j, 1,
               nv}];
           l = matchTable;
           ll1 = l1;
           ll2 = l2;
           matches = Position[matchTable, True];
           If[Length[matches] > 0 && Length[matches] == nv,
            AppendTo[matchList[[a1, a2]], {k, matches}];
            ];
           ];
         ,
         (* If a1 != a2, then all operations that are actual operations should be checked *)
         For[k = 1, k <= Length[allSymops], k++,
           l2 = loApplySymopToSpeclist[speclist[[a2]], allSymops[[k]]];
           nv = Length[l1];
           
           matchTable = 
            Table[loCompareSpecs[l1[[i]], l2[[j]]], {i, 1, nv}, {j, 1,
               nv}];
           l = matchTable;
           ll1 = l1;
           ll2 = l2;
           matches = Position[matchTable, True];
           If[Length[matches] > 0 && Length[matches] == nv,
            AppendTo[matchList[[a1, a2]], {k, matches}];
            ];
           ];
        
         ];
       ];
     ];
    ];
   matchList
   ];

loApplyPointAndTranslationalSymmetry[pair_, ml_, symops_, 
   allSymops_] := Module[
   {na, a1, a2, no, i, j, i1, i2, m1, m2},
   na = Length[pair[[1]]];
   newpair = pair;
   fc = newpair[[4]];
   For[a1 = 1, a1 <= na, a1++,
    For[a2 = a1, a2 <= na, a2++,
      (**)
      If[a1 == a2,
       (* a1 = a2 *)
       no = Length[ml[[a1, a2]]];
       For[i = 1, i <= no, i++,
        op = symops[[ml[[a1, a2]][[i]][[1]], 1]];
        nv = Length[fc[[a1]]];
        For[j = 1, j <= nv, j++,
         i1 = ml[[a1, a2]][[i]][[2]][[j, 1]];
         i2 = ml[[a1, a2]][[i]][[2]][[j, 2]];
         m1 = fc[[a1]][[i1]];
         m2 = loApplySymopToTensor[fc[[a2]][[i2]], op, 2];
         sol = First@Solve[m1 == m2];
         If[Length[sol] > 0,
          fc = fc /. sol;
          ];
         ];
        ];
       ,
       (* a1 != a2*)
       no = Length[ml[[a1, a2]]];
       For[i = 1, i <= no, i++,
        op = allSymops[[ml[[a1, a2]][[i]][[1]]]];
        nv = Length[fc[[a1]]];
        For[j = 1, j <= nv, j++,
         i1 = ml[[a1, a2]][[i]][[2]][[j, 1]];
         i2 = ml[[a1, a2]][[i]][[2]][[j, 2]];
         m1 = fc[[a1]][[i1]];
         m2 = loApplySymopToTensor[fc[[a2]][[i2]], op, 2];
         sol = First@Solve[m1 == m2];
         If[Length[sol] > 0,
          fc = fc /. sol;
          ];
         ];
        ];
       ];
      (**)
      ];
    ];
   newpair[[4]] = fc;
   newpair
   
   ];

loElectrostaticRigidTranslation[pair_] := Module[
   {na, fc, a1, a2, nv1, nv2, v1, v2, aa1, aa2, m1, m2, sol},
   na = Length[pair[[1]]];
   newpair = pair;
   fc = pair[[4]];
   For[a1 = 1, a1 <= na, a1++,
    For[a2 = a1, a2 <= na, a2++,
      nv1 = Length[pair[[1, a1]]];
      nv2 = Length[pair[[1, a2]]];
      For[v1 = 1, v1 <= nv1, v1++,
       For[v2 = 1, v2 <= nv2, v2++,
         aa1 = pair[[2, a1]][[v1]];
         aa2 = pair[[2, a2]][[v2]];
         If[a2 == aa1 && a1 == aa2,
          
          If[SquaredEuclideanDistance[
              pair[[1, a1]][[v1, 2]], -pair[[1, a2]][[v2, 2]]] < 10^-5,
            (* Now R=-R*)
            m1 = fc[[a1]][[v1]];
            m2 = TensorTranspose[fc[[a2]][[v2]],{2,1}];
            sol = First@Solve[m1 == m2];
            If[Length[sol] > 0,
             fc = fc /. sol;
             ];
            ];
          ];
         ];
       ];
      
      ];
    ];
   newpair[[4]] = fc;
   newpair
   ];
