(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loTriangleRotate::usage=""
loTrianglePermutationsThatMakesThemMatch::usage=""
loTriangleMatchKvalisort::usage=""
loTriangleShiftKvalisort::usage=""
loApplySymopToThirdOrderFc::usage=""
loThirdOrderTranslationalSymmetry::usage=""
loThirdOrderPointGroupSymmetry::usage=""
loThirdOrderAcousticSumRule::usage=""
loThirdOrderTransposeSymmetry::usage=""
loTripletPermutationsThatMakesThemMatch::usage=""
loTripletRigidTranslationSymmetryWithPermutations::usage=""
(*loThirdOrderSymcheckDerivativeorder::usage=""
loThirdOrderSymcheckTransposeSymmetry::usage=""
loThirdOrderSymcheckPointgroup::usage=""
loThirdOrderSymcheckSum::usage=""
loThirdOrderSymcheckTranslational::usage=""*)
End[];

loTripletPermutationsThatMakesThemMatch[p1_, p2_] := Module[
   {perms, i},
   perms = {{1, 2, 3}, {1, 3, 2}, {3, 2, 1}, {2, 1, 3}};
   (*perms=Permutations[{1,2}];*)
   
   i = Flatten[
     Position[
      SquaredEuclideanDistance[p1, p2[[#]]] < 10^-4 & /@ perms, True]];
   perms[[i]]
   ];

loTripletRigidTranslationSymmetryWithPermutations[fc_, cluster_] := 
  Module[
   {na, a1, a2, nc1, nc2, c1, c2, m1, m2, solutions, forceconstants, 
    shifts, match, i,
    shiftedCluster, shiftedClusterIndices, baseshift1, baseshift2, p, 
    perms, order, s},
   newfc = fc;
   forceconstants = fc[[4]];
   na = Dimensions[fc][[2]];
   order = Length[fc[[1, 1]][[1]]];
   For[a1 = 1, a1 <= na, a1++,
    nc1 = Length[fc[[1, a1]]];
    For[c1 = 1, c1 <= nc1, c1++,
     (*Find possible shifts*)
     
     shifts = 
      Union[fc[[3, a1]][[c1]], SameTest -> loKvalisortVectorTest];
     For[s = 1, s <= Length[shifts], s++,
      (*shift cluster 1*)
      
      shiftedCluster = 
       loClusterShiftKvalisort[fc[[3, a1]][[c1]], shifts[[s]]];
      For[a2 = 1, a2 <= na, a2++,
       nc2 = Length[fc[[1, a2]]];
       For[c2 = 1, c2 <= nc2, c2++,
        (* Which permutation of the thingys will make them the same? *)

                perms = 
         loTripletPermutationsThatMakesThemMatch[shiftedCluster, 
          fc[[3, a2]][[c2]]];
        m1 = forceconstants[[a1, c1]];
        m2 = forceconstants[[a2, c2]];
        For[p = 1, p <= Length[perms], p++,
         solutions = 
          Flatten[Solve[TensorTranspose[m2, perms[[p]]] == m1]];
         forceconstants = forceconstants /. solutions;
         ];
        ];
       ];
      ];
     ];
    ];
   newfc[[4]] = forceconstants;
   newfc
   ];




loTriangleRotate[t_, op_] := Module[{},
   loRotateKvalisortVector[#, op] & /@ t
   ];

loTrianglePermutationsThatMakesThemMatch[t1_, t2_] := Module[
   {perms, i},
   (*perms={{1,2,3},{1,3,2}};*)
   (*perms={{1,2,3},{1,3,2},{3,2,1},{2,1,3}};*)
   perms = Permutations[{1, 2, 3}];
   i = Flatten[
     Position[
      SquaredEuclideanDistance[t1, t2[[#]]] < 10^-4 & /@ perms, True]];
   perms[[i]]
   ];

loTriangleMatchKvalisort[t1_, t2_] := Module[
   {},
   SquaredEuclideanDistance[t1, t2] < 10^-4
   ];

loTriangleShiftKvalisort[t_, v_] := Module[
   {tt},
   tt = # - v & /@ t;
   tt[[;; , 4]] = t[[;; , 4]];
   tt
   ];

loApplySymopToThirdOrderFc[m_, op_] := Module[
   {},
   Table[Sum[m[[j1, j2, j3]]*
      op[[j1, i1]]*op[[j2, i2]]*op[[j3, i3]],
     {j1, 1, 3}, {j2, 1, 3}, {j3, 1, 3}],
    {i1, 1, 3}, {i2, 1, 3}, {i3, 1, 3}]
   ];

loTriangleArea[triangle_] := Module[
   {v1, v2},
   v1 = triangle[[1]] - triangle[[3]];
   v2 = triangle[[2]] - triangle[[3]];
   area = Norm[Cross[v1, v2]]/2
   ];

loThirdOrderTranslationalSymmetry[tri_, star_, uc_] := Module[
   {na, symops, triangles1, triangles2, triangleIndices1, 
    triangleIndices2, trianglesKvalisort1, trianglesKvalisort2, 
    forceconstants1, forceconstants2, ntri, vectorsKvalisort1, 
    vectorsKvalisort2, a1, a2, op, rotTetra, matchtable, m1, m2, 
    equations, matchingOperations, p, solutions, i},
   
   na = Dimensions[tri][[2]];
   newtri = tri;
   symops = loReturnValidSymmetryOperations[uc];
   
   For[a1 = 1, a1 <= na, a1++,
    triangles1 = tri[[1, a1]];
    triangleIndices1 = tri[[2, a1]];
    trianglesKvalisort1 = tri[[3, a1]];
    forceconstants1 = tri[[4, a1]];
    vectorsKvalisort1 = star[[7, a1]];
    
    For[a2 = a1+1, a2 <= na, a2++, If[star[[6, a1]] == star[[6, a2]],
       
       triangles2 = tri[[1, a2]];
       triangleIndices2 = tri[[2, a2]];
       trianglesKvalisort2 = tri[[3, a2]];
       forceconstants2 = tri[[4, a2]];
       vectorsKvalisort2 = star[[7, a2]];
       ntri = Length[triangles2];
       (* 
       Returns the symmetry operations that turns star 2 into star 1 *)

              matchingOperations = symops[[Flatten[
           Position[
            Table[
             
             Length[Union[
                Join[vectorsKvalisort1, 
                 loRotateKvalisortVector[#, symops[[i]]] & /@ 
                  vectorsKvalisort2], 
                SameTest -> loKvalisortVectorTest]] == 
              Length[vectorsKvalisort2]
             , {i, 1, Length[symops]}], True]]]];
       
       For[p = 1, p <= Min[48, Length[matchingOperations]], p++,
        op = matchingOperations[[p]];
        (* Rotate the triangles *)
        
        rotTetra = loTriangleRotate[#, op] & /@ trianglesKvalisort2;
        (* List that matches triangles *)
        
        matchtable = 
         Position[
          Table[loTriangleMatchKvalisort[ trianglesKvalisort1[[i]], 
            rotTetra[[j]] ], {i, 1, ntri}, {j, 1, ntri}], True];
        
        (* apply the equations *)
        For[i = 1, i <= ntri, i++,
         m1 = forceconstants1[[ matchtable[[i, 1]] ]];
         m2 = 
          loApplySymopToThirdOrderFc[
           forceconstants2[[ matchtable[[i, 2]] ]], op];
         
         solutions = Flatten[Solve[m1 == m2]];
         If[Length[solutions] > 0,
          forceconstants1 = forceconstants1 /. solutions;
          ];
         ];
        ];
       
       ];];
    newtri[[4, a1]] = forceconstants1;
    ];
   newtri
   ];

loThirdOrderPointGroupSymmetry[tri_, symops_, star_] := Module[
   {na, ntri, a1, i, t1, t2, triangles, triangleIndices, 
    trianglesKvalisort, forceconstants, s, p, m1, m2, equations, 
    solutions, perm, symrot, op, uk, rotTetra, matchtable},
   na = Dimensions[tri][[2]];
   newtri = tri;
   symrot = Union[symops[[;; , 1]]];
   
   For[a1 = 1, a1 <= na, a1++,
    triangles = tri[[1, a1]];
    triangleIndices = tri[[2, a1]];
    trianglesKvalisort = tri[[3, a1]];
    forceconstants = tri[[4, a1]];
    ntri = Length[triangles];
    
    For[s = 1, s <= Min[48, Length[symrot]], s++,
     op = symrot[[s]];
     rotTetra = loTriangleRotate[#, op] & /@ trianglesKvalisort;
     matchtable = 
      Position[
       Table[loTriangleMatchKvalisort[ trianglesKvalisort[[i]], 
         rotTetra[[j]] ], {i, 1, ntri}, {j, 1, ntri}], True];
     
     For[i = 1, i <= Length[matchtable], i++,
      m1 = forceconstants[[ matchtable[[i, 1]] ]];
      m2 = 
       loApplySymopToThirdOrderFc[
        forceconstants[[ matchtable[[i, 2]] ]], op];
      
      solutions = Flatten[Solve[m1 == m2]];
      If[Length[solutions] > 0,
       forceconstants = forceconstants /. solutions;
       ];
      ];
     newtri[[4, a1]] = forceconstants;
     ];
    ];
   newtri
   ];

loThirdOrderAcousticSumRule[tri_, star_] := Module[
   {na, ntri, a1, i, j, triangles, triangleIndices, 
    trianglesKvalisort, forceconstants, solutions, vectors, nv, vec, 
    relevantTriangles, fcsum,newtri},
   na = Dimensions[tri][[2]];
   newtri = tri;
   
   For[a1 = 1, a1 <= na, a1++,
    triangles = tri[[1, a1]];
    triangleIndices = tri[[2, a1]];
    trianglesKvalisort = tri[[3, a1]];
    forceconstants = tri[[4, a1]];
    vectors = star[[2, a1]];
    ntri = Length[triangles];
    nv = Length[vectors];
    (**)
    
    For[j = 1, j <= 2, j++,
     For[vec = 1, vec <= nv, vec++,
       fcsum = ConstantArray[0, {3, 3, 3, 3}];
       relevantTriangles = 
        Flatten[Position[triangleIndices[[;; , j]], vec]];
       For[i = 1, i <= Length[relevantTriangles], i++,
        fcsum = fcsum + forceconstants[[ relevantTriangles[[i]] ]];
        ];
       
       fcsum = Union[Flatten[fcsum]];
       solutions = 
        Flatten[Solve[fcsum == Table[0, {i, 1, Length[fcsum]}]]];
       If[Length[solutions] > 0,
        forceconstants = forceconstants /. solutions;
        ];
       ];
     ];
    newtri[[4, a1]] = forceconstants;
    ];
   newtri
   ];

loThirdOrderTransposeSymmetry[tri_] := Module[
   {na, ntri, a1, t1, t2, triangles, triangleIndices, 
    trianglesKvalisort, forceconstants, s, p, shiftTri, shifts, m1, 
    m2,m2rot, equations, solutions, perm,
    symrot,rotTri},
   na = Dimensions[tri][[2]];
   newtri = tri;
   
   For[a1 = 1, a1 <= na, a1++,
    triangles = tri[[1, a1]];
    triangleIndices = tri[[2, a1]];
    trianglesKvalisort = tri[[3, a1]];
    forceconstants = tri[[4, a1]];
    ntri = Length[triangles];
    (* Test all triangles vs all others *)
    
    For[t1 = 1, t1 <= ntri, t1++,
     For[t2 = t1, t2 <= ntri, t2++,
      (* I will do no shifting, that may mess things up. But I will Rotate! *)
   (*
      perm=loTrianglePermutationsThatMakesThemMatch[trianglesKvalisort[[t1]],trianglesKvalisort[[t2]]];
      For[p = 1, p <= Length[perm], p++,
        m1 = forceconstants[[t1]];
        m2 = TensorTranspose[forceconstants[[t2]], perm[[p]]];
        solutions = Flatten[Solve[m1 == m2]];
        forceconstants = forceconstants /. solutions;
      ];
   *)      
      (* Shift the triangle a bit, no point to shift it with the same vector more than once. *)
      shifts=Union[trianglesKvalisort[[t2]],SameTest -> loKvalisortVectorTest];
      
      For[s = 1, s <= Length[shifts], s++,
       shiftTri=loTriangleShiftKvalisort[trianglesKvalisort[[t2]],shifts[[s]]];
       perm=loTrianglePermutationsThatMakesThemMatch[trianglesKvalisort[[t1]], shiftTri];
       (* Now I have the matching permutations *)
       
       For[p = 1, p <= Length[perm], p++,
        m1 = forceconstants[[t1]];
        m2 = TensorTranspose[forceconstants[[t2]], perm[[p]]];
        solutions = Flatten[Solve[m1 == m2]];
        forceconstants = forceconstants /. solutions;
        ];
       ];
       
      ];
     (* end t1 t2 loops*)
     ];
    newtri[[4, a1]] = forceconstants;
    ];
   newtri
   ];


