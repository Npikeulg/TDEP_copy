author: Olle Hellman
display: none
graph: none
propname: convert abinit
propnamelink: <a href="../program/convert_abinit_ddb_to_forceconstant.html">convert abinit</a>
{!man/convert_abinit_ddb_to_forceconstant.md!}

### Longer summary

This is a utility to convert Abinit DDB files to the TDEP forceconstant format. It will try to figure out the q-mesh used in the DFPT calculations automatically, but in case you used a shifted mesh, you might want to speficy it manually, since the information about the q-mesh is not printed to the DDB file.
