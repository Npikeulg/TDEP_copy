(* Mathematica package *)


Begin["PLMathematicaUtils`"];

BirchMurnaghanFitFormPofV::usage="BirchMurnaghanFitFormPofV[{{V1,P1},{V2,P2},...}]"
BirchMurnaghanFitFormEofVSI::usage="BirchMurnaghanFitFormEofVSI[{{V1,E1},{V2,E2},...}]"
BirchMurnaghanFitFormEofVAtomic::usage="BirchMurnaghanFitFormEofVAtomic[{{V1,E1},{V2,E2},...}]"

BirchMurnaghanFitFormEofVAtomic::fiterror = 
  "Problem fitting with inital B' as `1`, will try again";
End[];

BirchMurnaghanFitFormPofV[data_] := Module[{pofv, V0a, B0a, model, V},
   pofv = Fit[data, {1, V, V^2}, V];
   V0a = V /. First@Solve[pofv == 0, V];
   B0a = -D[pofv, V]*V0a /. V -> V0a;
   model = 
    NonlinearModelFit[
     data, (3 Global`B0)/
      2 ((Global`V0/V)^(7/3) - (Global`V0/V)^(5/3)) (1 + 
        3/4 (Global`Bp - 4) ((Global`V0/V)^(2/3) - 1)), {{Global`B0, B0a}, {Global`V0, V0a}, {Global`Bp, 
       4.06}}, V, PrecisionGoal -> 8, AccuracyGoal -> 5];
   {model, {Global`B0, Global`V0, Global`Bp} /. model["BestFitParameters"], {Global`B0 -> B0a, 
     Global`V0 -> V0a}}
   ];

BirchMurnaghanFitFormEofVSI[data_] := 
  Module[{rescaledData, eofv, V, V0a, B0a, model},
   (*Rescale data A^3 -> m^3, eV -> J*)
   
   rescaledData = {#[[1]]*10.0^-30, #[[2]]*1.602176487`*^-19} & /@ 
     data;
   eofv = Fit[rescaledData, {1, V, V^2}, V];
   V0a = V /. First@Solve[D[eofv, V] == 0, V];
   B0a = D[eofv, {V, 2}]*V0a /. V -> V0a;
   model = 
    NonlinearModelFit[rescaledData, 
     Global`E0 + (9 Global`V0 Global`B0)/
       16 (((Global`V0/V)^(2/3) - 1)^3 Global`Bp + ((Global`V0/V)^(2/3) - 1)^2 (6 - 
            4 (Global`V0/V)^(2/3))) , {{Global`E0, 
       Min[rescaledData[[All, 2]]]}, {Global`B0, B0a}, {Global`V0, V0a}, {Global`Bp, 
       4.06}}, V, PrecisionGoal -> 50, AccuracyGoal -> 50];
   
   {model, {Global`E0, Global`B0, Global`V0, Global`Bp} /. model["BestFitParameters"]}
   ];

BirchMurnaghanFitFormEofVAtomic[data_] := 
  Module[{eofv, V, V0a, B0a, Bpa, model, 
    scaleFactor = 1.602176487`*^-19*10^30*10^-9},
   eofv = Fit[data, {1, V, V^2}, V];
   V0a = V /. First@Solve[D[eofv, V] == 0, V];
   B0a = D[eofv, {V, 2}]*V0a /. V -> V0a;
   model = -1;
   While[model == -1,
    Bpa = RandomReal[{4, 5}];
    model = 
     Check[NonlinearModelFit[data, 
       Global`E0 + (9 Global`V0 Global`B0)/
         16 (((Global`V0/V)^(2/3) - 1)^3 Global`Bp + ((Global`V0/V)^(2/3) - 1)^2 (6 - 
              4 (Global`V0/V)^(2/3))), {{Global`E0, Min[data[[All, 2]]]}, {Global`B0, 
         B0a}, {Global`V0, V0a}, {Global`Bp, Bpa}}, V], -1];
    If[model == -1, Message[CalcBulkFormEofVAtomic::fiterror, Bpa]];
    ];
   {model, {Global`E0, Global`B0*scaleFactor, Global`V0, Global`Bp} /. model["BestFitParameters"],scaleFactor}
   ];




