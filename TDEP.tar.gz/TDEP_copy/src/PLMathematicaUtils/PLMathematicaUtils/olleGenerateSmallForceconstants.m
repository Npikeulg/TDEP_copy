(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loFirstOrderGenerateSinglets::usage=""
loSecondOrderGeneratePairs::usage=""
loThirdOrderGenerateTriplets::usage=""
loFourthOrderGenerateTetrahedrons::usage=""
End[];

loFirstOrderGenerateSinglets[star_, uc_] := Module[
   {na, makeElem, a1, ii},
   na = Length[star[[3]]];
   makeElem[a1_, ii_] := 
    Symbol["tfo" <> ToString[a1] <> "m" <> ToString[ii]];
   Table[makeElem[a1, ii], {a1, 1, na}, {ii, 1, 3}]
   ];

loSecondOrderGeneratePairs[star_, cutoff_, cluster_, uc_] := 
  Module[{na, pairs, makeElem, a1, i, vectors, vectorsKvalisort, nv, 
    pairIndices, pairsKvalisort, forceconstants, pair, ind, 
    pairKvalisort, atom1vector, atom1vectorKvalisort, 
    atom1positionInCluster, clusterIndices, atom2vector, 
    atom2vectorKvalisort, atom2positionInCluster, 
    largeClusterIndexThingy},
   na = Length[star[[3]]];
   prs = ConstantArray[{}, {6, na}];
   makeElem[a1_, i_, ii_, jj_] := 
    Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "m" <> 
      ToString[ii] <> ToString[jj]];
   largeClusterIndexThingy = {};
   For[a1 = 1, a1 <= na, a1++,
    vectors = star[[2, a1]];
    vectorsKvalisort = star[[7, a1]];
    nv = Length[vectors];
    (*Empty arrays*)
    pairIndices = {};
    pairs = {};
    pairsKvalisort = {};
    forceconstants = {};
    clusterIndices = {};
    (* For my cluster notation thingy*)
    
    atom1vector = 
     Chop[DirectPositions[uc, a1].Base[uc]*LatticeConstant[uc]];
    atom1vectorKvalisort = Join[atom1vector, {star[[6, a1]]}];
    atom1positionInCluster = 
     First@Flatten[
       Position[
        loKvalisortVectorTest[#, atom1vectorKvalisort] & /@ 
         cluster[[1]], True]];
    For[i = 1, i <= nv, i++,
     (*The vector*)
     pair = ConstantArray[0, {2, 3}];
     pair[[1]] = {0, 0, 0};
     pair[[2]] = vectors[[i]];
     
     (**)
     atom2vector = atom1vector + vectors[[i]];
     atom2vectorKvalisort = Join[atom2vector, {star[[5, a1]][[i]]}];
     atom2positionInCluster = 
      First@Flatten[
        Position[
         loKvalisortVectorTest[#, atom2vectorKvalisort] & /@ 
          cluster[[1]], True]];
     
     (*The indices it points to*)
     ind = star[[1, a1]][[i]];
     (*The vector with kvalisort*)
     
     pairKvalisort = ConstantArray[0, {2, 4}];
     pairKvalisort[[1]] = Join[{0, 0, 0}, {star[[6, a1]]}];
     pairKvalisort[[2]] = star[[7, a1]][[i]];
     AppendTo[pairs, pair];
     AppendTo[pairIndices, ind];
     AppendTo[pairsKvalisort, pairKvalisort];
     AppendTo[forceconstants, 
      Table[makeElem[a1, i, ii, jj], {ii, 1, 3}, {jj, 1, 3}]];
     AppendTo[
      clusterIndices, {atom1positionInCluster, 
       atom2positionInCluster}];
     AppendTo[
      largeClusterIndexThingy, {atom1positionInCluster, 
       atom2positionInCluster, a1, i}];
     ];
    
    prs[[1, a1]] = Chop[pairs];
    prs[[2, a1]] = pairIndices;
    prs[[3, a1]] = pairsKvalisort;
    prs[[4, a1]] = forceconstants;
    prs[[5, a1]] = clusterIndices;
    ];
   prs[[6, 1]] = largeClusterIndexThingy;
   prs
   ];

loThirdOrderGenerateTriplets[star_, cutoff_, cluster_, uc_] := 
  Module[{na, a1, nv, distanceTable, i, j, k, vectors, triangles, 
    triangle, triangleKvalisort, vectorsKvalisort, ind, 
    triangleIndices, trianglesKvalisort, forceconstants, makeElem, 
    atom1vector, atom1vectorKvalisort, atom1positionInCluster, 
    atom2positionInCluster, atom3positionInCluster, clusterIndices, 
    str, largeClusterIndexThingy},
   na = Length[star[[3]]];
   tri = ConstantArray[{}, {6, na}];
   makeElem[a1_, i_, j_, ii_, jj_, kk_] := 
    Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "j" <> 
      ToString[j] <> "m" <> ToString[ii] <> ToString[jj] <> 
      ToString[kk]];
   largeClusterIndexThingy = {};
   For[a1 = 1, a1 <= na, a1++,
    vectors = star[[2, a1]];
    vectorsKvalisort = star[[7, a1]];
    nv = Length[vectors];
    distanceTable = 
     Table[Norm[vectors[[i]] - vectors[[j]]], {i, 1, nv}, {j, 1, 
       nv}];
    (*Empty arrays*)
    triangleIndices = {};
    triangles = {};
    trianglesKvalisort = {};
    forceconstants = {};
    clusterIndices = {};
    atom1vector = 
     Chop[DirectPositions[uc, a1].Base[uc]*LatticeConstant[uc]];
    atom1vectorKvalisort = Join[atom1vector, {star[[6, a1]]}];
    atom1positionInCluster = 
     First@Flatten[
       Position[
        loKvalisortVectorTest[#, atom1vectorKvalisort] & /@ 
         cluster[[1]], True]];
    k = 0;
    For[i = 1, i <= nv, i++,
     For[j = 1, j <= nv, j++,
       If[distanceTable[[i, j]] < cutoff,
         (*The triangle*)
         triangle = ConstantArray[0, {3, 3}];
         triangle[[1]] = {0, 0, 0};
         triangle[[2]] = vectors[[i]];
         triangle[[3]] = vectors[[j]];
         (*The indices it points to*)
         ind = {i, j};
         (*The triangle with kvalisort*)
         
         triangleKvalisort = ConstantArray[0, {3, 4}];
         triangleKvalisort[[1]] = {0, 0, 0, star[[6, a1]]};
         triangleKvalisort[[2]] = vectorsKvalisort[[i]];
         triangleKvalisort[[3]] = vectorsKvalisort[[j]];
         
         str = 
          loTriangleShiftKvalisort[
           triangleKvalisort, -atom1vectorKvalisort];
         atom2positionInCluster = 
          First@Flatten[
            Position[
             loKvalisortVectorTest[#, str[[2]]] & /@ cluster[[1]], 
             True]];
         atom3positionInCluster = 
          First@Flatten[
            Position[
             loKvalisortVectorTest[#, str[[3]]] & /@ cluster[[1]], 
             True]];
         str = {atom1positionInCluster, atom2positionInCluster, 
           atom3positionInCluster};
         k = k + 1;
         AppendTo[triangles, triangle];
         AppendTo[triangleIndices, ind];
         AppendTo[trianglesKvalisort, triangleKvalisort];
         AppendTo[forceconstants, 
          Table[makeElem[a1, i, j, ii, jj, kk], {ii, 1, 3}, {jj, 1, 
            3}, {kk, 1, 3}]];
         AppendTo[clusterIndices, str];
         AppendTo[
          largeClusterIndexThingy, {atom1positionInCluster, 
           atom2positionInCluster, atom3positionInCluster, a1, k}];
         ];
       ];
     ];
    tri[[1, a1]] = triangles;
    tri[[2, a1]] = triangleIndices;
    tri[[3, a1]] = trianglesKvalisort;
    tri[[4, a1]] = forceconstants;
    tri[[5, a1]] = clusterIndices;
    ];
   tri[[6, 1]] = largeClusterIndexThingy;
   tri
   ];

loFourthOrderGenerateTetrahedrons[star_, cutoff_, cluster_,uc_] := 
  Module[{na, a1, nv, distanceTable, i, j, k, l, vectors, 
    tetrahedrons, tetra, tetraKvalisort, vectorsKvalisort, ind, 
    tetrahedronIndices, tetrahedronsKvalisort, forceconstants, 
    makeElem, atom1vector, atom1vectorKvalisort, 
    atom1positionInCluster, atom2positionInCluster, 
    atom3positionInCluster, atom4positionInCluster, clusterIndices, 
    str, largeClusterIndexThingy},
   
   na = Length[star[[3]]];
   tet = ConstantArray[{}, {6, na}];
   
   makeElem[a1_, i_, j_, k_, ii_, jj_, kk_, ll_] := 
    Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "j" <> 
      ToString[j] <> "k" <> ToString[k] <> "m" <> ToString[ii] <> 
      ToString[jj] <> ToString[kk] <> ToString[ll]];
   
   l = 0;
   largeClusterIndexThingy={};
   For[a1 = 1, a1 <= na, a1++,
    vectors = star[[2, a1]];
    vectorsKvalisort = star[[7, a1]];
    nv = Length[vectors];
    distanceTable = 
     Table[Norm[vectors[[i]] - vectors[[j]]], {i, 1, nv}, {j, 1, 
       nv}];
    (*Empty arrays*)
    tetrahedronIndices = {};
    tetrahedrons = {};
    tetrahedronsKvalisort = {};
    forceconstants = {};
    clusterIndices = {};
    atom1vector = 
     Chop[DirectPositions[uc, a1].Base[uc]*LatticeConstant[uc]];
    atom1vectorKvalisort = Join[atom1vector, {star[[6, a1]]}];
    atom1positionInCluster = 
     First@Flatten[
       Position[
        loKvalisortVectorTest[#, atom1vectorKvalisort] & /@ 
         cluster[[1]], True]];
    
    For[i = 1, i <= nv, i++, 
     For[j = 1, j <= nv, j++, 
       For[k = 1, k <= nv, k++, 
         If[distanceTable[[i, j]] < cutoff && 
            distanceTable[[j, k]] < cutoff && 
            distanceTable[[k, i]] < cutoff,
           (*The tetrahedron*)
       
           tetra = ConstantArray[0, {4, 3}];
           tetra[[1]] = {0, 0, 0};
           tetra[[2]] = vectors[[i]];
           tetra[[3]] = vectors[[j]];
           tetra[[4]] = vectors[[k]];
           (*The indices it points to*)
           ind = {i, j, k};
           (*The tetrahedron with kvalisort*)
           
           tetraKvalisort = ConstantArray[0, {4, 4}];
           tetraKvalisort[[1]] = {0, 0, 0, star[[6, a1]]};
           tetraKvalisort[[2]] = vectorsKvalisort[[i]];
           tetraKvalisort[[3]] = vectorsKvalisort[[j]];
           tetraKvalisort[[4]] = vectorsKvalisort[[k]];
           
           
           str = loClusterShiftKvalisort[
             tetraKvalisort, -atom1vectorKvalisort];
           
           atom2positionInCluster = 
            First@Flatten[
              Position[
               loKvalisortVectorTest[#, str[[2]]] & /@ cluster[[1]], 
               True]];
           
           atom3positionInCluster = 
            First@Flatten[
              Position[
               loKvalisortVectorTest[#, str[[3]]] & /@ cluster[[1]], 
               True]];
           
           atom4positionInCluster = 
            First@Flatten[
              Position[
               loKvalisortVectorTest[#, str[[4]]] & /@ cluster[[1]], 
               True]];
           
           str = {atom1positionInCluster, atom2positionInCluster, 
             atom3positionInCluster, atom4positionInCluster};
           l = l + 1;
           AppendTo[tetrahedrons, tetra];
           AppendTo[tetrahedronIndices, ind];
           AppendTo[tetrahedronsKvalisort, tetraKvalisort];
           
           AppendTo[forceconstants, 
            Table[makeElem[a1, i, j, k, ii, jj, kk, ll], {ii, 1, 
              3}, {jj, 1, 3}, {kk, 1, 3}, {ll, 1, 3}]];
           AppendTo[clusterIndices, str];
           
           AppendTo[
            largeClusterIndexThingy, {atom1positionInCluster, 
             atom2positionInCluster, atom3positionInCluster, 
             atom4positionInCluster, a1, l}];
           
           ];
         ];
       ];
     ];
    
    tet[[1, a1]] = tetrahedrons;
    tet[[2, a1]] = tetrahedronIndices;
    tet[[3, a1]] = tetrahedronsKvalisort;
    tet[[4, a1]] = forceconstants;
    tet[[5, a1]] = clusterIndices;
   ];
   tet[[6,1]]=largeClusterIndexThingy;
   tet
  ];

(*loSecondOrderGeneratePairs[star_, cutoff_] := Module[
   {na, pairs, makeElem, a1, i, vectors, vectorsKvalisort, nv, 
    pairIndices, pairsKvalisort, forceconstants, pair, ind, 
    pairKvalisort},
   
   na = Length[star[[3]]];
   prs = ConstantArray[{}, {4, na}];
   
   makeElem[a1_, i_, ii_, jj_] := 
    Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "m" <> 
      ToString[ii] <> ToString[jj]];
   
   For[a1 = 1, a1 <= na, a1++,
    vectors = star[[2, a1]];
    vectorsKvalisort = star[[7, a1]];
    nv = Length[vectors];
    
    (* Empty arrays *)
    pairIndices = {};
    pairs = {};
    pairsKvalisort = {};
    forceconstants = {};
    For[i = 1, i <= nv, i++,
     (* The vector *)
     pair = ConstantArray[0, {2, 3}];
     pair = vectors[[i]];
     (* The indices it points to *)
     ind = star[[1, a1]][[i]];
     (* The vector with kvalisort *)
     
     pairKvalisort = star[[7, a1]][[i]];
     
     AppendTo[pairs, pair];
     AppendTo[pairIndices, ind];
     AppendTo[pairsKvalisort, pairKvalisort];
     AppendTo[forceconstants,
      Table[makeElem[a1, i, ii, jj], {ii, 1, 3}, {jj, 1, 3}]
      ];
     ];
    prs[[1, a1]] = pairs;
    prs[[2, a1]] = pairIndices;
    prs[[3, a1]] = pairsKvalisort;
    prs[[4, a1]] = forceconstants;
    ];
   prs
   ];

loThirdOrderGenerateTriplets[star_, cutoff_] := Module[
   {na, a1, nv, distanceTable, i, j, k, vectors, triangles, triangle, 
    triangleKvalisort, vectorsKvalisort, ind, triangleIndices, 
    trianglesKvalisort, forceconstants, makeElem},
   na = Length[star[[3]]];
   tri = ConstantArray[{}, {4, na}];
   
   makeElem[a1_, i_, j_, ii_, jj_, kk_] := 
    Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "j" <> 
      ToString[j] <> "m" <> ToString[ii] <> ToString[jj] <> 
      ToString[kk]];
   
   
   For[a1 = 1, a1 <= na, a1++,
    vectors = star[[2, a1]];
    vectorsKvalisort = star[[7, a1]];
    nv = Length[vectors];
    
    distanceTable = 
     Table[Norm[vectors[[i]] - vectors[[j]]], {i, 1, nv}, {j, 1, 
       nv}];
    (* Empty arrays *)
    triangleIndices = {};
    triangles = {};
    trianglesKvalisort = {};
    forceconstants = {};
    For[i = 1, i <= nv, i++,
     For[j = 1, j <= nv, j++,
       If[distanceTable[[i, j]] < cutoff,
         (* The triangle *)
         
         triangle = ConstantArray[0, {3, 3}];
         triangle[[1]] = {0, 0, 0};
         triangle[[2]] = vectors[[i]];
         triangle[[3]] = vectors[[j]];
         (* The indices it points to *)
         ind = {i, j};
         (* The triangle with kvalisort *)
         
         triangleKvalisort = ConstantArray[0, {3, 4}];
         triangleKvalisort[[1]] = {0, 0, 0, star[[6, a1]]};
         triangleKvalisort[[2]] = vectorsKvalisort[[i]];
         triangleKvalisort[[3]] = vectorsKvalisort[[j]];
         
         AppendTo[triangles, triangle];
         AppendTo[triangleIndices, ind];
         AppendTo[trianglesKvalisort, triangleKvalisort];
         AppendTo[forceconstants,
          
          Table[makeElem[a1, i, j, ii, jj, kk], {ii, 1, 3}, {jj, 1, 
            3}, {kk, 1, 3}]
          ];
         ];
       ];
     ];
    tri[[1, a1]] = triangles;
    tri[[2, a1]] = triangleIndices;
    tri[[3, a1]] = trianglesKvalisort;
    tri[[4, a1]] = forceconstants;
    ];
   tri
   ];

loFourthOrderGenerateTetrahedrons[star_, cutoff_] := Module[
   {na, a1, nv, distanceTable, i, j, k, vectors, tetrahedrons, tetra, 
    tetraKvalisort, vectorsKvalisort, ind, tetrahedronIndices, 
    tetrahedronsKvalisort, forceconstants, makeElem},
   na = Length[star[[3]]];
   tet = ConstantArray[{}, {4, na}];
   
   makeElem[a1_, i_, j_, k_, ii_, jj_, kk_, ll_] := 
    Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "j" <> 
      ToString[j] <> "k" <> ToString[k] <> "m" <> ToString[ii] <> 
      ToString[jj] <> ToString[kk] <> ToString[ll]];
   
   For[a1 = 1, a1 <= na, a1++,
    vectors = star[[2, a1]];
    vectorsKvalisort = star[[7, a1]];
    nv = Length[vectors];
    
    distanceTable = 
     Table[Norm[vectors[[i]] - vectors[[j]]], {i, 1, nv}, {j, 1, 
       nv}];
    (* Empty arrays *)
    tetrahedronIndices = {};
    tetrahedrons = {};
    tetrahedronsKvalisort = {};
    forceconstants = {};
    For[i = 1, i <= nv, i++,
     For[j = 1, j <= nv, j++,
       For[k = 1, k <= nv, k++,
         If[
           distanceTable[[i, j]] < cutoff &&
            
            distanceTable[[j, k]] < cutoff &&
            
            distanceTable[[k, i]] < cutoff,
           (* The tetrahedron *)
           
           tetra = ConstantArray[0, {4, 3}];
           tetra[[1]] = {0, 0, 0};
           tetra[[2]] = vectors[[i]];
           tetra[[3]] = vectors[[j]];
           tetra[[4]] = vectors[[k]];
           (* The indices it points to *)
           ind = {i, j, k};
           (* The tetrahedron with kvalisort *)
           
           tetraKvalisort = ConstantArray[0, {4, 4}];
           tetraKvalisort[[1]] = {0, 0, 0, star[[6, a1]]};
           tetraKvalisort[[2]] = vectorsKvalisort[[i]];
           tetraKvalisort[[3]] = vectorsKvalisort[[j]];
           tetraKvalisort[[4]] = vectorsKvalisort[[k]];
           
           AppendTo[tetrahedrons, tetra];
           AppendTo[tetrahedronIndices, ind];
           AppendTo[tetrahedronsKvalisort, tetraKvalisort];
           AppendTo[forceconstants,
            
            Table[makeElem[a1, i, j, k, ii, jj, kk, ll], {ii, 1, 
              3}, {jj, 1, 3}, {kk, 1, 3}, {ll, 1, 3}]
            ];
           ];
         ];
       ];
     ];
    tet[[1, a1]] = tetrahedrons;
    tet[[2, a1]] = tetrahedronIndices;
    tet[[3, a1]] = tetrahedronsKvalisort;
    tet[[4, a1]] = forceconstants;
    ];
   tet
   ];*)

(* OLD BORING STUFF

loSecondOrderBuildSmallForceConstants[unitcell_, cutoff_] := Module[
   {unitcellCutoff, supercellradius, lattice, na, base, pos, indices, 
    vectors, matrices, makeElem, i, j, k, Rij, Rc, a1, a2, v, nv, 
    fc},
   (* generate a lattice *)
   
   unitcellCutoff = loMaxCutoff[unitcell];
   supercellradius = Ceiling[(cutoff/unitcellCutoff - 1)/2]+2;
   lattice = 
    Sort[Tuples[Range[-supercellradius, supercellradius, 1], {3}], 
     SquaredEuclideanDistance[#1, {0, 0, 0}] < 
       SquaredEuclideanDistance[#2, {0, 0, 0}] &];
   
   (* shortcuts *)
   na = Total[NumberOfElements[unitcell]];
   base = Base[unitcell]*LatticeConstant[unitcell];
   pos = DirectPositions[unitcell];
   
   (* Construct a variable *)
   
   makeElem[a1_, a2_, v_, i_, j_] := 
    Symbol["fcsa" <> ToString[a1] <> "a" <> ToString[a2] <> "v" <> 
      ToString[v] <> "m" <> ToString[i] <> ToString[j]];
   
   fc = ConstantArray[{}, {3, na}];
   For[a1 = 1, a1 <= na, a1++,
    vectors = {};
    indices = {};
    matrices = {};
    For[a2 = 1, a2 <= na, a2++,
     For[k = 1, k <= Length[lattice], k++,
      Rc = lattice[[k]].base;
      Rij = (pos[[a2]] - pos[[a1]] + lattice[[k]]).base;
      If[EuclideanDistance[Rij, {0, 0, 0}] < cutoff,
       AppendTo[vectors, Rij];
       AppendTo[indices, a2];
       ];
      ];
     nv = Length[indices];
     matrices = ConstantArray[0, {nv, 3, 3}];
     matrices = 
      Table[makeElem[a1, indices[[v]], v, i, j], {v, 1, nv}, {i, 1, 
        3}, {j, 1, 3}];
     ];
    fc[[1, a1]] = indices;
    fc[[2, a1]] = vectors;
    fc[[3, a1]] = matrices;
          ];
   SmallForceConstant = fc
     ];

loCountUnknownThirdorder[smallfc_[indices_, vectors_, matrices_]] := 
  Module[{na, a1, fc},
   na = Length[indices];
   fc = ConstantArray[{}, {na}];
   For[a1 = 1, a1 <= na, a1++,
    fc[[a1]] = matrices[[a1]][[3]];
    ];
   Length[
    Union[Flatten[
      fc /. {x_ /; NumberQ[x] -> Sequence[], Plus -> List}]]]
   ];
loThirdOrderBuildSmallForceConstants[unitcell_, cutoff_] := Module[
   {unitcellCutoff, supercellradius, lattice, a1, a2, a3, t, i, j, k, 
    na, base, pos, makeElem, fc, vectors, indices, matrices, Rij, nv, 
    tripletIndices, alltriangles, triangles, triangleIndices, 
    forceconstants, triangleSpecies, i1, i2, i3, l, m, ii, jj, kk},
   (*generate a lattice*)
   unitcellCutoff = loMaxCutoff[unitcell];
   supercellradius = Ceiling[(cutoff/unitcellCutoff - 1)/2] + 1;
   lattice = 
    Sort[Tuples[Range[-supercellradius, supercellradius, 1], {3}], 
     SquaredEuclideanDistance[#1, {0, 0, 0}] < 
       SquaredEuclideanDistance[#2, {0, 0, 0}] &];
   (*shortcuts*)
   na = Total[NumberOfElements[unitcell]];
   base = Base[unitcell]*LatticeConstant[unitcell];
   pos = DirectPositions[unitcell];
   (*Construct a variable*)
   
   makeElem[a1_, a2_, a3_, t_, i_, j_, k_] := 
    Symbol["t" <> ToString[a1] <> "a" <> ToString[a2] <> "a" <> 
      ToString[a3] <> "t" <> ToString[t] <> "e" <> ToString[i] <> 
      ToString[j] <> ToString[k]];
   fc = ConstantArray[{}, {3, na}];
   (*Konstruera om från början*)
   l = 0;
   For[a1 = 1, a1 <= na, a1++,
    vectors = {};
    indices = {};
    matrices = {};
    (*get list of vectors*)
    For[a2 = 1, a2 <= na, a2++, 
     For[k = 1, k <= Length[lattice], k++, 
      Rij = (pos[[a2]] - pos[[a1]] + lattice[[k]]).base;
      If[EuclideanDistance[Rij, {0, 0, 0}] < cutoff, 
       AppendTo[vectors, Rij];
       AppendTo[indices, a2];];];
     (*get all triangles*)
     nv = Length[indices];
     tripletIndices = Tuples[Range[1, nv], {2}];
     alltriangles = 
      Chop[Table[
        Join[{{0, 0, 0}}, vectors[[tripletIndices[[i]]]]], {i, 1, 
         Length[tripletIndices]}]];
     triangles = {};
     triangleIndices = {};
     forceconstants = {};
     triangleSpecies = {};
     (*Sort out the relevant triangles*)
     For[i = 1, i <= Length[alltriangles], i++, 
      If[Norm[alltriangles[[i, 1]] - alltriangles[[i, 2]]] < cutoff &&
          Norm[alltriangles[[i, 1]] - alltriangles[[i, 3]]] < cutoff &&
          Norm[alltriangles[[i, 3]] - alltriangles[[i, 2]]] < 
          cutoff,
        (*Then it is an ok triangle*)
        
        i1 = a1;(*first index*)
        
        i2 = indices[[tripletIndices[[i, 1]]]];(*second index*)
        i3 = indices[[tripletIndices[[i, 2]]]];(*third index*)
       
         l = l + 1;
        m = 
         Table[makeElem[i1, i2, i3, l, ii, jj, kk], {ii, 1, 3}, {jj, 
           1, 3}, {kk, 1, 3}];
        AppendTo[triangles, alltriangles[[i]]];
        AppendTo[triangleIndices, tripletIndices[[i]]];
        AppendTo[forceconstants, m];
        AppendTo[triangleSpecies, 
         Elements[unitcell, #] & /@ {i1, i2, i3}];
        ];
      ];
     matrices = {triangles, triangleIndices, forceconstants, 
       triangleSpecies};
     fc[[1, a1]] = indices;
     fc[[2, a1]] = vectors;
     fc[[3, a1]] = matrices;
     ];
    ];
   SmallForceConstant = fc
   ];

*)
