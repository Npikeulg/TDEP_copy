(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loReadSymmetryOperationsFromFile::usage=""
loBuildUniquePairForceconstant::usage=""
loPointSymmetryUnique::usage=""
loTransposeSymmetryUnique::usage=""
loBuildStandardPairFormat::usage=""
loBuildLargePairFormat::usage=""
loUniqueAcousticSumRules::usage=""
loBuildUniqueTripletForceconstant::usage=""
loTripletTransposeSymmetryUnique::usage=""
loTripletPointSymmetryUnique::usage=""
loTripletUniqueAcousticSumRules::usage=""
loBuildStandardTripletFormat::usage=""
loBuildLargeTripletFormat::usage=""
loBuildUniqueQuartetForceconstant::usage=""
loQuartetTransposeSymmetryUnique::usage=""
loQuartetPointSymmetryUnique::usage=""
loQuartetUniqueAcousticSumRules::usage=""
loBuildStandardQuartetFormat::usage=""
loBuildLargeQuartetFormat::usage=""
loBuildLargePairFormatAlloyExpansion::usage=""
loBuildUniqueSingletForceconstant::usage=""
loSingletPointSymmetryUnique::usage=""
loBuildStandardSingletFormat::usage=""
loNewFirstOrderGetForceExpression::usage=""
loTripletASR::usage=""
loQuartetASR::usage=""
loHuangInvarianceUnique::usage=""
loBuildUniquePairJij::usage=""
loBuildStandardPairMagFormat::usage=""
loSimplifySecondorder::usage=""
loSimplifyThirdorder::usage=""
loSimplifyFourthorder::usage=""
loAnalyticalMatrixelement::usage=""
loPrintMatrixelementCode::usage=""
End[];

loPrintMatrixelementCode[tria_,psi_, uc_] := Module[
   {uniqeVariables, phiRulesVar, fullexpression, s0, s1, s2, 
    listOfIntermediateVariables, declareEigenvectors, 
    declareIntermediate, declareMasses, declarePhi, declareQvectors, 
    codeEigenvectors, codeIntermediate, codeMasses, codePhi, 
    codeQvectors, header, footer, replaceIntermedieateRules, i, ll, 
    nphi, a1, na, allthecode, u, l},
   (* Chop up analytical matrix element *)
   
   na = Dimensions[tria][[2]];
   uniqeVariables = 
    Union[Flatten[
      tria[[4]] /. {x_ /; NumberQ[x] -> Sequence[], Plus -> List}]];
   phiRulesVar = 
    Table[uniqeVariables[[i]] -> Symbol["phi" <> ToString[i]], {i, 1, 
      Length[uniqeVariables]}];
   fullexpression = 
    ToString[
     Experimental`OptimizeExpression[
       Simplify[ExpToTrig[psi]] /. phiRulesVar] // InputForm];
   (* Start working on the string to make it into Fortran code *)
   
   s0 = StringReplace[
     fullexpression, {";" -> "\n", 
      "Experimental`OptimizedExpression[Block[" -> "", "]]" -> ""}];
   s1 = StringSplit[s0, "}, "][[1]]; (* declaration header *)
   
   s2 = StringSplit[s0, "}, "][[2]];(* actual expression *)
   (* 
   list of intermediate variables *)
   
   listOfIntermediateVariables = 
    StringCases[s1, RegularExpression["Compile`\$[0-9]*"]];
   (* replacement rules *)
   declareIntermediate = "";
   replaceIntermedieateRules = {};
   For[i = 1, i <= Length[listOfIntermediateVariables], i++,
    AppendTo[replaceIntermedieateRules, 
     listOfIntermediateVariables[[i]] -> "dc" <> ToString[i]];
    declareIntermediate = 
     declareIntermediate <> "complex(flyt) :: dc" <> ToString[i] <> 
      "\n";
    ];
   (* Apply the rules backwards to not get weird stuff. *)
   
   For[i = Length[replaceIntermedieateRules], i >= 1, i--,
    s2 = StringReplace[s2, replaceIntermedieateRules[[i]]];
    ];
   (* Fix some special characters *)
   
   s2 = StringReplace[
     s2, {"[" -> "(", "]" -> ")", "I" -> "lo_imag", "^" -> "**"}];
   (* Work on the last line *)
   ll = StringSplit[s2, "\n"];
   ll[[Length[ll]]] = 
    "psi = " <> 
     ToString[InputForm[Together[ToExpression[ll[[Length[ll]]]]]]];
   (* make it code again *)
   codeIntermediate = "\n";
   For[i = 1, i <= Length[ll], i++,
    codeIntermediate = codeIntermediate <> ll[[i]] <> "\n";
    ];
   nphi = Length[uniqeVariables];
   declarePhi = "\n";
   codePhi = "\n";
   For[i = 1, i <= nphi, i++,
    codePhi = 
     codePhi <> "phi" <> ToString[i] <> " = irrphi(" <> ToString[i] <>
       ")\n";
    declarePhi = 
     declarePhi <> "real(flyt) :: phi" <> ToString[i] <> "\n";
    ];
   (* Start printing code *)
   
   declareQvectors = "\nreal(flyt) :: q2x,q2y,q2z,q3x,q3y,q3z \n";
   codeQvectors = "
    q2x=q2(1)
    q2y=q2(2)
    q2z=q2(3)
    q3x=q3(1)
    q3y=q3(2)
    q3z=q3(3)
    ";
   
   (* Eigenvectors *)
   declareEigenvectors = "\n";
   codeEigenvectors = "\n";
   l = 0;
   For[a1 = 1, a1 <= na, a1++,
    For[i = 1, i <= 3, i++,
      l = l + 1;
      declareEigenvectors = 
       declareEigenvectors <> "complex(flyt) :: e1" <> ToString[a1] <>
         ToString[i] <> "\n";
      declareEigenvectors = 
       declareEigenvectors <> "complex(flyt) :: e2" <> ToString[a1] <>
         ToString[i] <> "\n";
      declareEigenvectors = 
       declareEigenvectors <> "complex(flyt) :: e3" <> ToString[a1] <>
         ToString[i] <> "\n";
      codeEigenvectors = 
       codeEigenvectors <> "e1" <> ToString[a1] <> ToString[i] <> 
        "=egv(" <> ToString[l] <> ",1)" <> "\n";
      codeEigenvectors = 
       codeEigenvectors <> "e2" <> ToString[a1] <> ToString[i] <> 
        "=egv(" <> ToString[l] <> ",2)" <> "\n";
      codeEigenvectors = 
       codeEigenvectors <> "e3" <> ToString[a1] <> ToString[i] <> 
        "=egv(" <> ToString[l] <> ",3)" <> "\n";
      ];
    ];
   (* masses *)
   declareMasses = "\n";
   codeMasses = "\n";
   For[a1 = 1, a1 <= na, a1++,
    declareMasses = 
     declareMasses <> "real(flyt) :: m" <> ToString[a1] <> "\n";
    codeMasses = 
     codeMasses <> "m" <> ToString[a1] <> "=invsqrtmass(" <> 
      ToString[a1] <> ")" <> "\n";
    ];
   
   header = "module fastmatrixelements
        use constants
        implicit none
    contains
    
    !> superfast matrix elements, procedurally generated
    function \
fast_scattering_strength(invsqrtmass,omega,egv,q2,q3,irrphi) \
result(psi)
        !> the list of inverse sqrt masses
        real(flyt), dimension(:), intent(in) :: invsqrtmass
        !> the frequencies and q-vectors, in fractional coordinates
        real(flyt), dimension(3), intent(in) :: omega,q2,q3
        !> the eigenvectors
        complex(flyt), dimension(:,:), intent(in) :: egv
        !> the irreducible forceconstants
        real(flyt), dimension(:), intent(in) :: irrphi
        !> the resulting matrix element
        complex(flyt) :: psi
    ";
   footer = "! finally, fix the unit and the omegas
        psi=psi*2.367755374064161E51_flyt/sqrt(product(omega))
    end function
    
    end module
    ";
   allthecode = 
    header <> declareIntermediate <> declareEigenvectors <> 
     declareQvectors <> declareMasses <> declarePhi <> codeQvectors <>
      codeMasses <> codeEigenvectors <> codePhi <> codeIntermediate <>
      footer;
   u = OpenWrite["fastmatrixelements.f90"];
   WriteString[u, allthecode];
   Close[u];
   ];

loAnalyticalMatrixelement[tria_, uc_] := Module[
   {na, invbas, latticeVector2, latticeVector3, atind, forceconstants,
     a1, a2, a3, v, nv, ucvec, pv2, pv3, eigenvector1, eigenvector2, 
    eigenvector3, q2, q3, imass, ntri, expiqr, massterm, f0, psi,j,k,t},
   na = Dimensions[tria][[2]];
   invbas = Chop[Inverse[Base[uc]*LatticeConstant[uc]]];
   (* Sort the analytical forceconstant into different things *)
   
   atind = {};
   latticeVector2 = {};
   latticeVector3 = {};
   forceconstants = {};
   For[a1 = 1, a1 <= na, a1++,
    nv = Dimensions[tria[[1, a1]]][[1]];
    For[v = 1, v <= nv, v++,
     (* Atom indices *)
     a2 = tria[[2, a1]][[v]][[1]];
     a3 = tria[[2, a1]][[v]][[2]];
     AppendTo[atind, {a1, a2, a3}];
     (* The pair vectors *)
     
     ucvec = (Positions[uc, a2] - Positions[uc, a1]);
     pv2 = tria[[1, a1]][[v]][[2]] - ucvec;
     ucvec = (Positions[uc, a3] - Positions[uc, a1]);
     pv3 = tria[[1, a1]][[v]][[3]] - ucvec;
     AppendTo[latticeVector2, RootApproximant[ Chop[pv2.invbas]]];
     AppendTo[latticeVector3, RootApproximant[ Chop[pv3.invbas]]];
     (* The actual forceconstants *)
     
     AppendTo[forceconstants, tria[[4, a1]][[v]]];
     ];
    ];
   (* A table with the eigenvectors *)
   
   eigenvector1 = 
    Table[Symbol["e1" <> ToString[a1] <> ToString[i]], {a1, 1, 
      na}, {i, 1, 3}];
   eigenvector2 = 
    Table[Symbol["e2" <> ToString[a1] <> ToString[i]], {a1, 1, 
      na}, {i, 1, 3}];
   eigenvector3 = 
    Table[Symbol["e3" <> ToString[a1] <> ToString[i]], {a1, 1, 
      na}, {i, 1, 3}];
   (* Two general q-vectors *)
   q2 = {Symbol["q2x"],Symbol["q2y"],Symbol["q2z"]};
   q3 = {Symbol["q3x"],Symbol["q3y"],Symbol["q3z"]};
   (*q2 = {q2x, q2y, q2z};
   q3 = {q3x, q3y, q3z};*)
   (* inv sqrt of masses *)
   
   imass = Table[Symbol["m" <> ToString[a1]], {a1, 1, na}];
   
   (* Put this together to a matrix element *)
   
   ntri = Length[forceconstants];
   psi = 0;
   For[t = 1, t <= ntri, t++,
    a1 = atind[[t, 1]];
    a2 = atind[[t, 2]];
    a3 = atind[[t, 3]];
    (* exponent term *)
    
    expiqr = 
     Exp[I*(q2.latticeVector2[[t]] + q3.latticeVector3[[t]])];
    (* mass term *)
    massterm = imass[[a1]]*imass[[a2]]*imass[[a3]];
    (* eigenvector term *)
    
    f0 = Sum[
      eigenvector1[[a1, i]]*eigenvector2[[a2, j]]*
       eigenvector3[[a3, k]]*forceconstants[[t, i, j, k]], {i, 1, 
       3}, {j, 1, 3}, {k, 1, 3}];
    psi = psi + f0*expiqr*massterm;
    ];
   (* Return the matrix element *)
   psi
];

loBuildUniquePairJij := Module[
    {makeElem, i, ii, jj, na, d, dd, nkvalisort, a1, nv, shell},
    (*Construct the minimum number of force constants*)
   makeElem[a1_, i_, ii_, jj_] := 
    Symbol["tjij" <> ToString[a1] <> "i" <> ToString[i] <> "m" <> 
      ToString[ii] <> ToString[jj]];
   d = Import["mathoutfile.unique_representation_magnetic", "Table"];
   dd = SplitBy[d, First];
   nkvalisort = Length[dd];
   unfc = ConstantArray[{}, {2, nkvalisort}];
   For[a1 = 1, a1 <= nkvalisort, a1++,
    (*Store the vectors*)
    
    unfc[[1, a1]] = Chop[dd[[a1]][[;; , 2 ;; 4]]];
    (*What kind of coordination shell *)
    
    shell = Chop[dd[[a1]][[;; , 5]]];
    (*Get forceconstants*)
    nv = Length[unfc[[1, a1]]];
    unfc[[2, a1]] = 
     Table[makeElem[a1, shell[[i]], ii, jj], {i, 1, nv}, {ii, 1, 
       3}, {jj, 1, 3}];
    ];
   unfc];

loReadSymmetryOperationsFromFile := Module[
   {ll, nops, l, i, j, k},
   (* My fortran code dumps the symmetry operations *)
   
   ll = Import["mathoutfile.symmetryoperations", "Table"];
   nops = First@Dimensions[ll, 1]/3;
   ops = ConstantArray[0, {nops, 3, 3}];
   l = 0;
    For[i = 1, i <= nops, i++,
    For[j = 1, j <= 3, j++,
        l = l + 1;
        For[k = 1, k <= 3, k++,
            ops[[i, j, k]] = Chop[ll[[l, k]]];
            (* Added small safety check if someone has too few significant digits in the POSCAR *)
            If[ Abs[ops[[i, j, k]]-Sqrt[3]/2] < 0.0001,
                ops[[i,j,k]]=Sqrt[3]/2;
            ]
            If[ Abs[ops[[i, j, k]]+Sqrt[3]/2] < 0.0001,
                ops[[i,j,k]]=-Sqrt[3]/2;
            ]

        ];
    ];
    (* Mathematica - Fortran difference *)
    ops[[i]]=Transpose[ops[[i]]];
    ];
   ops = RootApproximant[Chop[ops]]
   ];

loBuildUniqueSingletForceconstant := Module[
   {makeElem, i, ii, jj, na, d, dd, nkvalisort, a1, nv},
   (* Construct the minimum number of force constants *)
   
   makeElem[a1_, i_] := Symbol["sfc" <> ToString[a1] <> "m" <> ToString[i]];
   
   d = Import["mathoutfile.unique_representation_singlet", "Table"];
   na=First@Flatten[d];
   unfc=Table[ makeElem[a1,i],{a1,1,na},{i,1,3} ];
   unfc
    ];

loSingletPointSymmetryUnique[unfc_, op_] := Module[
    {a1, i, k, ii, jj, m1, m2, rls, clist},
    (* Apply the point operations to the condensed forceconstant format *)
    clist = Import["mathoutfile.clist_singlet_group", "Table"];

    newfc = unfc;
    For[i = 1, i <= Length[clist], i++,
    (* For each connection *)
    a1 = clist[[i, 1]];
    k = clist[[i, 2]];
    (* var tvungen flippa ii och jj här *)

    m1 = loApplySymopToTensor[newfc[[a1]], op[[k]], 1];
    m2 = newfc[[a1]];
    rls = Flatten[Solve[m2 == m1]];
    newfc = newfc /. rls;
    ];
    newfc
];

loBuildStandardSingletFormat[fc_, ops_] := Module[
   {d, na, a1, mats, i, ii, k},

   d = Import["mathoutfile.unitcell_representation_singlet", "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   prs = ConstantArray[{}, {4, na}];

   For[a1 = 1, a1 <= na, a1++,
      ii=Flatten[d[[a1]]];
      i=ii[[3]];
      k=ii[[2]];
      mats=loApplySymopToTensor[fc[[i]],ops[[k]],1];
      prs[[4,a1]]=mats;
   ];

   prs
   ];

loNewFirstOrderGetForceExpression[fc_, ops_] := Module[
   {d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k},

   d = Import["mathoutfile.supercell_representation_singlet", "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   forces = ConstantArray[0, {3*na}];

   l=0;
   For[a1 = 1, a1 <= na, a1++,
      ii=Flatten[d[[a1]]];
      i=ii[[3]];
      k=ii[[2]];
      mats=loApplySymopToTensor[fc[[i]],ops[[k]],1];
      For[i=1,i<=3,i++,
         l=l+1;
         forces[[l]]=mats[[i]]*"y";
      ];
   ];

   forces
   ];


loBuildUniquePairForceconstant := Module[
   {makeElem, i, ii, jj, na, d, dd, nkvalisort, a1, nv},
   (* Construct the minimum number of force constants *)
   
   makeElem[a1_, i_, ii_, jj_] := 
    Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "m" <> 
      ToString[ii] <> ToString[jj]];
   
   d = Import["mathoutfile.unique_representation", "Table"];
   dd = SplitBy[d, First];
   
   nkvalisort = Length[dd];
   unfc = ConstantArray[{}, {2, nkvalisort}];
   For[a1 = 1, a1 <= nkvalisort, a1++,
    (* Store the vectors *)
    
    unfc[[1, a1]] = Chop[dd[[a1]][[;; , 2 ;; 4]]];
    (* Get forceconstants *)
    nv = Length[unfc[[1, a1]]];
    unfc[[2, a1]] = 
     Table[makeElem[a1, i, ii, jj], {i, 1, nv}, {ii, 1, 3}, {jj, 1,  3}];
   (* For[i=1,i<=nv,i++,
        unfc[[2, a1]][[i]]=unfc[[2, a1]][[i]]*dd[[a1]][[i,5]];
    ];*)
    ];
   unfc
   ];

loPointSymmetryUnique[unfc_, op_] := Module[
    {a1, i, k, ii, jj, m1, m2, rls, clist},
    (* Apply the point operations to the condensed forceconstant format *)
    clist = Import["mathoutfile.clist_pair_group", "Table"];

    newfc = unfc;
    For[i = 1, i <= Length[clist], i++,
        (* For each connection *)
        a1 = clist[[i, 1]];
        k = clist[[i, 2]];
        ii = clist[[i, 3]];
        jj = clist[[i, 4]];
        (* var tvungen flippa ii och jj här *)

        m1 = loApplySymopToTensor[newfc[[2, a1]][[ii]], op[[k]], 2];
        m2 = newfc[[2, a1]][[jj]];
        rls = Flatten[Solve[m2 == m1]];
        newfc = newfc /. rls;
        (* Speed things up by simplifying every once in a while *)
        If[Mod[i,20]==0,
            newfc=loSimplifySecondorder[newfc];
        ];
    ];
    newfc=loSimplifySecondorder[newfc]
];

loSimplifySecondorder[fc_] := Module[
   {na, nt, a1, k},
   newfc = fc;
   na = Dimensions[newfc][[2]];
   For[a1 = 1, a1 <= na, a1++,
    nt = Dimensions[newfc[[2, a1]]][[1]];
    For[k = 1, k <= nt, k++,
     newfc[[2, a1]][[k]] = Expand[Simplify[fc[[2, a1]][[k]]]];
     ];
    ];
   newfc
   ];


loTransposeSymmetryUnique[unfc_, op_] := Module[
   {a1, a2, i, i1, i2, o1, o2, m1, m2, rls, clist},
   (* Apply the point operations to the condensed forceconstant format *)
   clist = Import["mathoutfile.clist_pair_transpose", "Table"];
   
   newfc = unfc;
   For[i = 1, i <= Length[clist], i++,
    (* For each connection *)
    a1 = clist[[i, 1]];
    a2 = clist[[i, 2]];
    i1 = clist[[i, 3]];
    i2 = clist[[i, 4]];
    o1 = clist[[i, 5]];
    o2 = clist[[i, 6]];
    m1 = loApplySymopToTensor[newfc[[2, a1]][[i1]], op[[o1]], 2];
    m2 = loApplySymopToTensor[newfc[[2, a2]][[i2]], op[[o2]], 2];
    rls = Flatten[Solve[m1 == TensorTranspose[m2, {2, 1}]]];
    newfc = newfc /. rls;

(*
    Brute force impose transposition symmetry 
    rls = Flatten[Solve[m1 == TensorTranspose[m1, {2, 1}]]];
    newfc = newfc /. rls;
*)
    ];
   newfc
   ];

loHuangInvarianceUnique[fc_,ops_] := Module[
    {d, na, a1, nv, i, ii, jj, k, wt, mat, rls, vec, bracket, irrfc, CA}, 
    d = Import["mathoutfile.unitcell_representation", "Table"];
    d = SplitBy[d, First];
    na = Length[d];
    bracket = ConstantArray[0, {3, 3, 3, 3}];
    For[a1 = 1, a1 <= na, a1++,
     nv = Length[d[[a1]]];
     For[i = 1, i <= nv, i++,
      (* Irreducible index *)
      ii = d[[a1]][[i, 3]];
      (* Unitcell index *)
      kk = d[[a1]][[i, 5]];
      (* Vector index *)
      jj = d[[a1]][[i, 4]];
      (* Which operation *)
      k = d[[a1]][[i, 2]];
      (* The weight for future reference *)
      wt = d[[a1]][[i, 6]];
      (* Get the Cartesian vector *)
      vec = Chop[loApplySymopToTensor[fc[[1, ii]][[jj]], ops[[k]], 1]];
      (* And the force constant *)
      mat = loApplySymopToTensor[fc[[2, ii]][[jj]], ops[[k]], 2];
      (* bracket thingy *)
      bracket = 
       bracket + 
        Table[mat[[\[Alpha], \[Beta]]]*vec[[\[Gamma]]]*
          vec[[\[Lambda]]], {\[Alpha], 1, 3}, {\[Beta], 1, 3}, {\[Gamma], 
          1, 3}, {\[Lambda], 1, 3}];
      ];
     ];
    (* Get the relations in a smart way *)
    irrfc = loListOfUnknown[{0, 0, 0, fc}];
    CA = CoefficientArrays[Flatten[bracket - TensorTranspose[bracket, {3, 4, 1, 2}]], irrfc];
    (* Not in sparse stupid format *)
    If[Dimensions[CA][[1]]>1,
        CA = CA[[2]] // Normal;
    ,
        CA = 0;
    ];
    CA
];

loBuildStandardPairFormat[fc_, ops_] := Module[
   {d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k},
   d = Import["mathoutfile.unitcell_representation", "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   prs = ConstantArray[{}, {4, na}];
   
   For[a1 = 1, a1 <= na, a1++,
    nv = Length[d[[a1]]];
    vecs = ConstantArray[0, {nv, 2, 3}];
    inds = ConstantArray[0, {nv}];
    indvecs = ConstantArray[0, {nv, 2, 4}];
    mats = ConstantArray[0, {nv, 3, 3}];    
    For[i = 1, i <= nv, i++,
     (* the operation *)
     ii = d[[a1]][[i, 3]];
     jj = d[[a1]][[i, 4]];
     k = d[[a1]][[i, 2]];
     inds[[i]] = d[[a1]][[i, 5]];
     wt = d[[a1]][[i,6]];
     vecs[[i, 1, 1 ;; 3]] = {0, 0, 0};
     vecs[[i, 2, 1 ;; 3]]=Chop[loApplySymopToTensor[fc[[1, ii]][[jj]],ops[[k]],1]];
     indvecs[[i, 1, 1 ;; 3]] = vecs[[i, 1, 1 ;; 3]];
     indvecs[[i, 2, 1 ;; 3]] = vecs[[i, 2, 1 ;; 3]];
     indvecs[[i, 1, 4]] = a1;
     indvecs[[i, 2, 4]] = inds[[i]];
     mats[[i]] = 
      loApplySymopToTensor[fc[[2, ii]][[jj]], ops[[k]], 2];
      (*loApplySymopToTensor[fc[[2, ii]][[jj]], ops[[k]], 2]/wt;*)
     ];
    prs[[1, a1]] = vecs;
    prs[[2, a1]] = inds;
    prs[[3, a1]] = indvecs;
    prs[[4, a1]] = mats;
    ];
   prs
   ];

loBuildStandardPairMagFormat[fc_, ops_] := Module[
   {d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k},
   d = Import["mathoutfile.unitcell_representation", "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   prs = ConstantArray[{}, {4, na}];
   
   For[a1 = 1, a1 <= na, a1++,
    nv = Length[d[[a1]]];
    vecs = ConstantArray[0, {nv, 2, 3}];
    inds = ConstantArray[0, {nv}];
    indvecs = ConstantArray[0, {nv, 2, 4}];
    mats = ConstantArray[0, {nv, 3, 3}];    
    For[i = 1, i <= nv, i++,
     (* the operation *)
     ii = d[[a1]][[i, 3]];
     jj = d[[a1]][[i, 4]];
     k = d[[a1]][[i, 2]];
     inds[[i]] = d[[a1]][[i, 5]];
     wt = d[[a1]][[i,6]];
     vecs[[i, 1, 1 ;; 3]] = {0, 0, 0};
     vecs[[i, 2, 1 ;; 3]]=Chop[loApplySymopToTensor[fc[[1, ii]][[jj]],ops[[k]],1]];
     indvecs[[i, 1, 1 ;; 3]] = vecs[[i, 1, 1 ;; 3]];
     indvecs[[i, 2, 1 ;; 3]] = vecs[[i, 2, 1 ;; 3]];
     indvecs[[i, 1, 4]] = a1;
     indvecs[[i, 2, 4]] = inds[[i]];
     mats[[i]] = fc[[2, ii]][[jj]];
     ];
    prs[[1, a1]] = vecs;
    prs[[2, a1]] = inds;
    prs[[3, a1]] = indvecs;
    prs[[4, a1]] = mats;
    ];
   prs
   ];

loBuildLargePairFormat[fc_, ops_] := Module[
   {d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k},
   d = Import["mathoutfile.supercell_representation", "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   lfc = ConstantArray[{}, {na, 2}];
   
   For[a1 = 1, a1 <= na, a1++,
    nv = Length[d[[a1]]];
    inds = ConstantArray[0, {nv}];
    mats = ConstantArray[0, {nv, 3, 3}];
    For[i = 1, i <= nv, i++,
     (* what kind of atom *)
     ii = d[[a1]][[i, 3]];
     (* In the unique representation, which pair is it *)
     jj = d[[a1]][[i, 4]];
     (* the operation *)
     k = d[[a1]][[i, 2]];
     inds[[i]] = d[[a1]][[i, 5]];
     mats[[i]] = 
      loApplySymopToTensor[fc[[2, ii]][[jj]], ops[[k]], 2];
     ];
    lfc[[a1, 1]] = inds;
    lfc[[a1, 2]] = mats;
    ];
   lfc
   ];

loUniqueAcousticSumRules[fc_] := Module[
   {na, j, a1, rng, fcsm},
   na = Dimensions[fc][[2]];
   newfc = fc;
   fc2 = fc;

(*
   (*play with weights*)
   d = Import["mathoutfile.unique_representation", "Table"];
   dd = SplitBy[d, First];
   For[a1 = 1, a1 <= na, a1++,
        nv = Length[fc2[[1, a1]]];
        For[i=1,i<=nv,i++,
            fc2[[2, a1]][[i]]=fc2[[2, a1]][[i]]/dd[[a1]][[i,5]];
        ];
    ];
*)
   
   For[a1 = 1, a1 <= na, a1++,
    j = First@Flatten[Position[newfc[[1, a1]], {0, 0, 0}]];
    rng = Delete[Range[Length[newfc[[1, a1]]]], j];
    fcsum = Sum[fc2[[2, a1]][[i]], {i, rng}];
    newfc[[2, a1]][[j]] = -fcsum;
    ];
   newfc
   ];

(* Third order stuff *)
loBuildUniqueTripletForceconstant := Module[
   {makeElem, i, ii, jj, kk, na, d, dd, nkvalisort, a1, nv},
   (* Construct the minimum number of force constants *)
   
   makeElem[a1_, i_, ii_, jj_, kk_] := 
    Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "m" <> 
      ToString[ii] <> ToString[jj] <> ToString[kk]];
   
   d = Import["mathoutfile.unique_representation_triplet", "Table"];
   dd = SplitBy[d, First];
   
   nkvalisort = Length[dd];
   unfc = ConstantArray[{}, {3, nkvalisort}];
   For[a1 = 1, a1 <= nkvalisort, a1++,
    (* Store the vectors *)
    
    unfc[[1, a1]] = Chop[dd[[a1]][[;; , 2 ;; 4]]];
    unfc[[2, a1]] = Chop[dd[[a1]][[;; , 5 ;; 7]]];
    (* Get forceconstants *)
    nv = Length[unfc[[1, a1]]];
    unfc[[3, a1]] = 
     Table[makeElem[a1, i, ii, jj, kk], {i, 1, nv}, {ii, 1, 3}, {jj, 
       1, 3}, {kk, 1, 3}
      ];
    ];
   unfc
   ];

loTripletTransposeSymmetryUnique[unfc_, op_] := Module[
   {a1, a2, i, i1, i2, o1, o2, m1, m2, rls, clist, perm},
   (* Apply the point operations to the condensed forceconstant \
format *)
   
   clist = Import["mathoutfile.clist_triplet_transpose", "Table"];
   
   newfc = unfc;
   For[i = 1, i <= Length[clist], i++,
    (* For each connection *)
    a1 = clist[[i, 1]];
    a2 = clist[[i, 2]];
    i1 = clist[[i, 3]];
    i2 = clist[[i, 4]];
    o1 = clist[[i, 5]];
    o2 = clist[[i, 6]];
    perm = clist[[i, 7 ;; 9]];
    m1 = loApplySymopToTensor[newfc[[3, a1]][[i1]], op[[o1]], 3];
    m2 = loApplySymopToTensor[newfc[[3, a2]][[i2]], op[[o2]], 3];
(*    rls = Flatten[Solve[m1 == TensorTranspose[m2, perm]]];*)
    rls = Flatten[Solve[m2 == TensorTranspose[m1, perm]]];
    newfc = newfc /. rls;
    ];
   newfc
   ];

loTripletPointSymmetryUnique[unfc_, op_] := Module[
   {a1, i, k, ii, jj, m1, m2, rls, clist},
    (* Apply the point operations to the condensed forceconstant format *)   
    clist = Import["mathoutfile.clist_triplet_group", "Table"];

    newfc = unfc;
    For[i = 1, i <= Length[clist], i++,
        (* For each connection *)
        a1 = clist[[i, 1]];
        k = clist[[i, 2]];
        ii = clist[[i, 3]];
        jj = clist[[i, 4]];
        (* var tvungen flippa ii och jj här *)
        m1 = loApplySymopToTensor[newfc[[3, a1]][[ii]], op[[k]], 3];
        m2 = newfc[[3, a1]][[jj]];
        rls = Flatten[Solve[m1 == m2]];
        newfc = newfc /. rls;
        (* Every once in a while, simplify the forceconstant, speeds things up considerably *)
        If[Mod[i,20]==0,
            newfc=loSimplifyThirdorder[newfc];
        ];
    ];
    loSimplifyThirdorder[newfc]
];

loSimplifyThirdorder[fc_] := Module[
   {na, nt, a1, k},
   newfc = fc;
   na = Dimensions[newfc][[2]];
   For[a1 = 1, a1 <= na, a1++,
    nt = Dimensions[newfc[[3, a1]]][[1]];
    For[k = 1, k <= nt, k++,
     newfc[[3, a1]][[k]] = Expand[Simplify[fc[[3, a1]][[k]]]];
     ];
    ];
   newfc
   ];

loTripletUniqueAcousticSumRules[fc_] := Module[
   {na, j, a1, rng, fcsm},
   na = Dimensions[fc][[2]];
   newfc = fc;
   For[a1 = 1, a1 <= na, a1++,
    (*j=First@Flatten[Position[newfc[[1,a1]],{0,0,0}]];*)
    
    j = First@
      Flatten[Position[
        Transpose[
         newfc[[1 ;; 2, a1]], {2, 1, 3}], {{0, 0, 0}, {0, 0, 0}}]];
    rng = Delete[Range[Length[newfc[[1, a1]]]], j];
    fcsum = Sum[newfc[[3, a1]][[i]], {i, rng}];
    newfc[[3, a1]][[j]] = -fcsum;
    ];
   newfc
   ];

loTripletASR[unfc_] := Module[
   {d, listPerAtom, listPerUnique, na, a1, nt, l, i, dv, lv2, i2, ng, 
    ll, m0, m1, rls},
   d = Import["mathoutfile.unique_representation_triplet", "Table"];
   (* Do it per atom *)
   listPerUnique = SplitBy[d, First];
   na = First@Dimensions[listPerUnique];
   newfc = unfc;
   
   For[a1 = 1, a1 <= na, a1++,
       listPerAtom = listPerUnique[[a1]];
       nt = First@Dimensions[listPerAtom];
       (* Build the chopping list *)
       l = ConstantArray[{}, nt];
       For[i = 1, i <= nt, i++,
           dv = ConstantArray[0, 5];
           (* Put the first lattice vector here *)
           lv2 = Round[Chop[listPerAtom[[i, 8 ;; 10]]]];
           (*lv3=Round[Chop[d[[i,11;;13]]]];*)
           (*i1=d[[i,14]];*)
           i2 = listPerAtom[[i, 15]];
           (*i3=d[[i,16]];*)
           dv[[1 ;; 3]] = lv2;
           dv[[4]] = i2;
           dv[[5]] = i;
           l[[i]] = dv;
       ];
       (* chop it into groups of constant lv2 and i2 *)
       l = SplitBy[Sort[l], #[[1 ;; 4]] &];
       (* make the sum rules *)
       ng = First@Dimensions[l];
       For[i = 1, i <= ng, i++,
           (* The list of relevant triplets *)
           ll = l[[i]][[;; , 5]];
           (* Sum of the force constants *)
           m0 = ConstantArray[0, {3, 3, 3}];
           m1 = Sum[newfc[[3, a1]][[ ll[[i]] ]], {i, 1, Length[ll]}];
           (* Apply the equations *)
           rls = Flatten[Solve[m0 == m1]];
           newfc = newfc /. rls;
       ];
   ];
   newfc
   ];

loBuildStandardTripletFormat[fc_, ops_] := 
  Module[{d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k},
   d = Import["mathoutfile.unitcell_representation_triplet", 
     "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   prs = ConstantArray[{}, {4, na}];
   For[a1 = 1, a1 <= na, a1++,
    
    nv = Length[d[[a1]]];
    vecs = ConstantArray[0, {nv, 3, 3}];
    inds = ConstantArray[0, {nv, 2}];
    indvecs = ConstantArray[0, {nv, 3, 4}];
    mats = ConstantArray[0, {nv, 3, 3, 3}];
    
    For[i = 1, i <= nv, i++,
     ii = d[[a1]][[i, 3]]; (* kvalisort *)
     jj = d[[a1]][[i, 4]]; (* triplet in unique *)
     k = d[[a1]][[i, 2]]; (* connecting operation *)
     (* indices *)
     inds[[i, 1]] = d[[a1]][[i, 5]];
     inds[[i, 2]] = d[[a1]][[i, 6]];
     (* the triangle *)
     vecs[[i, 1, 1 ;; 3]] = {0, 0, 0};
     vecs[[i, 2, 1 ;; 3]] = Chop[loApplySymopToTensor[fc[[1, ii]][[jj]], ops[[k]], 1]];
     vecs[[i, 3, 1 ;; 3]] = Chop[loApplySymopToTensor[fc[[2, ii]][[jj]], ops[[k]], 1]];
     indvecs[[i, 1, 1 ;; 3]] = vecs[[i, 1, 1 ;; 3]];
     indvecs[[i, 2, 1 ;; 3]] = vecs[[i, 2, 1 ;; 3]];
     indvecs[[i, 3, 1 ;; 3]] = vecs[[i, 3, 1 ;; 3]];
     
     indvecs[[i, 1, 4]] = a1;
     indvecs[[i, 2, 4]] = inds[[i, 1]];
     indvecs[[i, 3, 4]] = inds[[i, 2]];
     
     mats[[i]] = 
      loApplySymopToTensor[fc[[3, ii]][[jj]], ops[[k]], 3];
     ];
    prs[[1, a1]] = vecs;
    prs[[2, a1]] = inds;
    prs[[3, a1]] = indvecs;
    prs[[4, a1]] = mats;];
   prs
   ];

loBuildLargeTripletFormat[fc_, ops_] := Module[
   {d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k},
   d = Import["mathoutfile.supercell_representation_triplet", "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   ltfc = ConstantArray[{}, {na, 2}];
   For[a1 = 1, a1 <= na, a1++, nv = Length[d[[a1]]];
    inds = ConstantArray[0, {nv, 3}];
    mats = ConstantArray[0, {nv, 3, 3, 3}];
    For[i = 1, i <= nv, i++,
     (*what kind of atom*)
     ii = d[[a1]][[i, 3]];
     (*In the unique representation,which pair is it*)
     
     jj = d[[a1]][[i, 4]];
     (*the operation*)
     k = d[[a1]][[i, 2]];
     (*Indices*)
     inds[[i, 1]] = a1;
     inds[[i, 2]] = d[[a1]][[i, 5]];
     inds[[i, 3]] = d[[a1]][[i, 6]];
     (* *)
     
     mats[[i]] = 
      loApplySymopToTensor[fc[[3, ii]][[jj]], ops[[k]], 3];
     ];
    ltfc[[a1, 1]] = inds;
    ltfc[[a1, 2]] = mats;
    ];
   ltfc
   ];

(* Fourth order stuff *)

loBuildUniqueQuartetForceconstant := Module[
   {makeElem, i, ii, jj, kk, na, d, dd, nkvalisort, a1, nv},
   (* Construct the minimum number of force constants *)
   
   makeElem[a1_, i_, ii_, jj_, kk_, ll_] := Symbol["tfc" <> ToString[a1] <> "i" <> ToString[i] <> "m" <> ToString[ii] <> ToString[jj] <> ToString[kk] <> ToString[ll]];
   
   d = Import["mathoutfile.unique_representation_quartet", "Table"];
   dd = SplitBy[d, First];
   
   nkvalisort = Length[dd];
   unfc = ConstantArray[{}, {4, nkvalisort}];
   For[a1 = 1, a1 <= nkvalisort, a1++,
        (* Store the vectors *)
        unfc[[1, a1]] = Chop[dd[[a1]][[;; , 2 ;; 4]]];
        unfc[[2, a1]] = Chop[dd[[a1]][[;; , 5 ;; 7]]];
        unfc[[3, a1]] = Chop[dd[[a1]][[;; , 8 ;; 10]]];
        (* Get forceconstants *)
        nv = Length[unfc[[1, a1]]];
        unfc[[4, a1]] = Table[makeElem[a1, i, ii, jj, kk, ll], {i, 1, nv}, {ii, 1, 3}, {jj, 1, 3}, {kk, 1, 3}, {ll, 1, 3}];
    ];
   unfc
   ];

loQuartetTransposeSymmetryUnique[unfc_, op_] := Module[
   {a1, a2, i, i1, i2, o1, o2, m1, m2, rls, clist, perm},
   (*Apply the transpositions to the condensed forceconstant format*)
   clist = Import["mathoutfile.clist_quartet_transpose", "Table"];
   newfc = unfc;
   For[i = 1, i <= Length[clist], i++,
        (*For each connection*)
        a1 = clist[[i, 1]];
        a2 = clist[[i, 2]];
        i1 = clist[[i, 3]];
        i2 = clist[[i, 4]];
        o1 = clist[[i, 5]];
        o2 = clist[[i, 6]];
        perm = clist[[i, 7 ;; 10]];
        m1 = loApplySymopToTensor[newfc[[4, a1]][[i1]], op[[o1]], 4];
        m2 = loApplySymopToTensor[newfc[[4, a2]][[i2]], op[[o2]], 4];
        (*rls = Flatten[Solve[m1 == TensorTranspose[m2, perm]]];*)
        rls = Flatten[Solve[m2 == TensorTranspose[m1, perm]]];
        newfc = newfc /. rls;
    ];
   newfc
   ];

loQuartetPointSymmetryUnique[unfc_, op_] := Module[
   {a1, i, k, ii, jj, m1, m2, rls, clist},
   (*Apply the point operations to the condensed forceconstant format*)
   clist = Import["mathoutfile.clist_quartet_group", "Table"];
   newfc = unfc;
   For[i = 1, i <= Length[clist], i++,
        (*For each connection*)
        a1 = clist[[i, 1]];
        k = clist[[i, 2]];
        ii = clist[[i, 3]];
        jj = clist[[i, 4]];
        (*var tvungen flippa ii och jj här*)
        m1 = loApplySymopToTensor[newfc[[4, a1]][[ii]], op[[k]], 4];
        m2 = newfc[[4, a1]][[jj]];
        rls = Flatten[Solve[m1 == m2]];
        newfc = newfc /. rls;
        (* Simplify every once in a while to speed things up *)
        If[Mod[i,20]==0,
            newfc=loSimplifyFourthorder[newfc];
        ];
    ];
   loSimplifyFourthorder[newfc]
   ];

loSimplifyFourthorder[fc_] := Module[
   {na, nt, a1, k},
   newfc = fc;
   na = Dimensions[newfc][[2]];
   For[a1 = 1, a1 <= na, a1++,
    nt = Dimensions[newfc[[4, a1]]][[1]];
    For[k = 1, k <= nt, k++,
     newfc[[4, a1]][[k]] = Expand[Simplify[fc[[4, a1]][[k]]]];
     ];
    ];
   newfc
   ];

loQuartetUniqueAcousticSumRules[fc_] := Module[
   {na, j, a1, rng, fcsm},
   na = Dimensions[fc][[2]];
   newfc = fc;
   For[a1 = 1, a1 <= na, a1++,
    (*j=First@Flatten[Position[newfc[[1,a1]],{0,0,0}]];*)
    j = First@Flatten[Position[Transpose[fc[[1 ;; 3, 1]], {2, 1, 3}], {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}}]];
    rng = Delete[Range[Length[newfc[[1, a1]]]], j];
    fcsum = Sum[newfc[[4, a1]][[i]], {i, rng}];
    newfc[[4, a1]][[j]] = -fcsum;
   ];
   newfc
   ];

loQuartetASR[unfc_] := Module[
   {d, listPerAtom, listPerUnique, na, a1, nt, l, i, dv, lv2, i2, ng, 
    ll, m0, m1, rls},
   d = Import["mathoutfile.unique_representation_quartet", "Table"];
   (* Do it per atom *)
   listPerUnique = SplitBy[d, First];
   na = First@Dimensions[listPerUnique];
   newfc = unfc;
   
   For[a1 = 1, a1 <= na, a1++,
       listPerAtom = listPerUnique[[a1]];
       nt = First@Dimensions[listPerAtom];
       (* Build the chopping list *)
       l = ConstantArray[{}, nt];
       For[i = 1, i <= nt, i++,
           dv = ConstantArray[0, 5];
           (* Get lattice vector 2 *)
           lv2 = Round[Chop[listPerAtom[[i, 17 ;; 19]]]];
           (* And what it points to *)
           i2 = listPerAtom[[i, 23]];
           (* store this in a smart way *)
           dv[[1 ;; 3]] = lv2;
           dv[[4]] = i2;
           dv[[5]] = i;
           l[[i]] = dv;
       ];
       (* chop it into groups of constant lv2 and i2 *)
       l = SplitBy[Sort[l], #[[1 ;; 4]] &];
       (* make the sum rules *)
       ng = First@Dimensions[l];
       For[i = 1, i <= ng, i++,
           (* The list of relevant triplets *)
           ll = l[[i]][[;; , 5]];
           (* Sum of the force constants *)
           m0 = ConstantArray[0, {3, 3, 3, 3}];
           m1 = Sum[newfc[[4, a1]][[ ll[[ii]] ]], {ii, 1, Length[ll]}];
           (* Apply the equations *)
           rls = Flatten[Solve[m0 == m1]];
           newfc = newfc /. rls;
       ];
   ];
   newfc
   ];


loBuildStandardQuartetFormat[fc_, ops_] := Module[
   {d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k},
   d = Import["mathoutfile.unitcell_representation_quartet", 
     "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   prs = ConstantArray[{}, {4, na}];
   For[a1 = 1, a1 <= na, a1++,
    nv = Length[d[[a1]]];
    vecs = ConstantArray[0, {nv, 4, 3}];
    inds = ConstantArray[0, {nv, 3}];
    indvecs = ConstantArray[0, {nv, 4, 4}];
    mats = ConstantArray[0, {nv, 3, 3, 3, 3}];
    For[i = 1, i <= nv, i++,
        ii = d[[a1]][[i, 3]];  (*kvalisort*)
        jj = d[[a1]][[i, 4]];  (*triplet in unique*)
        k = d[[a1]][[i, 2]];   (*connecting operation*)
        (*indices*)
        inds[[i, 1]] = d[[a1]][[i, 5]];
        inds[[i, 2]] = d[[a1]][[i, 6]];
        inds[[i, 3]] = d[[a1]][[i, 7]];
        (*the triangle*)
        vecs[[i, 1, 1 ;; 3]] = {0, 0, 0};
        vecs[[i, 2, 1 ;; 3]] = Chop[loApplySymopToTensor[fc[[1, ii]][[jj]], ops[[k]], 1]];
        vecs[[i, 3, 1 ;; 3]] = Chop[loApplySymopToTensor[fc[[2, ii]][[jj]], ops[[k]], 1]];
        vecs[[i, 4, 1 ;; 3]] = Chop[loApplySymopToTensor[fc[[3, ii]][[jj]], ops[[k]], 1]];
        indvecs[[i, 1, 1 ;; 3]] = vecs[[i, 1, 1 ;; 3]];
        indvecs[[i, 2, 1 ;; 3]] = vecs[[i, 2, 1 ;; 3]];
        indvecs[[i, 3, 1 ;; 3]] = vecs[[i, 3, 1 ;; 3]];
        indvecs[[i, 4, 1 ;; 3]] = vecs[[i, 4, 1 ;; 3]];
        indvecs[[i, 1, 4]] = a1;
        indvecs[[i, 2, 4]] = inds[[i, 1]];
        indvecs[[i, 3, 4]] = inds[[i, 2]];
        indvecs[[i, 4, 4]] = inds[[i, 3]];
        mats[[i]] = loApplySymopToTensor[fc[[4, ii]][[jj]], ops[[k]], 4];
    ];
    prs[[1, a1]] = vecs;
    prs[[2, a1]] = inds;
    prs[[3, a1]] = indvecs;
    prs[[4, a1]] = mats;
    ];
   prs
   ];

loBuildLargeQuartetFormat[fc_, ops_] := Module[
   {d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k},
   d = Import["mathoutfile.supercell_representation_quartet", "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   ltfc = ConstantArray[{}, {na, 2}];
   For[a1 = 1, a1 <= na, a1++,
    nv = Length[d[[a1]]];
    inds = ConstantArray[0, {nv, 4}];
    mats = ConstantArray[0, {nv, 3, 3, 3, 3}];
    For[i = 1, i <= nv, i++,
        (*what kind of atom*)
        ii = d[[a1]][[i, 3]];
        (*In the unique representation,which pair is it*)
        jj = d[[a1]][[i, 4]];
        (*the operation*)
        k = d[[a1]][[i, 2]];
        (*Indices*)
        inds[[i, 1]] = a1;
        inds[[i, 2]] = d[[a1]][[i, 5]];
        inds[[i, 3]] = d[[a1]][[i, 6]];
        inds[[i, 4]] = d[[a1]][[i, 7]];
        (* The forceconstant *)
        mats[[i]] = loApplySymopToTensor[fc[[4, ii]][[jj]], ops[[k]], 4]; 
    ];
    ltfc[[a1, 1]] = inds;
    ltfc[[a1, 2]] = mats;
    ];
   ltfc
   ];

loBuildLargePairFormatAlloyExpansion[fcs_, ops_] :=
  Module[
   {d, na, a1, nv, vecs, inds, indvecs, mats, i, ii, jj, k, kk}, 
   d = Import["mathoutfile.supercell_representation", "Table"];
   d = SplitBy[d, First];
   na = Length[d];
   lfc = ConstantArray[{}, {na, 2}];
   For[a1 = 1, a1 <= na, a1++,
    nv = Length[d[[a1]]];
    inds = ConstantArray[0, {nv}];
    mats = ConstantArray[0, {nv, 3, 3}];
    For[i = 1, i <= nv, i++,
     (*what kind of atom*)
     ii = d[[a1]][[i, 3]];
     (*In the unique representation,which pair is it*)
     
     jj = d[[a1]][[i, 4]];
     (*the operation*)
     k = d[[a1]][[i, 2]];
     (*from which forceconstant, pairwise speaking*)
     
     kk = d[[a1]][[i, 6]];
     inds[[i]] = d[[a1]][[i, 5]];
     (* Add the forceconstant *)
     mats[[i]] = 
      loApplySymopToTensor[fcs[[kk]][[2, ii]][[jj]], ops[[k]], 2];
     ];
    lfc[[a1, 1]] = inds;
    lfc[[a1, 2]] = mats;
    ];
   lfc
   ];

