(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loNewLargeFirstOrderFc::usage=""
loNewLargeSecondOrderFc::usage=""
loNewLargeThirdOrderFc::usage=""
loNewLargeFourthOrderFc::usage=""
loNewFirstOrderGetForceExpression::usage=""
loNewSecondOrderGetForceExpression::usage=""
loNewThirdOrderGetForceExpression::usage=""
loNewFourthOrderGetForceExpression::usage=""
loSecondMagneticEnergyExpression::usage=""
End[];

loNewLargeFirstOrderFc[indlist_, singlet_] := Module[
   {na, i, k},
   na = Length[indlist];
   largefc = ConstantArray[{}, {na, 2}];
   For[i = 1, i <= na, i++,
    k = indlist[[i, 1]];
    largefc[[i, 1]] = k;
    largefc[[i, 2]] = singlet[[k]];
    ];
   largefc
   ];

loNewLargeSecondOrderFc[indlist_, pair_] := Module[
   {na, i, k, l},
   na = Length[indlist];
   largefc = ConstantArray[{}, {na, 2}];
   
   For[i = 1, i <= na, i++,
    largefc[[i, 1]] = indlist[[i, 3]];
    k = indlist[[i, 1]];
    l = indlist[[i, 2]];
    largefc[[i, 2]] = pair[[4, k]][[l]];
    ];
   largefc
   ];

loNewLargeThirdOrderFc[indlist_, tri_] := Module[
   {na, i, j, k, l, triangles, forceconstants, triangle, ucind1, 
    ucind2, ucind3, ssind1, ssind2, ssind3, ntri},
   na = Length[indlist];
   largefc = ConstantArray[{}, {na, 2}];
   
   For[i = 1, i <= na, i++,
    k = indlist[[i, 1]];
    ntri = Length[tri[[1, k]]];
    triangles = {};
    forceconstants = {};
    For[j = 1, j <= ntri, j++,
     triangle = ConstantArray[0, {3}];
     (* index till vektorerna i star *)
     
     ucind2 = tri[[2, k]][[j, 1]];
     ucind3 = tri[[2, k]][[j, 2]];
     (* först mappa frpn star till ss, sen ssindex till ssatom *)
    
      ssind2 = indlist[[i, 3]][[ indlist[[i, 4]][[ucind2]] ]];
     ssind3 = indlist[[i, 3]][[ indlist[[i, 4]][[ucind3]] ]];
     triangle[[1]] = i;
     triangle[[2]] = ssind2;
     triangle[[3]] = ssind3;
     AppendTo[triangles, triangle];
     AppendTo[forceconstants, tri[[4, k]][[j]]];
     ];
    largefc[[i, 1]] = triangles;
    largefc[[i, 2]] = forceconstants;
    ];
   largefc
   ];

loNewLargeFourthOrderFc[indlist_, tet_] := Module[
   {na, i, j, k, l, tetrahedrons, forceconstants, tetrahedron, ucind4,
     ucind2, ucind3, ssind4, ssind2, ssind3, ntet},
   na = Length[indlist];
   
   largefc = ConstantArray[{}, {na, 2}];
   
   For[i = 1, i <= na, i++,
    k = indlist[[i, 1]];
    ntet = Length[tet[[1, k]]];
    tetrahedrons = {};
    forceconstants = {};
    For[j = 1, j <= ntet, j++,
     tetrahedron = ConstantArray[0, {4}];
     (* index till vektorerna i star *)
     
     ucind2 = tet[[2, k]][[j, 1]];
     ucind3 = tet[[2, k]][[j, 2]];
     ucind4 = tet[[2, k]][[j, 3]];
     (* först mappa frpn star till ss, sen ssindex till ssatom *)
    
      ssind2 = indlist[[i, 3]][[ indlist[[i, 4]][[ucind2]] ]];
     ssind3 = indlist[[i, 3]][[ indlist[[i, 4]][[ucind3]] ]];
     ssind4 = indlist[[i, 3]][[ indlist[[i, 4]][[ucind4]] ]];
     tetrahedron[[1]] = i;
     tetrahedron[[2]] = ssind2;
     tetrahedron[[3]] = ssind3;
     tetrahedron[[4]] = ssind4;
     AppendTo[tetrahedrons, tetrahedron];
     AppendTo[forceconstants, tet[[4, k]][[j]]];
     ];
    largefc[[i, 1]] = tetrahedrons;
    largefc[[i, 2]] = forceconstants;
    ];
   largefc
   ];

loNewFirstOrderGetForceExpression[fc_] := Module[
   {na, l, i, mu, y},
   (*shortcuts*)
   na = Length[fc];
   forces = ConstantArray[0, {3*na}];
   l = 0;
   For[i = 1, i <= na, i++, ind = fc[[i, 1]];
    For[mu = 1, mu <= 3, mu++,
     l = l + 1;
     forces[[l]] = fc[[i, 2]][[mu]]*"y";
     ];
    ];
   forces];

loNewSecondOrderGetForceExpression[fc_] := Module[
   {na, displacements, i, j, k, l, mu, nu, lambda, nv, n, a, 
    ind, mat},
   (*shortcuts*)
   na = Length[fc];
   displacements = 
    Table["u(" <> ToString[n] <> "," <> ToString[a] <> ")", {n, 1, 
      na}, {a, 1, 3}];
   forces = ConstantArray[0, {3*na}];
   
   l = 0;
   For[i = 1, i <= na, i++,
    ind = fc[[i, 1]];
    mat = fc[[i, 2]];
    nv = Length[ind];
    For[mu = 1, mu <= 3, mu++,
     l = l + 1;
     forces[[l]] = Sum[
       mat[[j]][[mu, nu]]*displacements[[ind[[j]], nu]], {j, 1, 
        nv}, {nu, 1, 3}];
     ];
    ];
   forces
   ];

loNewThirdOrderGetForceExpression[fc_] := Module[
   {na, displacements, i, j, k, l, mu, nu, lambda, nv, n, a, 
    a2, a3, m, ii, jj, kk, ind, mat},
   (*shortcuts*)
   na = Length[fc];
   displacements = 
    Table["u(" <> ToString[n] <> "," <> ToString[a] <> ")", {n, 1, 
      na}, {a, 1, 3}];
   forces = ConstantArray[0, {3*na}];
   
   l = 0;
   For[i = 1, i <= na, i++,
    ind = fc[[i, 1]];
    mat = fc[[i, 2]];
    n = Length[ind];
    For[ii = 1, ii <= 3, ii++,
     l = l + 1;
     forces[[l]] = Sum[
       a2 = ind[[j, 2]];
       a3 = ind[[j, 3]];
       mat[[j]][[ii, jj, kk]]*displacements[[a2, jj]]*
        displacements[[a3, kk]]/2,
       {jj, 1, 3}, {kk, 1, 3}, {j, 1, n}
       ];
     ];
    ];
   forces
   ];

loNewFourthOrderGetForceExpression[fc_] := Module[
   {na, displacements, i, j, k, l, mu, nu, lambda, nv, n, a, 
    a2, a3, a4, m, ii, jj, kk, ll, ind, mat},
   (*shortcuts*)
   na = Length[fc];
   displacements = 
    Table["u(" <> ToString[n] <> "," <> ToString[a] <> ")", {n, 1, 
      na}, {a, 1, 3}];
   forces = ConstantArray[0, {3*na}];
   
   l = 0;
   For[i = 1, i <= na, i++,
    ind = fc[[i, 1]];
    mat = fc[[i, 2]];
    n = Length[ind];
    For[ii = 1, ii <= 3, ii++,
     l = l + 1;
     forces[[l]] = Sum[
       a2 = ind[[j, 2]];
       a3 = ind[[j, 3]];
       a4 = ind[[j, 4]];
       m = mat[[j]];
       m[[ii, jj, kk, ll]]*displacements[[a2, jj]]*
        displacements[[a3, kk]]*displacements[[a4, ll]]/6,
       {jj, 1, 3}, {kk, 1, 3}, {ll, 1, 3}, {j, 1, n}]
     ];
    ];
   forces
   ];

loSecondMagneticEnergyExpression[fc_] := Module[
    {displacements, i, j, k, l, mu, nu, lambda, nv, n, a, ind, mat},
    (*shortcuts*)
    na = Length[fc];
    displacements = Table[Symbol["a" <> ToString[n] <> "b" <> ToString[a] <> "c"], {n, 1, na}, {a, 1, 3}];
    energy = 0;
    (* Loop over first atom *)
    For[i = 1, i <= na, i++,
    ind = fc[[i, 1]];
    mat = fc[[i, 2]];
    nv = Length[ind];

    For[j = 1, j <= nv, j++,
        (* Do something special for i=j *)
            If[i != ind[[j]],
                (* Normal i != j *)
                energy = energy + Sum[
                    mat[[j]][[mu, nu]]*displacements[[ind[[j]], nu]]*displacements[[i, mu]], {mu, 1, 3}, {nu, 1, 3}
                ];
            ,
                (* Special i = j *)
                (*energy = energy + Sum[ mat[[j]][[mu, mu]]*displacements[[i, mu]]^4, {mu, 1, 3} ]; *)
                energy = energy + mat[[j]][[1, 1]]*Sum[displacements[[i, mu]], {mu, 1, 3} ];
                (*energy=energy;*)
            ];
        ];
    ];
    energy
];

