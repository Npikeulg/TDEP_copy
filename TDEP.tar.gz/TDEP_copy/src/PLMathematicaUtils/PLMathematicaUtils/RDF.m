(* ::Package:: *)

(* Mathematica package *)


Begin["PLMathematicaUtils`"];

RDF::usage="RDF[positions Dim {Nt,Na,3}, base, {xmin,xmax,dx}]"
ParallelRDF::usage="RDF[positions Dim {Nt,Na,3}, base, {xmin,xmax,dx}]"
End[];

RDF[positions_, base_, range_] := 
  Module[{dists, bins, N, V, norm, steps,pbcNorm},
	steps = Length[positions];
 	N = Length[positions[[1]]];
 	V = Abs[Dot[base[[1]],Cross[base[[2]],base[[3]]]]];
 	pbcNorm[{a_, b_}] := Sqrt[Dot[#,#]&[(Piecewise[{{#+1, #<-0.5}, {#-1, #>0.5}},#]&/@(a-b)).base]];
 	dists = Flatten[Table[pbcNorm /@ Tuples[p, {2}], {p, positions}]];
    bins = BinCounts[dists, range];
   	norm = Table[V/(N*N*steps*4*\[Pi]/3*((i + range[[3]])^3 - i^3)), Evaluate@Join[{i}, range]];
   	bins = bins*norm[[;; -2]];
   	Partition[Riffle[Table[i, Evaluate@Join[{i}, range]], bins], 2]
];  



ParallelRDF[positions_, base_, range_] := 
  Module[{dists, bins, N, V, norm, steps,pbcNorm},
	steps = Length[positions];
 	N = Length[positions[[1]]];
 	V = Abs[Dot[base[[1]],Cross[base[[2]],base[[3]]]]];
 	pbcNorm[{a_, b_}] := Sqrt[Dot[#,#]&[(Piecewise[{{#+1, #<-0.5}, {#-1, #>0.5}},#]&/@(a-b)).base]];
 	dists = Flatten[ParallelTable[pbcNorm /@ Tuples[p, {2}], {p, positions},DistributedContexts->Automatic]];
    bins = BinCounts[dists, range];
   	norm = Table[V/(N*N*steps*4*\[Pi]/3*((i + range[[3]])^3 - i^3)), Evaluate@Join[{i}, range]];
   	bins = bins*norm[[;; -2]];
   	Partition[Riffle[Table[i, Evaluate@Join[{i}, range]], bins], 2]
];  
