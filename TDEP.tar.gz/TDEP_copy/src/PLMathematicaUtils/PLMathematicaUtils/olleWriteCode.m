(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loNewWriteCoefficients::usage=""
loNewFirstOrderWritePhis::usage=""
loNewSecondOrderWritePhis::usage=""
loNewSecondOrderWriteMagPhis::usage=""
loNewThirdOrderWritePhis::usage=""
loNewFourthOrderWritePhis::usage=""
loDumpHuang::usage=""
loWriteMagneticCoefficients::usage=""
loDumpEmptyMagnetism::usage=""

loDumpEmptyFirstorder::usage=""
loDumpEmptyThirdorder::usage=""
loDumpEmptyFourthorder::usage=""
loDumpEmptyAlloy::usage=""
loDumpEmptyHuang::usage=""
loDumpEmptySecondorderMag::usage=""
(*loSecondOrderWriteCoefficients::usage=""
loSecondOrderWritePhis::usage=""
loThirdOrderWriteCoefficients::usage=""
loThirdOrderWritePhis::usage=""*)
End[];

loDumpHuang[CA_]:=Module[
    {n1,n2,i,j,string,fileind,f0,chars,stream},
    (* Dump the Huang invariance matrix thing to file *)

    (* open and close a file, with the proper header and footer *)
    openFile[num_]:=Module[{streamtmp},
        streamtmp=OpenWrite["huang_invariance_"<>ToString[num]<>".f90"];
        WriteString[streamtmp,StringReplace[HuangCodeTemplate1,{"<NUM>"->ToString[num]}]];
        WriteString[$Output,"Writing huang_invariance_"<>ToString[num]<>".f90\n"];
        streamtmp
    ];
    closeFile[num_]:=Module[{},
        WriteString[num,HuangCodeTemplate2];
        Close[num];
    ];

    fileind=1;
    chars=0;
    ctr=0;

    stream=openFile[fileind];
    (* This is the actual print function *)
    n1=Dimensions[CA][[1]];
    n2=Dimensions[CA][[2]];
    string="";
    For[i=1,i<=n1,i++,
        For[j=1,j<=n2,j++,
            f0=CA[[i,j]];
            If[Abs[f0]>10^-5,
                ctr++;
                string=StringJoin[string,"C("<>ToString[i]<>","<>ToString[j]<>")= "<>ToString[FortranForm[f0]]<>" \n"];
            ];
        ];
        (* Print what I have to the current file *)
        WriteString[stream,string];
        (* Check that the file not gets too long *)
        chars += StringLength[string];
        If[chars>100000,
        chars=0;
        string="";
        fileind++;
        closeFile[stream];
        stream=openFile[fileind];
        ];
    ];
    closeFile[stream];

    (* And write the wrapper *)
    string=StringReplace[HuangCodeTemplate0,{
    "<CALLSUBS>"->StringJoin[Table["call get_huanginvariance"<>ToString[i]<>"(C)\n  ",{i,1,fileind}]],
    "<COUNTER>"->ToString[ctr],
    "<USE>"->StringJoin[Table["use huang_invariance_"<>ToString[i]<>"\n  ",{i,1,fileind}]]}
    ];
    Export["huang_invariance.f90",string,"String"];
];

loNewWriteCoefficients[forceConstant_, forces_, npairs_] := Module[
      {uniqeVariables, displacements, coefficients, fileind, stream, 
        chars, printfun, coeffkod, openFile, closeFile, n, uv, i},

    (* Perhaps it's an alloy thing *)
    If[npairs>0,
        coeffPrefix="alloyCoeff",
        coeffPrefix="coeff"
    ];

    (* Get a list of the unique variables *)
    n = Length[forceConstant];
    uv = ConstantArray[{}, n];
    For[i = 1, i <= n, i++,
        uv[[i]] = Union[Flatten[ forceConstant[[i]] /. {x_ /; NumberQ[x] -> Sequence[], Plus -> List}]];
    ];
    uniqeVariables = Flatten[uv];
    coefficients = CoefficientArrays[forces, uniqeVariables];
    
    (* Open a new file *)
    If[npairs>0,
        (* alloy version *)
        openFile[num_] := Module[
            {streamtmp},
            streamtmp = OpenWrite["alloy_coeff_force_" <> ToString[fileind] <> ".f90"];    
            WriteString[streamtmp, StringReplace[alloyCoeffCodeTemplate1, {"<NUM>" -> ToString[fileind]}]];
            WriteString[$Output,"Writing output alloy_coeff_force_" <> ToString[fileind] <> ".f90\n"];
            streamtmp
        ];
        ,
        (* normal version *)
        openFile[num_] := Module[
            {streamtmp},
            streamtmp = OpenWrite["coeff_force_" <> ToString[fileind] <> ".f90"];    
            WriteString[streamtmp, StringReplace[coeffCodeTemplate1, {"<NUM>" -> ToString[fileind]}]];
            WriteString[$Output,"Writing output coeff_force_" <> ToString[fileind] <> ".f90\n"];
            streamtmp
        ];
    ];
   
    (* Close a file *)
    If[npairs>0,
        (* alloy version *)
        closeFile[stream_] := Module[{},
            WriteString[stream, alloyCoeffCodeTemplate2];
            Close[stream];
        ];
    ,
        (* normal version *)
        closeFile[stream_] := Module[{},
            WriteString[stream, coeffCodeTemplate2];
            Close[stream];
        ];
    ];

    (* Print coefficients to file *)
    fileind = 1;
    chars = 0;
    stream = openFile[fileind];

    printfun[coeff_, {i_, j_}] := Module[
        {string, nCoeff, ii, maxLength, coeffPart},
        If[coeff =!= 0,
            nCoeff = Length[coeff];
            maxLength = 10;
            ii = 1;
            (* Chop up long arithmetic expression *)
            string = "x=0.0_flyt \n";        
            While[ii < nCoeff,
                coeffPart = Take[coeff, {ii, Min[ii + maxLength - 1, nCoeff]}];
                (*string = string <> "x=x+" <> StringReplace[ToString[InputForm[Simplify[Chop[N[coeffPart,10^-12]]]]],{"\"" -> "", " " -> "",  "^" -> "**"}]<>"\n";*)
                string = string <> "x=x+" <> StringReplace[ToString[InputForm[N[Chop[Expand[coeffPart]]]]],{"\"" -> "", " " -> "",  "^" -> "**"}]<>"\n";
                ii += maxLength;
            ];
            (* Set it equal *)
            string = string <> "C(" <> ToString[i] <> "," <> ToString[j] <> ")=x \n";
            string=StringReplace[string, "+-" -> "-"];
            WriteString[stream, string];
            (* Count how much has been written, if it's too much, open another file *)
            chars += StringLength[string];
            If[chars > 500000, 
                chars = 0;
                closeFile[stream];
                stream = openFile[fileind++];
            ];
        ];
    ];


    (* Actually write *)      
    MapIndexed[printfun, coefficients[[2]], {2}];
    closeFile[stream];

    (* Dump the wrapper function *)
    If[npairs>0,
        (* Alloy version *)
        coeffkod = StringReplace[ alloyCoeffCodeTemplate0, {
            "<CALLSUBS>" -> 
                  StringJoin[Table["call alloy_force_coefficients_from_u" <> ToString[i] <>  "(C,u)\n  ", {i, 1, fileind}]],
            "<USE>" -> 
                  StringJoin[Table["use alloy_coeff_force" <> ToString[i] <> "\n  ", {i, 1, fileind}]]}
        ];
        Export["alloy_coeff_force.f90", coeffkod, "String"];
    ,
        (* Normal version *)
        coeffkod = StringReplace[ coeffCodeTemplate0, {
            "<CALLSUBS>" -> 
                  StringJoin[Table["call force_coefficients_from_u" <> ToString[i] <>  "(C,u)\n  ", {i, 1, fileind}]],
            "<USE>" -> 
                  StringJoin[Table["use coeff_force" <> ToString[i] <> "\n  ", {i, 1, fileind}]]}
        ];
        Export["coeff_force.f90", coeffkod, "String"];
    ];
    (*All done*)

];

loNewFirstOrderWritePhis[SmallForceConstant_, cutoff_, uc_] := 
  Module[
   {uniqeVariables, phiRules, fileind, chars, lineBreak, applyPhi, fg,
     fi, stream, phikod, matrices, openFile, closeFile, base, invbase,
     printfun},
   
   matrices = SmallForceConstant[[4]];
   uniqeVariables = Union[Flatten[ matrices /. {x_ /; NumberQ[x] -> Sequence[], Plus -> List}]];
   phiRules = Table[uniqeVariables[[i]] -> "phi(" <> ToString[i] <> ")", {i, 1, Length[uniqeVariables]}];
   (*Insert some newlines*)
   
   lineBreak[tmp_] := StringReplacePart[tmp, ")&\n   & ", If[Length[#] > 10, #[[10 ;; -2 ;; 10]], {}] &@ StringPosition[tmp, ")"]];
   (*Apply phirule*)
   
   applyPhi[x_] := lineBreak[StringReplace[ToString[InputForm[N[x /. phiRules]]], {"\"" -> "", " 1.*" -> "", " " -> ""}]];
   (*Format functions*)
   
   fg[x_] := If[x == "0." || x == "0", "0.0_flyt", x];
   fi[x_] := FortranForm[SetPrecision[x, 16]];

   (* Open and close functions *)
   openFile[num_] := Module[
     {streamtmp},
     streamtmp = OpenWrite["first_phimap_" <> ToString[fileind] <> ".f90"];
     WriteString[streamtmp, StringReplace[FirstPhiCodeTemplate1, {"<NUM>" -> ToString[fileind]}]];
     WriteString[$Output, "Writing output first_phimap_" <> ToString[fileind] <> ".f90\n"];
     streamtmp
     ];

   closeFile[stream_] := Module[{},
     WriteString[stream, FirstPhiCodeTemplate2];
     Close[stream];
     ];
   

    (* Start writing *)

   fileind = 1;
   chars = 0;
   stream = openFile[fileind];
   base = Base[uc]*LatticeConstant[uc];
   invbase = Inverse[base];


   printfun[fc_] := Module[
     {as, bs, vs, v, vec, ucvec, string, a1, a2, na, v1, nv, nvs, i, 
      m, a1s},
     string = " ";
     na = Length[fc[[4]]];
     For[a1 = 1, a1 <= na, a1++,
      a1s = ToString[a1];
      vec = Chop [(Positions[uc, a1]).invbase];
      m = fc[[4]][[a1]];
      string = StringJoin[string, "  fc%atom(", a1s, ")%i1=", ToString[a1], "\n"];
      string = StringJoin[string, "  fc%atom(", a1s, ")%v1(1)=", fg@ToString[fi@vec[[1]]], "\n"];
      string = StringJoin[string, "  fc%atom(", a1s, ")%v1(2)=", fg@ToString[fi@vec[[2]]], "\n"];
      string = StringJoin[string, "  fc%atom(", a1s, ")%v1(3)=", fg@ToString[fi@vec[[3]]], "\n"];
      string = StringJoin[string, "  fc%atom(", a1s, ")%m(1)=", fg@applyPhi@m[[1]], "\n"];
      string = StringJoin[string, "  fc%atom(", a1s, ")%m(2)=", fg@applyPhi@m[[2]], "\n"];
      string = StringJoin[string, "  fc%atom(", a1s, ")%m(3)=", fg@applyPhi@m[[3]], "\n"];

      WriteString[stream, string];
      chars += StringLength[string];
      If[chars > 500000, 
            chars = 0;
            closeFile[stream];
            stream = openFile[fileind++];
      ];
      string = " ";
      ];
     ];
   
   printfun[SmallForceConstant];
   closeFile[stream];
   
   phikod = 
    StringReplace[
     FirstPhiCodeTemplate0, {"<PHIS>" -> 
       ToString[Length[uniqeVariables]], 
      "<CUTOFF>" -> ToString[cutoff], 
      "<NUC>" -> ToString[Length[Positions[uc]]], 
      "<CALLSUBS>" -> 
       StringJoin[
        Table["call get_firstforceconstant_from_phi" <> ToString[i] <>
           "(phi,fc)\n  ", {i, 1, fileind}]], 
      "<USE>" -> 
       StringJoin[
        Table["use first_remap_forceconstant" <> ToString[i] <> 
          "\n  ", {i, 1, fileind}]]}];
   
   Export["first_phimap.f90", phikod, "String"];
   ];

loNewSecondOrderWriteMagPhis[SmallForceConstant_, cutoff_, uc_,npairs_] := Module[
   {uniqeVariables, phiRules, fileind, chars, lineBreak, applyPhi, fg,
     fi, stream, phikod, matrices, openFile, closeFile, base, invbase,
     printfun},
   
   matrices=SmallForceConstant[[4]];
   uniqeVariables=Union[Flatten[matrices/.{x_/;NumberQ[x]->Sequence[],Plus->List}]];
   phiRules=Table[uniqeVariables[[i]]->"phi("<>ToString[i]<>")",{i,1,Length[uniqeVariables]}];
   (*Insert some newlines*)
   lineBreak[tmp_]:=StringReplacePart[tmp, ")&\n   & ", 
     If[Length[#] > 10, #[[10 ;; -2 ;; 10]], {}] &@
      StringPosition[tmp, ")"]];
   (*Apply phirule*)
   applyPhi[x_]:=lineBreak[StringReplace[ToString[InputForm[N[Chop[Expand[x/.phiRules]]]]],{"\""-> ""," 1.*"->""," "->"","^"->"**"}]];
   (*Format functions*)
   
   fg[x_] := If[x == "0." || x == "0", "0.0_flyt", x];
   fi[x_] := FortranForm[SetPrecision[x, 16]];
   openFile[num_] := Module[
     {streamtmp},
     streamtmp=OpenWrite["second_mag_phimap_"<>ToString[fileind]<>".f90"];
     WriteString[streamtmp,StringReplace[SecondPhiMagCodeTemplate1, {"<NUM>" -> ToString[fileind]}]];
     WriteString[$Output,"Writing output second_mag_phimap_"<>ToString[fileind]<>".f90\n"];
     streamtmp
     ];
   closeFile[stream_] := Module[
     {},
     WriteString[stream, SecondPhiMagCodeTemplate2];
     Close[stream];
     ];
   fileind = 1;
   chars = 0;
   stream = openFile[fileind];
   base = Base[uc]*LatticeConstant[uc];
   invbase = Inverse[base];
   
   printfun[fc_] := Module[
     {as, bs, vs, v, vec, ucvec, string, a1, a2, na, v1, nv, nvs, i, m, a1s},
     string = " ";
     na = Length[fc[[1]]];
     For[a1 = 1, a1 <= na, a1++,
          nv = Length[fc[[2, a1]]];
          nvs = ToString[nv];
          a1s = ToString[a1];
          string = StringJoin[string, "  fc%atom(", a1s, ")%n=", nvs, "\n"];
          string = StringJoin[string, "  allocate(fc%atom(", a1s, ")%pair(", nvs, "))\n"];
          For[v1 = 1, v1 <= nv, v1++,
               a2 = fc[[2]][[a1, v1]];
               ucvec = (Positions[uc, a2] - Positions[uc, a1]).invbase;
               (* Get the lattice vector *)
               vec = fc[[1]][[a1, v1]][[2]];
               vec = Round[Chop[vec.invbase-ucvec]];
               m = fc[[4]][[a1]][[v1]];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%i1=", ToString[a1], "\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%i2=", ToString[a2], "\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%v1=0.0_flyt\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%v2=0.0_flyt\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%lv1=0.0_flyt\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%lv2(1)=", fg@ToString[fi@vec[[1]]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%lv2(2)=", fg@ToString[fi@vec[[2]]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%lv2(3)=", fg@ToString[fi@vec[[3]]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(1,1)=", fg@applyPhi@m[[1, 1]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(1,2)=", fg@applyPhi@m[[1, 2]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(1,3)=", fg@applyPhi@m[[1, 3]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(2,1)=", fg@applyPhi@m[[2, 1]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(2,2)=", fg@applyPhi@m[[2, 2]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(2,3)=", fg@applyPhi@m[[2, 3]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(3,1)=", fg@applyPhi@m[[3, 1]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(3,2)=", fg@applyPhi@m[[3, 2]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(3,3)=", fg@applyPhi@m[[3, 3]] ,"\n"];
           ];

         WriteString[stream, string];
         chars += StringLength[string];
         If[chars > 500000, 
            chars = 0;
            closeFile[stream];
            stream = openFile[fileind++];
           ];
         string=" ";      
     ];
     ];
   
   printfun[SmallForceConstant];
   closeFile[stream];
   
   phikod = 
    StringReplace[
     SecondPhiMagCodeTemplate0, {
      "<PHIS>" -> ToString[Length[uniqeVariables]],
      "<CUTOFF>" -> ToString[cutoff], 
      "<NUC>" -> ToString[Length[SmallForceConstant[[1]]]], 
      "<CALLSUBS>" -> StringJoin[Table["call get_secondforceconstant_mag_from_phi" <> ToString[i] <> "(phi,fc)\n  ", {i, 1, fileind}]], 
      "<USE>" -> StringJoin[Table["use second_remap_forceconstant_mag" <> ToString[i] <> "\n  ", {i, 1, fileind}]],
      "<NPAIRS>" -> ToString[npairs]
    }
    ];
   
   Export["second_mag_phimap.f90", phikod, "String"];
   ];

loNewSecondOrderWritePhis[SmallForceConstant_, cutoff_, uc_,npairs_] := Module[
   {uniqeVariables, phiRules, fileind, chars, lineBreak, applyPhi, fg,
     fi, stream, phikod, matrices, openFile, closeFile, base, invbase,
     printfun},
   
   matrices=SmallForceConstant[[4]];
   uniqeVariables=Union[Flatten[matrices/.{x_/;NumberQ[x]->Sequence[],Plus->List}]];
   phiRules=Table[uniqeVariables[[i]]->"phi("<>ToString[i]<>")",{i,1,Length[uniqeVariables]}];
   (*Insert some newlines*)
   lineBreak[tmp_]:=StringReplacePart[tmp, ")&\n   & ", 
     If[Length[#] > 10, #[[10 ;; -2 ;; 10]], {}] &@
      StringPosition[tmp, ")"]];
   (*Apply phirule*)
   applyPhi[x_]:=lineBreak[StringReplace[ToString[InputForm[N[Chop[Expand[x/.phiRules]]]]],{"\""-> ""," 1.*"->""," "->"","^"->"**"}]];
   (*Format functions*)
   
   fg[x_] := If[x == "0." || x == "0", "0.0_flyt", x];
   fi[x_] := FortranForm[SetPrecision[x, 16]];
   openFile[num_] := Module[
     {streamtmp},
     streamtmp=OpenWrite["second_phimap_"<>ToString[fileind]<>".f90"];
     WriteString[streamtmp,StringReplace[SecondPhiCodeTemplate1, {"<NUM>" -> ToString[fileind]}]];
     WriteString[$Output,"Writing output second_phimap_"<>ToString[fileind]<>".f90\n"];
     streamtmp
     ];
   closeFile[stream_] := Module[
     {},
     WriteString[stream, SecondPhiCodeTemplate2];
     Close[stream];
     ];
   fileind = 1;
   chars = 0;
   stream = openFile[fileind];
   base = Base[uc]*LatticeConstant[uc];
   invbase = Inverse[base];
   
   printfun[fc_] := Module[
     {as, bs, vs, v, vec, ucvec, string, a1, a2, na, v1, nv, nvs, i, m, a1s},
     string = " ";
     na = Length[fc[[1]]];
     For[a1 = 1, a1 <= na, a1++,
          nv = Length[fc[[2, a1]]];
          nvs = ToString[nv];
          a1s = ToString[a1];
          string = StringJoin[string, "  fc%atom(", a1s, ")%n=", nvs, "\n"];
          string = StringJoin[string, "  allocate(fc%atom(", a1s, ")%pair(", nvs, "))\n"];
          For[v1 = 1, v1 <= nv, v1++,
               a2 = fc[[2]][[a1, v1]];
               ucvec = (Positions[uc, a2] - Positions[uc, a1]).invbase;
               (* Get the lattice vector *)
               vec = fc[[1]][[a1, v1]][[2]];
               vec = Round[Chop[vec.invbase-ucvec]];
               m = fc[[4]][[a1]][[v1]];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%i1=", ToString[a1], "\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%i2=", ToString[a2], "\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%v1=0.0_flyt\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%v2=0.0_flyt\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%lv1=0.0_flyt\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%lv2(1)=", fg@ToString[fi@vec[[1]]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%lv2(2)=", fg@ToString[fi@vec[[2]]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%lv2(3)=", fg@ToString[fi@vec[[3]]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(1,1)=", fg@applyPhi@m[[1, 1]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(1,2)=", fg@applyPhi@m[[1, 2]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(1,3)=", fg@applyPhi@m[[1, 3]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(2,1)=", fg@applyPhi@m[[2, 1]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(2,2)=", fg@applyPhi@m[[2, 2]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(2,3)=", fg@applyPhi@m[[2, 3]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(3,1)=", fg@applyPhi@m[[3, 1]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(3,2)=", fg@applyPhi@m[[3, 2]] ,"\n"];
               string = StringJoin[string, "  fc%atom(", a1s, ")%pair(", fg@ToString[v1], ")%m(3,3)=", fg@applyPhi@m[[3, 3]] ,"\n"];
           ];

         WriteString[stream, string];
         chars += StringLength[string];
         If[chars > 500000, 
            chars = 0;
            closeFile[stream];
            stream = openFile[fileind++];
           ];
         string=" ";      
     ];
     ];
   
   printfun[SmallForceConstant];
   closeFile[stream];
   
   phikod = 
    StringReplace[
     SecondPhiCodeTemplate0, {
      "<PHIS>" -> ToString[Length[uniqeVariables]],
      "<CUTOFF>" -> ToString[cutoff], 
      "<NUC>" -> ToString[Length[SmallForceConstant[[1]]]], 
      "<CALLSUBS>" -> StringJoin[Table["call get_secondforceconstant_from_phi" <> ToString[i] <> "(phi,fc)\n  ", {i, 1, fileind}]], 
      "<USE>" -> StringJoin[Table["use second_remap_forceconstant" <> ToString[i] <> "\n  ", {i, 1, fileind}]],
      "<NPAIRS>" -> ToString[npairs]
    }
    ];
   
   Export["second_phimap.f90", phikod, "String"];
   ];

loNewThirdOrderWritePhis[tri_, cutoff_, uc_, star_] := 
  Module[{uniqeVariables, phiRules, fileind, chars, lineBreak, 
    applyPhi, fg, fi, stream, phikod, na, fc, base, invbase},
 
   na = Length[tri[[1]]];
   uniqeVariables=Union[Flatten[tri[[4]] /. {x_ /; NumberQ[x] -> Sequence[], Plus -> List}]];
   phiRules=Table[uniqeVariables[[i]] -> "phi(" <> ToString[i] <> ")", {i, 1, Length[uniqeVariables]}];

   (*Insert some newlines*)
   lineBreak[tmp_] := 
    StringReplacePart[tmp, ")&\n   & ", 
     If[Length[#] > 10, #[[10 ;; -2 ;; 10]], {}] &@
      StringPosition[tmp, ")"]];
   (*Apply phirule*)
   applyPhi[x_] := 
    lineBreak[
     StringReplace[
      ToString[InputForm[N[x /. phiRules]]], {"\"" -> "", 
       " 1.*" -> "", " " -> ""}]];
   (*Format functions*)
   fg[x_] := If[x == "0." || x == "0", "0.0_flyt", x];
   fi[x_] := FortranForm[SetPrecision[x, 16]];

   openFile[num_] := Module[
       {streamtmp}, 
       streamtmp = OpenWrite["third_phimap_" <> ToString[fileind] <> ".f90"];
       WriteString[streamtmp, StringReplace[ ThirdPhiCodeTemplate1, {"<NUM>" -> ToString[fileind]}]];
       WriteString[$Output, "Writing output third_phimap_" <> ToString[fileind] <> ".f90\n"];
       streamtmp
   ];

   closeFile[stream_] := Module[
       {}, 
       WriteString[stream, ThirdPhiCodeTemplate2];
       Close[stream];
   ];

   fileind = 1;
   chars = 0;
   stream = openFile[fileind];
   base = Chop[Base[uc]*LatticeConstant[uc]];
   invbase = Chop[Inverse[base]];
   
   pf2[fc_, na_,str_] := Module[
     {a1, a2, a3, string, ntri, a1s, ntris, v1, v2, v3, i1, i2, i3, 
      m, t, ucv, lv, ind, dumstring, dumstring2},

    string = " ";
    For[a1 = 1, a1 <= na, a1++,
        ntri = Length[fc[[1, a1]]];
        ntris = ToString[ntri];
        a1s = ToString[a1];
        string = StringJoin[string, "  fc%atom(", a1s, ")%n=", ntris, "\n"];
        string = StringJoin[string, "  allocate(fc%atom(", a1s, ")%triplet(", ntris, "))\n"];
        For[i = 1, i <= ntri, i++,
            dumstring = StringJoin["   fc%atom(", a1s, ")%triplet(", ToString[i], ")%"];
            (* First the vectors *)
            triangle = Chop[fc[[1, a1]][[i]].invbase];
            (* Get indices and lattice vectors *)
            ind = ConstantArray[0, {3}];
            ind[[1]] = a1;
            ind[[2]] = fc[[2,a1]][[i,1]];
            ind[[3]] = fc[[2,a1]][[i,2]];
            ucv = ConstantArray[0, {3, 3}];
            lv = ConstantArray[0, {3, 3}];
            For[ii = 1, ii <= 3, ii++,
                ucv[[ii]] = Chop[(Chop[Positions[uc, ind[[ii]]]] - Chop[Positions[uc, a1]]).invbase];
                lv[[ii]] = Round[Chop[triangle[[ii]] - ucv[[ii]]]];
            ];
            (* Print indices *)
            For[ii = 1, ii <= 3, ii++,
                dumstring2 = StringJoin[dumstring, "i", ToString[ii], "=", fg@ToString[ind[[ii]]], "\n"];
                string = StringJoin[string, dumstring2];
            ];
            (* Print vectors. Kind of meaningless, never used. *)
            For[ii = 1, ii <= 3, ii++, 
                For[jj = 1, jj <= 3, jj++,
                    dumstring2 = StringJoin[dumstring, "v", ToString[ii], "(", ToString[jj], ")=", fg@ToString[ucv[[ii, jj]]], "\n"];
                    string = StringJoin[string, dumstring2];
                ];
            ];
            (* Print vectors *)       
            For[ii = 1, ii <= 3, ii++, 
                For[jj = 1, jj <= 3, jj++,
                    dumstring2 = StringJoin[dumstring, "lv", ToString[ii], "(", ToString[jj], ")=", fg@ToString[lv[[ii, jj]]], "\n"];
                    string = StringJoin[string, dumstring2];
                ];
            ];
            (* Print matrices *)
            m = fc[[4, a1]][[i]];
            For[ii = 1, ii <= 3, ii++,
            For[jj = 1, jj <= 3, jj++,
            For[kk = 1, kk <= 3, kk++,
                dumstring2 = StringJoin["m(", ToString[ii], ",", ToString[jj], ",", ToString[kk], ")="];
                dumstring2 = StringJoin[dumstring, dumstring2, fg@applyPhi@m[[ii, jj, kk]], "\n"];
                string = StringJoin[string, dumstring2];
            ];
            ];
            ];       
        ];
    ];

    WriteString[stream, string];
    chars += StringLength[string];
    If[chars > 200000, chars = 0;
    closeFile[stream];
    stream = openFile[fileind++];
    ];
   ];
   
   pf2[tri, na, star];
   closeFile[stream];
   
   phikod = 
    StringReplace[
     ThirdPhiCodeTemplate0, {"<PHIS>" -> 
       ToString[Length[uniqeVariables]], 
      "<CUTOFF>" -> ToString[cutoff], "<NUC>" -> ToString[na], 
      "<CALLSUBS>" -> 
       StringJoin[
        Table["call get_thirdforceconstant_from_phi" <> ToString[i] <>
           "(phi,fc)\n  ", {i, 1, fileind}]], 
      "<USE>" -> 
       StringJoin[
        Table["use third_remap_forceconstant" <> ToString[i] <> 
          "\n  ", {i, 1, fileind}]]}];
   
   Export["third_phimap.f90", phikod, "String"];
   ];

loNewFourthOrderWritePhis[tet_, cutoff_, uc_, star_] := Module[
   {uniqeVariables, phiRules, fileind, chars, lineBreak, applyPhi, fg,
     fi, stream, phikod, na, fc, base, invbase},
   
   na = Length[tet[[1]]];
   uniqeVariables = Union[Flatten[ tet[[4]] /. {x_ /; NumberQ[x] -> Sequence[], Plus -> List}]];
   phiRules = Table[uniqeVariables[[i]] -> "phi(" <> ToString[i] <> ")", {i, 1, Length[uniqeVariables]}];
   (*Insert some newlines*)
   lineBreak[tmp_] := StringReplacePart[tmp, ")&\n   & ", If[Length[#] > 10, #[[10 ;; -2 ;; 10]], {}] &@ StringPosition[tmp, ")"]];
   (*Apply phirule*)
   applyPhi[x_] := lineBreak[ StringReplace[ ToString[InputForm[N[x /. phiRules]]], {"\"" -> "", " 1.*" -> "", " " -> ""}]];
   (*Format functions*)
   
   fg[x_] := If[x == "0." || x == "0", "0.0_flyt", x];
   fi[x_] := FortranForm[SetPrecision[x, 16]];

   openFile[num_] := Module[
     {streamtmp},
     streamtmp = OpenWrite["fourth_phimap_" <> ToString[fileind] <> ".f90"];
     WriteString[streamtmp, StringReplace[FourthPhiCodeTemplate1, {"<NUM>" -> ToString[fileind]}] ];
     WriteString[$Output, "Writing output fourth_phimap_" <> ToString[fileind] <> ".f90\n"];
     streamtmp
     ];

   closeFile[stream_] := Module[
     {},
     WriteString[stream, FourthPhiCodeTemplate2];
     Close[stream];
     ];

   fileind = 1;
   chars = 0;
   stream = openFile[fileind];
   base = Base[uc]*LatticeConstant[uc];
   invbase = Inverse[base];
   
pf2[fc_, na_, str_] := Module[
    {i, a1, string, ntet, a1s, ntets, v1, v2, v3, v4, i1, i2, i3, i4, m, dumstring, ii, jj, kk, ll, dumstring2, tetra, ind, ucv, lv},
    string = " ";
    For[a1 = 1, a1 <= na, a1++,

        ntet = Length[fc[[1, a1]]];
        ntets = ToString[ntet];
        a1s = ToString[a1];
        string = StringJoin[string, "  fc%atom(", a1s, ")%n=", ntets, "\n"];
        string = StringJoin[string, "  allocate(fc%atom(", a1s, ")%quartet(", ntets, "))\n"];

        For[i = 1, i <= ntet, i++,
            (* First the vectors *)
            tetra = Chop[fc[[1, a1]][[i]].invbase];
            (* Get indices and lattice vectors *)
            ind = ConstantArray[0, {4}];
            ind[[1]] = a1;
            ind[[2]] = fc[[2,a1]][[i,1]];
            ind[[3]] = fc[[2,a1]][[i,2]];
            ind[[4]] = fc[[2,a1]][[i,3]];
            (*  *)
            ucv = ConstantArray[0, {4, 3}];
            lv = ConstantArray[0, {4, 3}];
            For[ii = 1, ii <= 4, ii++,
                ucv[[ii]] = Chop[(Positions[uc, ind[[ii]]] - Positions[uc, a1]).invbase];
                lv[[ii]] = Round[Chop[tetra[[ii]] - ucv[[ii]]]];
            ];
            dumstring =  StringJoin["   fc%atom(", a1s, ")%quartet(", ToString[i], ")%"];
            (*the vectors*)
            For[ii = 1, ii <= 4, ii++,
            For[jj = 1, jj <= 3, jj++,
                dumstring2 = StringJoin[dumstring, "v", ToString[ii], "(", ToString[jj], ")=", fg@ToString[ucv[[ii, jj]]], "\n"];
                string = StringJoin[string, dumstring2];
            ];
            ];
            (*the lattice vectors*)
            For[ii = 1, ii <= 4, ii++,
            For[jj = 1, jj <= 3, jj++,
                dumstring2 = StringJoin[dumstring, "lv", ToString[ii], "(", ToString[jj], ")=", fg@ToString[lv[[ii, jj]]], "\n"];
                string = StringJoin[string, dumstring2];
            ];
            ];
            (* the indices *)
            For[ii = 1, ii <= 4, ii++,
                dumstring2 = 
                StringJoin[dumstring, "i", ToString[ii], "=", 
                fg@ToString[ind[[ii]]], "\n"];
                string = StringJoin[string, dumstring2];
            ];
            (* the matrices *)
            m = fc[[4, a1]][[i]];
            For[ii = 1, ii <= 3, ii++,
            For[jj = 1, jj <= 3, jj++,
            For[kk = 1, kk <= 3, kk++,
            For[ll = 1, ll <= 3, ll++,
                dumstring2 = StringJoin["m(", ToString[ii], ",", ToString[jj], ",", ToString[kk], ",", ToString[ll], ")="];
                dumstring2 = StringJoin[dumstring, dumstring2, fg@applyPhi@m[[ii, jj, kk, ll]], "\n"];
                string = StringJoin[string, dumstring2];
            ];
            ];
            ];
            ];
            (* done writing *)
        ];
    ];

    WriteString[stream, string];
    chars += StringLength[string];
    If[chars > 500000,
        chars = 0;
        closeFile[stream];
        stream = openFile[fileind++];
    ];
];
   
   pf2[tet, na, star];
   closeFile[stream];
   
   phikod = 
    StringReplace[
     FourthPhiCodeTemplate0, {"<PHIS>" -> 
       ToString[Length[uniqeVariables]], 
      "<CUTOFF>" -> ToString[cutoff], "<NUC>" -> ToString[na], 
      "<CALLSUBS>" -> 
       StringJoin[
        Table["call get_fourthforceconstant_from_phi" <> ToString[i] <>
           "(phi,fc)\n  ", {i, 1, fileind}]], 
      "<USE>" -> 
       StringJoin[
        Table["use fourth_remap_forceconstant" <> ToString[i] <> 
          "\n  ", {i, 1, fileind}]]}];
   
   Export["fourth_phimap.f90", phikod, "String"];
   ];

loDumpEmptyFirstorder[] := Module[
   {string},
   
   string = "module first_remap_forceconstant
        use constants
        use type_forceconstant_firstorder
        implicit none
        save
        contains
    
        subroutine get_firstforceconstant_uniques(phis)
            integer,intent(out) :: phis
            phis=-1
        end subroutine

      subroutine get_firstforceconstant_from_phi(phi,fc)
          type(lo_forceconstant_firstorder),intent(inout)::fc
          real(flyt),dimension(:),intent(in)::phi
      end subroutine

    end module";
   Export["first_phimap.f90", string, "Text"];
   ];

loDumpEmptyThirdorder[] := Module[
   {string},
   
   string = "module third_remap_forceconstant
        use constants
        use type_forceconstant_thirdorder
        implicit none
        save
        contains
    
        subroutine get_thirdforceconstant_uniques(phis)
            integer,intent(out) :: phis
            phis=-1
        end subroutine

      subroutine get_thirdforceconstant_from_phi(phi,fc)
          type(lo_forceconstant_thirdorder),intent(inout)::fc
          real(flyt),dimension(:),intent(in)::phi
          fc%cutoff=-1.0_flyt
      end subroutine

    end module";
   Export["third_phimap.f90", string, "Text"];
   ];

loDumpEmptyFourthorder[] := Module[
   {string},
   
   string = "module fourth_remap_forceconstant
        use constants
        use type_forceconstant_fourthorder
        implicit none
        save
        contains
    
        subroutine get_fourthforceconstant_uniques(phis)
            integer,intent(out) :: phis
            phis=-1
        end subroutine

      subroutine get_fourthforceconstant_from_phi(phi,fc)
          type(lo_forceconstant_fourthorder),intent(inout)::fc
          real(flyt),dimension(:),intent(in)::phi
          fc%cutoff=-1.0_flyt
      end subroutine

    end module";
   Export["fourth_phimap.f90", string, "Text"];
   ];


loDumpEmptyAlloy[] := Module[
   {string},
   
   string = "module alloy_coeff_force
        use constants

        implicit none
        contains
    
        subroutine alloy_force_coefficients_from_u(C,u)
            real(flyt),intent(in),dimension(:,:)::u
            real(flyt),intent(inout),dimension(:,:)::C
            C=0.0_flyt
        end subroutine


    end module";
   Export["alloy_coeff_force.f90", string, "Text"];
   ];

loDumpEmptyHuang[] := Module[
   {string},
   
   string = "module huang_invariance
        use constants

        implicit none
        contains
   
        subroutine huang_invariance_nonzeros(n)
            integer, intent(out) :: n
            n=0
        end subroutine
 
        subroutine get_huang_invariance_matrix(C)
            real(flyt),intent(out),dimension(:,:)::C
            C=0.0_flyt
        end subroutine


    end module";
   Export["huang_invariance.f90", string, "Text"];
   ];

loDumpEmptyMagnetism[] := Module[
   {string},
   
   string = "module mag_coeff_force
        use constants

        implicit none
        contains
   
        subroutine magnetic_coefficients_from_u(C,u)
            real(flyt),intent(in),dimension(:,:)::u
            real(flyt),intent(inout),dimension(:)::C
            C=0.0_flyt
        end subroutine

        function do_magnetic_stuff() result(magstuff)
            logical :: magstuff
            magstuff=.false.
        end function

    end module";
   Export["magnetic_coefficient.f90", string, "Text"];
   ];

loDumpEmptySecondorderMag[] := Module[
   {string},
   
   string = "module second_mag_remap_forceconstant
        use constants
        use type_forceconstant_secondorder
        implicit none
        save
        contains
    
        subroutine get_secondforceconstant_mag_uniques(phis)
            integer,intent(out) :: phis
            phis=-1
        end subroutine
    
        subroutine get_secondforceconstant_mag_from_phi(phi,fc)
            type(lo_forceconstant_secondorder),intent(inout)::fc
            real(flyt),dimension(:),intent(in)::phi
            fc%cutoff=-1.0_flyt
        end subroutine

    end module";
   Export["second_mag_phimap.f90", string, "Text"];
   ];

loWriteMagneticCoefficients[forceConstant_, energy_] := Module[
   {n, ev, i, uv, uniqeVariables, fileind, chars, ctr, n1, n2, string,
     dum, f0, stream, carr},
   (* Get a list of the force constants *)
   
   n = Length[forceConstant];
   uv = ConstantArray[{}, n]; 
   For[i = 1, i <= n, i++, 
    uv[[i]] = 
      Union[Flatten[
        forceConstant[[i]] /. {x_ /; NumberQ[x] -> Sequence[], 
          Plus -> List}]];
    ];
   uniqeVariables = Flatten[uv];
   
   (*open and close a file,with the proper header and footer*)
   openFile[num_] := 
    Module[{streamtmp}, 
     streamtmp = 
      OpenWrite["magnetic_coefficient_" <> ToString[num] <> ".f90"];
     WriteString[streamtmp, 
      StringReplace[
       magCoeffCodeTemplate1, {"<NUM>" -> ToString[num]}]];
     WriteString[$Output, 
      "Writing magnetic_coefficient_" <> ToString[num] <> ".f90\n"];
     streamtmp
     ];
   closeFile[num_] := Module[{},
     WriteString[num, magCoeffCodeTemplate2];
     Close[num];
     ];
   (* Get the actual vector to write *)
   
   carr = CoefficientArrays[energy, uniqeVariables];
   carr = carr[[2]];
   
   fileind = 1;
   chars = 0;
   ctr = 0;
   stream = openFile[fileind];
   
   (*This is the actual print function*)
   n1 = Dimensions[carr][[1]];
   string = "";
   For[i = 1, i <= n1, i++,
    string = string <> "x=0.0_flyt \n";
    (*Chop up the energy expression*)
    dum = Level[carr[[i]], 1];
    n2 = Length[dum];
    For[j = 1, j <= n2, j++,
     f0 = "x=x+" <> ToString[FortranForm[dum[[j]]]] <> "\n";
     string = 
      string <> 
       StringReplace[f0, {"a" -> "u(", "b" -> ",", "c" -> ")","+-"->"-"}];
     ];
    string = string <> "C(" <> ToString[i] <> ")=x \n";
    (*Print what I have to the current file*)
    
    WriteString[stream, string];
    (*Check that the file not gets too long*)
    
    chars += StringLength[string];
    If[chars > 100000, chars = 0;
     string = "";
     fileind++;
     closeFile[stream];
     stream = openFile[fileind];
     ];
    ];
   closeFile[stream];
   (* print the wrapper *)
   (*And write the wrapper*)
   string = 
    StringReplace[
     magCoeffCodeTemplate0, {"<CALLSUBS>" -> 
       StringJoin[
        Table["call magnetic_coefficients_from_u" <> ToString[i] <>
           "(C,u)\n  ", {i, 1, fileind}]], 
      "<USE>" -> 
       StringJoin[
        Table["use mag_coeff_force" <> ToString[i] <> "\n  ", {i, 1, 
          fileind}]]}
     ];
   Export["magnetic_coefficient.f90", string, "String"];
   ];

