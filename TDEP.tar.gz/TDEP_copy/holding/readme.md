### Holding area for codes that are not quite done yet

These codes work, but might not have gone through extensive testing. Could be that they were only used once. Or alternatively, I consider them not particularly useful. But I wrote them, and it's a shame to throw them away, if someone expresses interest I might pick it up again.
