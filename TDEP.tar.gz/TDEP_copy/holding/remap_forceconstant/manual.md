author: Olle Hellman
display: none
graph: none
propname: remap forceconstant
propnamelink: <a href="../program/remap_forceconstant.html">remap forceconstant</a>
{!man/remap_forceconstant.md!}

### Longer summary

@todo Actually write this

### What should be here

* explain how my force constant structure works, and how it can be remapped.
* emphasize that there is no particular cell attached to a forceconstant.
* one simple example, fcc primitive to fcc conventional.
* one more annoying, take the one with fcc as a hexagonal cell.

