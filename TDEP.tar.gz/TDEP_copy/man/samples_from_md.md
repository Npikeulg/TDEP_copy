
### Short description

Choose representative uncorrelated samples from an MD simulation. The samples are chosen to be approximately evenly spaced, and reproduce the average potential energy, average kinetic energy have the same standard deviation of potential and kinetic energy.

### Command line options:




Optional switches:

* `--nsamples value`, `-n value`  
    default value 50  
    Number of samples

* `--output_format value`, `-of value`, value in: `1,2,3`  
    default value 1  
    Output format. 1 is VASP, 2 Abinit, 3 LAMMPS.

* `--help`, `-h`  
    Print this help message

* `--version`, `-v`  
    Print version
### Examples

`samples_from_md -n 100` 
