author: Olle Hellman
display: none
graph: none
{!man/pair_distribution_function.md!}

### Longer summary

This is a longer summary of the program.

Have a plot or two.

@todo Have to make it safer, and separate things into proper shells.
