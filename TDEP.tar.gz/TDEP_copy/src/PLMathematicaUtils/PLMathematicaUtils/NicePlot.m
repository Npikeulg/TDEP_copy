(* Mathematica package *)

(* Nice Plots *)

Begin["PLMathematicaUtils`"];


NicePlot::usage="NicePlot[ListPlot, {data1, data2, ...},  
Legend -> {\"Data 1\", \"Data 2\", ... }, 
LegendOptions -> {Frame -> None, LegendXMax->0.2, LegendXSep->0.05, LegendYSep->0.6,}, 
LegendPosition -> {0.95, 0.95},
LegendPositionFunction -> Scaled,
LegendReference -> {Right, Top},
LegendRowHeight -> None,
LegendWidth -> None,
LegendStyle -> {FontColor->Black,FontSize->12},
LegendPlotStyle -> Thin
]";

End[];

 MakeLegendLabel[text_,index_, opts:OptionsPattern[{Options[Style]}]]:= 
 	Style[text, Evaluate@FilterRules[{opts}, Options[Style]]];
 	

Options[MakeLegend]={Options[ListPlot],
   	LegendXMax->0.2,
   	LegendXSep->0.05,
   	LegendYSep->0.7,
    LegendStyle -> {FontColor -> Black, FontSize -> 12}};

MakeLegend[legend_, plotstyle_, markers_, width_, rowHeight_, 
   opts : OptionsPattern[{Options[ListPlot],
   	LegendXMax->0.2,
   	LegendXSep->0.05,
   	LegendYSep->0.6,
    LegendStyle -> {FontColor -> Black, FontSize -> 12}}]] :=
  Module[{xmax, xsep, pad, height, ysep,pr},
   xmax = OptionValue[LegendXMax];
   xsep = OptionValue[LegendXSep];
   ysep = OptionValue[LegendYSep];
   pad = 1;
   height = rowHeight*Length[legend] + 2 pad + 2*rowHeight*(ysep - 0.5);
   pr = {{-xsep, 0.6*width/100 - xsep}, {-ysep, 
      Length[legend] - 1 + ysep}};
   ListPlot[
   	Table[
   		If[If[ListQ[OptionValue[Joined]],OptionValue[Joined][[i+1]],OptionValue[Joined]],
   		{{0, i}, {xmax, i}},
   		 {{xmax, i}}
   		],
   	{i, Length[legend] - 1, 0, -1}],
   	
    Evaluate@FilterRules[{opts}, Options[ListPlot]], 
    PlotMarkers -> markers, PlotStyle -> plotstyle, 
    Background -> None, Frame -> True, Axes -> None, 
    FrameTicks -> None, 
    AspectRatio -> (height - 2 pad)/(width - 2*pad),
    ImageSize -> {width, height},
    ImagePadding -> {{pad, pad}, {pad, pad}},
    PlotRangePadding -> {{0, 0}, {0, 0}}, PlotRange -> pr,
    Epilog -> 
     MapIndexed[
      Inset[MakeLegendLabel[#1, #2, 
         OptionValue[LegendStyle]], {xmax + xsep, 
         Length[legend] - First@#2}, {Left, Center}] &, legend]]
   ];   	
   	
   	

Options[NicePlot]={
	Options[Plot],
	Options[DateListPlot],
	Options[ListPlot],
	Options[ListLogPlot],
	Options[ListLogLogPlot],
	Options[SmoothHistogram],
    Frame -> True,  
  	Legend -> {}, 
    LegendPosition -> {0.95, 0.95},
    LegendPositionFunction->ImageScaled, 
    LegendReference -> {Right, Top},
  	LegendRowHeight -> None,
    LegendWidth->None,
    LegendStyle->{FontColor->Black,FontSize->12},
    LegendPlotStyle->None,
    LegendOptions->{}
    };   	

NicePlot[plt_, fun__, opts : OptionsPattern[{
	Options[Plot],
	Options[DateListPlot],
	Options[ListPlot],
	Options[ListLogPlot],
	Options[ListLogLogPlot],
	Options[SmoothHistogram],
    Frame -> True,  
  	Legend -> {}, 
    LegendPosition -> {0.95, 0.95},
    LegendPositionFunction->ImageScaled, 
    LegendReference -> {Right, Top},
  	LegendRowHeight -> None,
    LegendWidth->None,
    LegendStyle->{FontColor->Black,FontSize->12},
    LegendPlotStyle->None,
    LegendOptions->{}
    }]
    ] := Module[{width,legend,rowHeight},
    width = OptionValue[LegendWidth];
	If[width == None && Length[OptionValue[Legend]]>0,
		width = 45 + 0.9*Max[
			First[ImageSize/.Rasterize[Style[#,OptionValue[LegendStyle]]][[2]]]&/@OptionValue[Legend]
		]
	];
	
	rowHeight = OptionValue[LegendRowHeight];
	If[rowHeight == None && Length[OptionValue[Legend]]>0,
		rowHeight = 1.3*Max[
			(ImageSize/.Rasterize[Style[#,OptionValue[LegendStyle]]][[2]])[[2]]&/@OptionValue[Legend]
		]
	];
	
	If[Length[OptionValue[Legend]]>0,	
	legend = MakeLegend[
    	OptionValue[Legend],
    	If[OptionValue[LegendPlotStyle]=!=None,
    		OptionValue[LegendPlotStyle],
      		OptionValue[PlotStyle]
      	],
      	OptionValue[PlotMarkers],
      	width,
      	rowHeight,
      	LegendStyle->OptionValue[LegendStyle],
      	OptionValue[LegendOptions],
      	Evaluate@FilterRules[{opts}, {Joined}]
	]];
		
	plt[fun,
		Epilog -> Join[
 			OptionValue[Epilog],
 			{If[Length[OptionValue[Legend]] > 0, 
    			Inset[legend,
       				OptionValue[LegendPositionFunction][OptionValue[LegendPosition]], 
       				OptionValue[LegendReference]
       			],
       			{}
       		]}
       	], 
       	Evaluate@FilterRules[{opts}, Options[plt]]
   	]
  ] 