author: Olle Hellman
display: none
graph: none
{!man/phonon_linewidths.md!}

### Longer summary


With the third order force constants we can calculate the phonon lifetimes. The lifetime due to phonon-phonon scattering is related to the imaginary part of the phonon self energy [^1]


[^1]: D. C. Wallace, Thermodynamics of Crystals, (1998).

$$
\begin{equation}
\frac{1}{\tau_{\mathbf{q}s}}=2 \Gamma_{\mathbf{q}s}
\end{equation}
$$

where \(\tau_{\textbf{q}s}\) is the lifetime for wave vector \(\textbf{q}\) and mode \(s\), and

$$
\begin{equation}
\begin{split}
\Gamma_{\mathbf{q}s}=& \sum_{s's''} \frac{\hbar \pi}{16} \iint_{\mathrm{BZ}}
\left|\Psi^{\mathbf{q}\mathbf{q}'\mathbf{q}''}_{ss's''}\right|^2 \Delta_{\mathbf{q}\mathbf{q}'\mathbf{q}''} \times \\
& \bigl[(n_{\mathbf{q}'s'}+n_{\mathbf{q}''s''}+1)
\delta(\omega_{\mathbf{q}s}-\omega_{\mathbf{q}'s'}-\omega_{\mathbf{q}''s''}) \\
+ & 2(n_{\mathbf{q}'s'}-n_{\mathbf{q}''s''})
\delta(\omega_{\mathbf{q}s}-\omega_{\mathbf{q}'s'}+\omega_{\mathbf{q}''s''}) \bigr]d\mathbf{q}'d\mathbf{q}''.
\end{split}
\end{equation}
$$


\(n_{\textbf{q}s}\) is the equilibrium occupation number. The \(\Delta_{\textbf{q}\textbf{q}'\textbf{q}''}\) ensures momentum conversation, \(\textbf{q}+\textbf{q}'+\textbf{q}''=\textbf{G}\), and the deltafunctions in frequency ensure energy conservation. The three-phonon matrix elements are given by

$$
\begin{equation}
\begin{split}
\Psi^{\mathbf{q}\mathbf{q}'\mathbf{q}''}_{ss's''} = &
\sum_{ijk}
\sum_{\alpha\beta\gamma}
\frac{
\epsilon^{\mathbf{q}s}_{\alpha i} \epsilon^{\mathbf{q}'s'}_{\beta j} \epsilon^{\mathbf{q}''s''}_{\gamma k}
}{
\sqrt{M_{i}M_{j}M_{j}}
\sqrt{\omega_{\mathbf{q}s}\omega_{\mathbf{q}'s'}\omega_{\mathbf{q}''s''}}
}\times 
\Psi^{\alpha\beta\gamma}_{ijk}
e^{i \mathbf{q}\cdot\vec{r}_i + i \mathbf{q}'\cdot\mathbf{r}_j+i \mathbf{q}''\cdot\mathbf{r}_k}
\end{split}
\end{equation}
$$

where \(M_i\) is the mass of atom \(i\), \(\epsilon^{\textbf{q}s}_{\alpha i}\) is component \(\alpha\) of the eigenvector for mode \(\vec{q}s\) and atom \(i\) and \(\textbf{r}_i\) is the lattice vector associated with atom \(i\).


### Input files

* [infile.ucposcar](../page/files.html#infile.ucposcar)
* [infile.ssposcar](../page/files.html#infile.ssposcar)
* infile.forceconstant 
* infile.forceconstant_thirdorder 


#### Default output files
Note that -qg option has to specified, otherwise the default q-point mesh is 

@todo can not find the default value 

If the temperature --temperature option is not specified than the lifetimes and linewidths are calculated using the default temperauture specified in ... If the temperature is specified than temperature in included in the Plank distribution of phonons.

@todo what is a default value for the temperature  


* outfile.linewidths
* outfile.lifetimes* outfile.lifetimes.gnuplot


##### outfile.linewidths

The first colomn is a frequency (THz) and the second colomn is a linewidth in THz. 

```
  6.0964083427789095        1.8760887465142922E-003
  6.0964083427789113        1.8760887465142121E-003
  6.0964083427789113        1.8760887465142189E-003
 
```



##### outfile.lifetimes

```
  6.0964083427789095        84.833376559392093
  6.0964083427789113        84.833376559395717
  6.0964083427789113        84.833376559395418
  ...
```
The first colomn is a frequency (THz) and the second colomn is a lifetimes in ps. 


##### outfile.lifetimes.gnuplot

The lifetimes and linewidths can be plotted using gnuplot.

@todo maybe rename gnuplot file with a name that contains both lifetimes and linewidths


### Maybe some plots?

Have a plot or two.
