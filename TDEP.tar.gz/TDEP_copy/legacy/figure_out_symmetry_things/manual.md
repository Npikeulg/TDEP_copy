author: Olle Hellman
display: none
graph: none
{!man/figure_out_symmetry_things.md!}

### Longer summary

This is a longer summary of the program.

### Maybe some plots?

Have a plot or two.
