(* ::Package:: *)

(* Mathematica Package *)

(* Created by the Wolfram Workbench 2011-feb-07 *)

BeginPackage["PLMathematicaUtils`"];
(* Exported symbols added here with SymbolName::usage *) 

PLData::usage="Database of usefull stuff: Lattices, ...";
LeftArrow::usage="Postfix notation with extra arguments";
DoubleLongRightArrow::usage="Apply list of funtions to data, {Min,Max}==>{1,2,3}";
TableToString::usage="Make a string from a table";
ImportSSH::usage="ImportSSH[\"kappa\",\"ls\",SSHAuthSock->\"/tmp/launch-XYFVqs/Listeners\"]";
FileExistsQSSH::usage="FileExistsQSSH[\"kappa\", file]";
PBC::usage="PBC[data], Dimenstion[data] = {Na,3}";
UndoPBC::usage="UndoPBC[data], Dimensions[data] = {Nt,Na,3}";

ExportPDF::usage="ExportPDF[file (excluding .pdf), obj, size [cm], dpi: 300]";
ExportEPS::usage="ExportEPS[file (excluding .eps), obj, size [cm], dpi: 300]";
TextToShape::usage="TextToShape[graphics]"

ModuleProgressBar::usage="ModuleProgressBar[counter, maxvalue(or Indeterminate)]"
ModuleProgressBarSparkline::usage="ModuleProgressBarSparkline[counter, maxvalue(or Indeterminate), datalist, ({plot option list}]"

Disp::usage="Disp[x*y] will display \"x*y = result\" "

MapAtSlice::usage="MapAtSlice[fun, data, slice, levelspec]";
AccumulateY::usage="AccumulateY[pairlist]";
NiceData::usage="NiceData[data] returns true if data is an n dim array of Machine numbers, \n
NiceData[data, d] returns true if data is an d dim array of Machine numbers";
PJPalette::usage="PJPalette[Context[]]";
VarStats::usage="Print a list of all used variables";

Begin["`Private`"];
(* Implementation of the package *)

(* Export data *)
TableToString[data_, indent_: 0, format_: {20, 16}] := Module[{res},
   res = ExportString[
     NumberForm[
      TableForm[N[data], TableSpacing -> {0, 1}]
      , format,
      NumberSigns -> {"-", " "},
      NumberPadding -> {"", "0"},
      ExponentFunction -> (If[-30 < # < 30, Null, #] &)]
     , "String"];
   
   StringJoin[
    Riffle[Map[StringJoin[StringJoin[Table[" ", {indent}]], #] &, 
      StringSplit[res, "\n"]], "\n"]]
   ];


(* Remote file operations *)
ImportSSH[computer_, command_, 
   opts : OptionsPattern[]] := Module[{},
     Import["!export SSH_AUTH_SOCK=" <> OptionValue[SSHAuthSock] <> "; ssh " <>
      computer <> " " <> command , OptionValue[Format]]
 ];
Options[ImportSSH]={SSHAuthSock -> "/tmp/501/SSHKeychain.socket", 
   	 Format -> "Table"};

FileExistsQSSH[computer_, file_,opts : OptionsPattern[{Options[ImportSSH]}]] := 
 ToExpression[
  ImportSSH[computer, 
   "\"if [ -r " <> file <> 
    " ]; then echo True; else echo False; fi\"", Format -> "String",
    Evaluate@FilterRules[{opts}, Options[ImportSSH]]]]


(* Syntax definitions *) 
LeftArrow[x_, f_[y___]] := f[x, y];
LeftArrow[x_, f_[opts : OptionsPattern]] := f[x, opts];
LeftArrow[a_, b_, c__] := LeftArrow[LeftArrow[a, b], c];
LeftArrow[x_, f_] := f[x];
SetAttributes[LeftArrow, HoldRest];

DoubleLongRightArrow[x_List, y__] := Through[x[y]]
DoubleLongRightArrow[x_, y__] := x[y]

Disp[x_] := Row[{ExpressionCell[HoldForm[x]], TextCell[": "],  ExpressionCell[x]}];
SetAttributes[Disp, HoldFirst]

PBC[data_] := Module[{pbc},
  pbc[list_] := Map[If[#1 < 0.0, #1 + 1, If[#1 >= 1.0, #1 - 1, #1]] &, list];
  Map[pbc, data]
];  

UndoPBC[data_] := Module[{unpbc},
   unpbc[list_List] := FoldList[If[#1 - #2 < -0.5, #2 - 1,  If[#1 - #2 > 0.5, #2 + 1, #2]] &, list[[1]], list[[2 ;;]]];
   Transpose[ Table[unpbc[data[[All, i, j]]], {i, 1, Length[data[[1]]]}, {j, 1, 3}], {2, 3, 1}]
   ];

ExportPDF[file_, obj_, size_, dpi_: 300] := Module[{dpc, res},
   dpc = 72/2.54;
   res = size*dpc;
   Export[file <> ".pdf", obj, ImageSize -> res, 
    ImageResolution -> dpi]
   ];
ExportEPS[file_, obj_, size_, dpi_: 300] := Module[{dpc, res},
   dpc = 72/2.54;
   res = size*dpc;
   Export[file <> ".eps", obj, ImageSize -> res, 
    ImageResolution -> dpi, Background -> White]
   ];
   
   	(*http://pages.uoregon.edu/noeckel/MathematicaGraphics.html*)
	(* Convert Text to Shapes *)
TextToShape[obj_]:=First@ImportString[
		ExportString[obj, "PDF"], "PDF", "TextMode" -> "Outlines"];

ModuleProgressBar[i_, maxval_:Indeterminate] := PrintTemporary[Row[{ProgressIndicator[Dynamic[i],If[NumberQ[maxval],{0, maxval}, Indeterminate] ]," ",Dynamic[i]}]];
SetAttributes[ModuleProgressBar, HoldFirst];
ModuleProgressBarSparkline[i_, maxval_, datalist_, plotopts_:{}] := PrintTemporary[Row[
		{ProgressIndicator[Dynamic[i], If[NumberQ[maxval],{0, maxval}, Indeterminate]]," ", 
		 Dynamic@ListLinePlot[datalist, plotopts,PlotMarkers->Automatic,
					Ticks -> {None,  {Ceiling[#1], Floor[#2]}&}, Axes -> {False, True} ] }]];
SetAttributes[ModuleProgressBarSparkline, HoldAll];

MapAtSlice[fun_, data_, slice_, levelspec_: {1}] := 
 Module[{tmp, res},
  tmp = Part @@ Join[{data}, slice];
  res = data;
  Part[res, Sequence @@ slice] = Map[fun, tmp, levelspec];
  res
  ];

AccumulateY[pairlist_] := 
  Rest@FoldList[{#2[[1]], Plus[#2[[2]], #1[[2]]]} &, {0, 0}, 
    pairlist];

NiceData[x_] := ArrayQ[x, ArrayDepth[x], MachineNumberQ];
NiceData[x_, d_Integer] := ArrayQ[x, d, MachineNumberQ];

VarStats[] := DynamicModule[{sf=1,i,context=Context[],sortfuns},
	sortfuns[sfi_]:={
		Sign[sfi]*Order[#1,#2]>0&,
		Sign[sfi]*Order[ToString[Head[ToExpression[#1]]],ToString[Head[ToExpression[#2]]]]>0&,
		Sign[sfi]*Order[ByteCount[ToExpression[#1]],ByteCount[ToExpression[#2]]]>0&
	}[[Abs[sfi]]];
	Dynamic[TableForm[Join[
	{
		{Button["Object",If[sf==1,sf=-sf,sf=1]],
		 Button["Head (Dim, Top Head)",If[sf==2,sf=-sf,sf=2]],
	     Button["Size (Bytes)",If[sf==3,sf=-sf,sf=3]]},
   		{"====================", "====================", "=============="}
   	} ,
	Map[
		{Tooltip[ActionMenu[#, {"Clear" :> Clear[#], "Remove" :> Remove[#]}],Short[ToExpression[#]]],
	ToString[Head[ToExpression[#]]] <> " " <> 
	If[Head[ToExpression[#]] === List, 
      ToString[Dimensions[ToExpression[#]]] <> ", " <> 
      ToString[Head[Extract[ToExpression[#],Table[1, {i, 1, ArrayDepth[ToExpression[#]]}]]]]
      ,
      ""
     ], 
     ByteCount[ToExpression[#]]
    }&, 
    Sort[Names[context <> "*"], sortfuns[sf]]
    ], 
   	{
   		{"====================", "====================", "=============="}, 
   		{context,"Total:", Total[ByteCount[ToExpression[#]] &/@Names[context <> "*"]]}
   	}   
    ]
    ]
    ]
];


PJPalette[context_:"Global`"] := Module[{sortfuns},
	sortfuns[sfi_] := {
           Sign[sfi]*Order[#1, #2] > 0 &, 
           Sign[sfi]*
              Order[ToString[Head[ToExpression[#1]]], 
               ToString[Head[ToExpression[#2]]]] > 0 &, 
           Sign[sfi]*
              Order[ByteCount[ToExpression[#1]], 
               ByteCount[ToExpression[#2]]] > 0 &
           }[[Abs[sfi]]];             
   CreatePalette[
   	DynamicModule[{sf=1,i},
   	TabView[
     {
      Style["Varables", 16, FontFamily -> "Helvetica"] -> Dynamic[ 
        TableForm[Join[
          {
           {Button["Object", If[sf == 1, sf = -sf, sf = 1]],
            Button["Head (Dim, Top Head)",If[sf == 2, sf = -sf, sf = 2]],
            Button["Size (Bytes)", If[sf == 3, sf = -sf, sf = 3]]},
           {"====================", "====================", "=============="}
          },
          
          Map[{Tooltip[
              ActionMenu[Last@StringSplit[#,"`"], {"Clear" :> Clear[#], 
                "Remove" :> Remove[#]},FrameMargins -> 1 ], Short[ToExpression[#]]], 
             ToString[Head[ToExpression[#]]] <> " " <> 
              If[Head[ToExpression[#]] === List, 
               ToString[Dimensions[ToExpression[#]]] <> ", " <> 
                ToString[
                 Head[Extract[ToExpression[#], 
                   Table[1, {i, 1, ArrayDepth[ToExpression[#]]}]]]], 
               ""], ByteCount[ToExpression[#]]} &, 
           Sort[Names[context <> "*"], sortfuns[sf]]],
           
          {
           {"====================", "====================", "=============="},
           {context, "Total:", Total[ByteCount[ToExpression[#]] & /@ Names[context <> "*"]]}
          }
          ]
         ],
        UpdateInterval -> 1        
        ],
      	Style["Other", 16, FontFamily -> "Helvetica"] -> "Something else fun"
      }
     ]],
    WindowSize -> {Fit, 500},
    WindowElements -> {"VerticalScrollBar"},
    WindowTitle -> "PJ Stats",
    Saveable -> False];
];

    


PLData["PaperStats"]={{"PageWitdh",17.9219},{"ColumnWidth",8.64468},{"DotsPerCm",72.0/2.54}};


PLData["PlotMarkers"]={"\[FilledCircle]","\[FilledSquare]","\[FilledDiamond]","\[FilledUpTriangle]","\[FilledDownTriangle]",
	"\[EmptyCircle]","\[EmptySquare]","\[EmptyDiamond]","\[EmptyUpTriangle]","\[EmptyDownTriangle]"};
PLData["Colors"]={
 RGBColor[0.121569, 0.470588, 0.705882], 
 RGBColor[0.2, 0.627451, 0.172549], 
 RGBColor[0.890196, 0.101961, 0.109804], RGBColor[1., 0.498039, 0.], 
 RGBColor[0.415686, 0.239216, 0.603922], 
 RGBColor[0.65098, 0.807843, 0.890196], 
 RGBColor[0.698039, 0.87451, 0.541176], 
 RGBColor[0.984314, 0.603922, 0.6], 
 RGBColor[0.992157, 0.74902, 0.435294], 
 RGBColor[0.792157, 0.698039, 0.839216]
 };
 PLData["Dashes"]={
 	AbsoluteDashing[{}], 
 	AbsoluteDashing[{10, 4}], 
 	AbsoluteDashing[{4, 4}], 
 	AbsoluteDashing[{4, 4, 0, 4}], 
  	AbsoluteDashing[{10, 4, 0, 4}],
  	AbsoluteDashing[{10, 4, 0, 4, 0, 4}], 
  	AbsoluteDashing[{10, 4, 10, 4, 0, 4}], 
  	AbsoluteDashing[{10, 4, 0, 4, 5, 4, 0, 4}], 
  	AbsoluteDashing[{10, 4, 0, 4, 5, 4, 5, 4, 0, 4}], 
  	AbsoluteDashing[{10, 4, 0, 4, 5, 4, 0, 4, 5, 4, 0, 4}]
  	};
Unprotect[AbsoluteDashing]
AbsoluteDashing /: Times[x_?NumberQ, AbsoluteDashing[list_List]] := 
 AbsoluteDashing[x*list]
Protect[AbsoluteDashing]	


Get["PLMathematicaUtils`POSCAR`"];
Get["PLMathematicaUtils`META`"];
Get["PLMathematicaUtils`MDSIMULATION`"];
Get["PLMathematicaUtils`NicePlot`"];
Get["PLMathematicaUtils`GridPlot`"];
Get["PLMathematicaUtils`RDF`"];
Get["PLMathematicaUtils`TextureTransformFunction3D`"];
Get["PLMathematicaUtils`CLI`"];
Get["PLMathematicaUtils`Lattices`"];
Get["PLMathematicaUtils`EOS`"];
(* Här har jag lagt till massa skit, det är ju helt j-a omöjligt att göra ett eget paket *)
Get["PLMathematicaUtils`olleFindSymmetries`"];
Get["PLMathematicaUtils`olleHelperFunctions`"];
Get["PLMathematicaUtils`olleKodsnuttar`"];
Get["PLMathematicaUtils`olleGeneralSymmetry`"];
Get["PLMathematicaUtils`olleSecondOrderSymmetrycheck`"];
Get["PLMathematicaUtils`olleThirdOrderSymmetrycheck`"];
Get["PLMathematicaUtils`olleFourthOrderSymmetryCheck`"];
Get["PLMathematicaUtils`olleGenerateSmallForceconstants`"];
Get["PLMathematicaUtils`olleGetForceExpressions`"];
Get["PLMathematicaUtils`olleMatchUnitAndSupercell`"];
Get["PLMathematicaUtils`olleWriteCode`"];
Get["PLMathematicaUtils`olleFortranHybridFunctions`"];


End[]

EndPackage[]




