title: Minimal example III
author: Olle Hellman

### Really fast stochastic calculations

@todo Will arrive when I publish


