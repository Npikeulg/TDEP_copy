(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loGetSupercellNeighbourlist::usage="loGetSupercellNeighbourlist[supercell_, cutoff_]"
loGetUnitToSupercellMatching::usage="loGetUnitToSupercellMatching[ucnn,ssnn]"
loIndexMatchlist::usage=""
End[];

loGetSupercellNeighbourlist[supercell_, cutoff_] := Module[
   {na, pos, base, nlist, points1, points2, species2, indices2, norms,
     matches, a1, n, vectors, indices, species, k, i},
   
   na = Total[NumberOfElements[supercell]];
   pos = DirectPositions[supercell];
   base = Base[supercell]*LatticeConstant[supercell];
   nlist = ConstantArray[{}, {3, na}];
   
   points1 = pos.base;
   points2 = 
    Flatten[Map[Function[{punkt}, (punkt + #).base & /@ pos], 
      Tuples[{-1, 0, 1}, 3]], 1];
   species2 = 
    Flatten[Table[Map[Elements[supercell, #] &, Range[na]], {27}]];
   indices2 = Flatten[Table[Range[na], {27}]];
   
   norms = 
    Map[Function[{apoint}, Norm@(apoint - #) & /@ points2], points1];
   matches = 
    Table[Flatten[Position[norms[[i]], x_ /; x < cutoff]], {i, 1, na}];
   
   For[a1 = 1, a1 <= na, a1++,
    n = Length[matches[[a1]]];
    vectors = ConstantArray[0, {n, 3}];
    indices = ConstantArray[0, {n}];
    species = ConstantArray[{}, {n}];
    
    For[k = 1, k <= n, k++,
     i = matches[[a1, k]];
     vectors[[k]] = points2[[i]] - points1[[a1]];
     indices[[k]] = indices2[[i]];
     species[[k]] = species2[[i]];
     ];
    nlist[[1, a1]] = Chop[vectors, 10^-5];
    nlist[[2, a1]] = species;
    nlist[[3, a1]] = indices;
    ];
   nl = nlist
   ];

loGetUnitToSupercellMatching[star_, nlistSc_] := Module[
   {ssna, ucna, a1, a2, match, ucvecs, ssvecs, vectorTest, nvss, nvuc},
   ssna = Length[nlistSc[[1]]];
   ucna = Length[star[[1]]];
   match = ConstantArray[0, {ssna}];
   
   vectorTest[v1_, v2_] := 
    Module[{}, 
     SquaredEuclideanDistance[v1[[1 ;; 3]], v2[[1 ;; 3]]] < 10^-4 && 
      v1[[4]] == v2[[4]]];
   
   For[a1 = 1, a1 <= ssna, a1++,
    
    nvss = Length[nlistSc[[1, a1]]];
    ssvecs = 
     Table[Join[nlistSc[[1, a1]][[i]], {nlistSc[[2, a1]][[i]]}], {i, 
       1, nvss}];
    
    For[a2 = 1, a2 <= ucna, a2++,
     
     nvuc = Length[star[[1, a2]]];
     ucvecs = 
      Table[Join[star[[2, a2]][[i]], {star[[3, a2]][[i]]}], {i, 1, 
        nvuc}];
     
     If[nvss == nvuc,
      
      If[Length[Union[ucvecs, ssvecs, SameTest -> vectorTest]] == nvss,
        match[[a1]] = a2;
        ];
      
      ];
     
     ];
    ];
   m = match
   ];

loIndexMatchlist[ss_, star_, cutoff_, uc_] := Module[
   {nlistUc, nlistSc, match, i, na, matchatom, starVectors, nv, 
    matchlist},
   (* First item is index in unit cell, 
   second is index corresponding to the unit cell vectors, 
   third is the index to the super cell atoms. *)
   
   nlistSc = loGetSupercellNeighbourlist[ss, cutoff];
   match = loGetUnitToSupercellMatching[star, nlistSc];
   na = Total[NumberOfElements[ss]];
   
   indlist = ConstantArray[{}, {na, 4}];
   
   For[i = 1, i <= na, i++,
    matchatom = match[[i]];
    starVectors = star[[2, matchatom]];
    nv = Length[nlistSc[[1, i]]];
    matchlist = 
     Position[
      Table[loKvalisortVectorTest[nlistSc[[1, i]][[ii]], 
        starVectors[[jj]]], {ii, 1, nv}, {jj, 1, nv}], True];
    indlist[[i, 1]] = match[[i]];
    indlist[[i, 2]] = matchlist[[;; , 2]];
    indlist[[i, 3]] = nlistSc[[3, i]];
    matchlist = 
     Position[
      Table[loKvalisortVectorTest[starVectors[[ii]], 
        nlistSc[[1, i]][[jj]]], {ii, 1, nv}, {jj, 1, nv}], True];
    indlist[[i, 4]] = matchlist[[;; , 2]];
    ];
   indlist
   ];


