#!/software/apps/python/3.4.1/snic-1/bin/python3

import scipy
from network import Landscape
from pdb import set_trace

fp_arr = []

with open('fp.dat', 'r') as fpfile:
  for line in fpfile:
    arr = scipy.fromstring(line.strip(),sep=' ')
    fp_arr.append(arr)

pel = Landscape()

fromnode = 0
for i,fp in enumerate(fp_arr):
  fromnode = pel.add_node(i,1.,fp,fromnode)

hist,bins = pel.get_degree_dist()
print(bins)
print(hist)
set_trace()
pass
