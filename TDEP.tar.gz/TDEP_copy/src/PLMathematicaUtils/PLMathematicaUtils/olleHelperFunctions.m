(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loMaxCutoff::usage="loMaxCutoff[poscar_]"
loKvalisortVectorTest::usage=""
loKvalisortCartesianDistance::usage=""
loRotateKvalisortVector::usage=""
loCountUnknown::usage=""
loGenerateStar::usage=""
loDetermineKvalisort::usage=""
loReturnPermutationOfIndices::usage=""
loExtractCluster::usage=""
loClusterShiftKvalisort::usage=""
loClusterMatchKvalisort::usage=""
loClusterRotateKvalisort::usage=""
loApplySymopToTensor::usage=""
loFindClusterIndices::usage=""
loGetAnalyticalBornChargesFromFile::usage=""
loReturnRulesForUnknown::usage=""
loListOfUnknown::usage=""
End[];

loMaxCutoff[poscar_] := Module[{base, corners},
     base = Base[poscar]*LatticeConstant[poscar];
     corners = 
    Join[{{0, 0, 0}}, 
     base, {Total[base[[{1, 2}]]], Total[base[[{2, 3}]]], 
      Total[base[[{3, 1}]]], Total[base]}];
     First@
    Sort[(EuclideanDistance @@ #)/2.0 & /@ Subsets[corners, {2}]]
   ];

loKvalisortVectorTest[v1_, v2_] := Module[{},
   SquaredEuclideanDistance[v1, v2] < 10^-4
   ];

loKvalisortCartesianDistance[v1_, v2_] := Module[{},
   Norm[v1[[1 ;; 3]] - v1[[1 ;; 3]]]
   ];

loRotateKvalisortVector[v_, op_] := Module[{},
   Join[v[[1 ;; 3]].op, {v[[4]]}]
   ];

loCountUnknown[m_] := Module[
   {},
   Length[
    Union[Flatten[
      m[[4]] /. {x_ /; NumberQ[x] -> Sequence[], Plus -> List}]]]
   ];

loListOfUnknown[m_] := Module[
   {},
    Union[Flatten[
      m[[4]] /. {x_ /; NumberQ[x] -> Sequence[], Plus -> List}]]
   ];

loReturnRulesForUnknown[m_,symb_] := 
  Module[{l, i}, 
   l = Union[
     Flatten[m /. {x_ /; NumberQ[x] -> Sequence[], 
        Plus -> List}]];
   Table[l[[i]] -> Symbol[symb <> ToString[i]], {i, 1, 
     Length[l]}]
   ];

loReturnPermutationOfIndices[ind1_, ind2_, n_] := Module[
   {perms, l},
   perms = Permutations[Range[n]];
   l = Flatten[Position[ind1 == ind2[[#]] & /@ perms, True]];
   p = perms[[l]]
   ];

loClusterShiftKvalisort[t_, v_] := Module[{tt},
   tt = # - v & /@ t;
   tt[[;; , 4]] = t[[;; , 4]];
   Chop[tt]
   ];

loClusterMatchKvalisort[t1_, t2_] := Module[{}, SquaredEuclideanDistance[t1, t2] < 10^-4];

loClusterRotateKvalisort[t_, op_] := Module[{}, loRotateKvalisortVector[#, op] & /@ t];

loFindClusterIndices[cl_, cluster_, baseshift_] := 
  Module[{shiftedcluster},
   shiftedcluster = loClusterShiftKvalisort[cl, baseshift];
   Flatten[
    Table[Position[
      SquaredEuclideanDistance[#, shiftedcluster[[i]]] < 10^-4 & /@ 
       cluster[[1]], True], {i, 1, Length[shiftedcluster]}]]
   ];

loApplySymopToTensor[m_, op_, n_] := Module[
   {},
   If[n == 1,
    newm = Table[
       Sum[m[[j1]]*op[[j1, i1]],
        {j1, 1, 3}],
       {i1, 1, 3}];
    ];
   If[n == 2,
    newm = Table[
       Sum[m[[j1, j2]]*op[[j1, i1]]*op[[j2, i2]],
        {j1, 1, 3}, {j2, 1, 3}],
       {i1, 1, 3}, {i2, 1, 3}];
    ];
   If[n == 3,
    newm = Table[
       Sum[m[[j1, j2, j3]]*op[[j1, i1]]*op[[j2, i2]]*op[[j3, i3]],
        {j1, 1, 3}, {j2, 1, 3}, {j3, 1, 3}],
       {i1, 1, 3}, {i2, 1, 3}, {i3, 1, 3}];
    ];
   If[n == 4,
    newm = Table[
       Sum[
        m[[j1, j2, j3, j4]]*op[[j1, i1]]*op[[j2, i2]]*op[[j3, i3]]*op[[j4, i4]],
        {j1, 1, 3}, {j2, 1, 3}, {j3, 1, 3}, {j4, 1, 3}],
       {i1, 1, 3}, {i2, 1, 3}, {i3, 1, 3}, {i4, 1, 3}];
    ];
   newm
   ];

loGenerateStar[unitcell_, cutoff_] := Module[
   {unitcellCutoff, supercellradius, lattice, na, base, pos, indices, 
    vectors, atomicsymbols, k, Rij, a1, a2, star},
   (* generate a lattice *)
   na = Total[NumberOfElements[unitcell]];
           

   unitcellCutoff = loMaxCutoff[unitcell];
   supercellradius = Ceiling[(cutoff/unitcellCutoff - 1)/2] + 2;
   supercellradius = Ceiling[(cutoff/unitcellCutoff - 1)/2] + 2;
   If[na>60,
    supercellradius=1
   ];
   lattice = 
    Sort[Tuples[Range[-supercellradius, supercellradius, 1], {3}], 
     SquaredEuclideanDistance[#1, {0, 0, 0}] < 
       SquaredEuclideanDistance[#2, {0, 0, 0}] &];
   (*shortcuts*)
   base = Base[unitcell]*LatticeConstant[unitcell];
   pos = DirectPositions[unitcell];
   star = ConstantArray[{}, {4, na}];
   For[a1 = 1, a1 <= na, a1++,
    vectors = {};
    indices = {};
    atomicsymbols = {};
    For[a2 = 1, a2 <= na, a2++,
     For[k = 1, k <= Length[lattice], k++,
       Rij = (pos[[a2]] - pos[[a1]] + lattice[[k]]).base;
       If[EuclideanDistance[Rij, {0, 0, 0}] < cutoff,
        AppendTo[vectors, Rij];
        AppendTo[indices, a2];
        AppendTo[atomicsymbols, Elements[unitcell, a2]];
        ];
       ];
     ];
    star[[1, a1]] = indices;
    star[[2, a1]] = vectors;
    star[[3, a1]] = atomicsymbols;
    star[[4, a1]] = Elements[unitcell, a1];
    ];
   starFromUnitcell = star
   ];

loDetermineKvalisort[
   star_[indices_, vectors_, atomicsymbols_, startatom_], uc_] := 
  Module[
   {na, a1, a2, vectorTest, symops, l1, l2, matchingOperations, 
    kvalisort, kvalisortVector,
    nv1, nv2, matchOperationList, matchList},
   na = Length[indices];
   symops = loReturnValidSymmetryOperations[uc];
   (*Test vector and species*)
   vectorTest[v1_, v2_] := 
    Module[{}, 
     SquaredEuclideanDistance[v1[[1 ;; 3]], v2[[1 ;; 3]]] < 10^-4 && 
      v1[[4]] == v2[[4]]];
   (* Build a matching table *)
   
   matchOperationList = ConstantArray[{}, {na, na}];
   matchList = ConstantArray[{}, {na, na}];
   For[a1 = 1, a1 <= na, a1++,
    For[a2 = 1, a2 <= na, a2++,
      
      nv1 = Length[indices[[a1]]];
      nv2 = Length[indices[[a2]]];
      
      If[nv1 == nv2 && startatom[[a1]] == startatom[[a2]],
       
       matchingOperations = Table[
         l1 = 
          Table[Flatten[{vectors[[a1, i]], 
             atomicsymbols[[a1, i]]}], {i, 1, nv1}];
         l2 = 
          Table[Flatten[{vectors[[a2, i]].symops[[j]], 
             atomicsymbols[[a2, i]]}], {i, 1, nv2}];
         Length[
          Union[l1, l2, 
           SameTest -> (vectorTest[#1, #2] == True &)]], {j, 1, 
          Length[symops]}
         ];
       matchingOperations = Flatten[Position[matchingOperations, nv1]];
       matchOperationList[[a1, a2]] = matchingOperations;
       matchList[[a1, a2]] = Length[matchingOperations];
       ];
      
      ];
    ];
   
   (* List of differet kind of species *)
   
   kvalisort = Table[Symbol[StringJoin["s", ToString[i]]], {i, 1, na}];
   (* Figure out the equivalent ones *)
   
   For[a1 = 1, a1 <= na, a1++,
    For[a2 = a1, a2 <= na, a2++,
      If[matchList[[a1, a2]] > 0,
        kvalisort = 
          kvalisort /. {kvalisort[[a2]] -> kvalisort[[a1]]};
        ];
      ];
    ];
   (* Replace them with numbers *)
   
   rls = Table[
     Union[kvalisort][[i]] -> i, {i, 1, Length[Union[kvalisort]]}];
   kvalisort = kvalisort /. rls;
   
   kvalisortVector = ConstantArray[{}, {na}];
   For[a1 = 1, a1 <= na, a1++,
    kvalisortVector[[a1]] = 
      Table[Flatten[{vectors[[a1, i]], 
         kvalisort[[indices[[a1, i]]]]}], {i, 1, 
        Length[indices[[a1]]]}];
    ];
   
   (*I tur och ordning:index i poscar,vector till atom,
   symbol den pekar på,atomsymbol jag startar från,
   kvalisort vektorn pekar på,kvalisort jag startar från.*)
   
   newstar = ConstantArray[{}, {8, na}];
   newstar[[1]] = indices;
   newstar[[2]] = Chop[vectors];
   newstar[[3]] = atomicsymbols;
   newstar[[4]] = startatom;
   newstar[[5]] = kvalisort[[#]] & /@ indices;
   newstar[[6]] = kvalisort;
   newstar[[7]] = Chop[kvalisortVector];
   newstar[[8]] = matchOperationList;
   newstar
   ];

loExtractCluster[uc_, star_] := Module[
   {na, bas, pos, a1, c2, cluster, indexFromClusterToFc, 
    positionInCluster, p0, posKv},
   na = Total[NumberOfElements[uc]];
   bas = Base[uc]*LatticeConstant[uc];
   p0 = DirectPositions[uc].bas;
   pos = Chop[Table[Flatten[{p0[[a1]], 0}], {a1, 1, na}]];
   posKv = 
    Chop[Table[Flatten[{p0[[a1]], star[[6, a1]]}], {a1, 1, na}]];
   
   cluster = Chop[Union[Flatten[Table[
        pos[[a1]] + # & /@ star[[7, a1]]
        , {a1, 1, na}], 1], SameTest -> loKvalisortVectorTest]];
   (* Where in the cluster are my unitcell atoms? *)

    positionInCluster = 
    Flatten[Table[
   Position[loKvalisortVectorTest[posKv[[a1]], #] & /@ cluster, 
    True], {a1, 1, Length[posKv]}]];
   
   (* And where are the rest of the vectors? *)
   
   indexFromClusterToFc = Table[
     c2 = Chop[# - pos[[a1]]] & /@ cluster;
     Flatten[Table[Position[
        loKvalisortVectorTest[#, star[[7, a1]][[i]]] & /@ c2, True]
       , {i, 1, Length[star[[7, a1]]]}]], {a1, 1, na}];
   
   cl = ConstantArray[{}, 3];
   cl[[1]] = cluster;
   cl[[2]] = indexFromClusterToFc;
   cl[[3]] = positionInCluster;
   cl
   ];

loGetAnalyticalBornChargesFromFile[uc_] := Module[
   {na, uv, rls, i},
   (* load infile.lotosplitting, do some fiddling and get it as *)
   (* symbolic tensors for symmetry analysis. *)
   
   na = Total[NumberOfElements[uc]];
   l = ReadList["infile.lotosplitting", Number];
   l = ArrayReshape[l, {na + 1, 3, 3}];
   l = l[[2 ;; na + 1, ;; , ;;]];
   l = Round[Chop[l], 10^-2];
   uv = DeleteCases[Union[Flatten[l]], 0];
   rls = Table[
     uv[[i]] -> Symbol["zz" <> ToString[i]], {i, 1, Length[uv]}];
   l /. rls
   ];
