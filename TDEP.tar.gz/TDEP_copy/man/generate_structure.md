
### Short description

Builds supercells, diagonal and non-diagonal. Also has the capability to find the optimal supercells for a given lattice, very handy when you have complicated structures.

### Command line options:




Optional switches:

* `--dimensions value#1 value#2 value#3`, `-d value#1 value#2 value#3`  
    default value 5 5 5  
    Dimensions of supercell.

* `--nondiagonal_dimensions value#1 value#2 value#3 value#4 value#5 value#6 value#7 value#8 value#9`, `-nd value#1 value#2 value#3 value#4 value#5 value#6 value#7 value#8 value#9`  
    default value 0 0 0 0 0 0 0 0 0  
    Non-diagonal dimensions of supercell.

* `--output_format value`, `-of value`, value in: `1,2,3,4,5`  
    default value 1  
    Output format. 1 is VASP, 2 Abinit, 3 LAMMPS, 4 xyz-files for i-pi, 5 FHI-Aims

* `--magnetic_bins value`, `-mb value`  
    default value 5  
    Number of bins in correlation functions, from order to disorder.

* `--magnetic_configurations value`, `-mc value`  
    default value 10  
    Number of magnetic configurations per bin

* `--desired_na value`, `-na value`  
    default value -1  
    Desired number of atoms in supercell. Will try to choose a cell as cubic as possible.

* `--help`, `-h`  
    Print this help message

* `--version`, `-v`  
    Print version
### Examples

`generate_structure -dim 4 3 5` 
