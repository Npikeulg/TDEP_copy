title: Using the library
author: Olle Hellman

This documentation also details the library. It's easy to write codes. A minimal code that calculates the phonon dispersions on a mesh in the BZ looks something like this:

```fortran
program minimal_example
use constants
use type_crystalstructure
use type_lotosplitting
use type_qpointmesh
use type_phonon_dispersions
use type_forceconstant_secondorder

implicit none
type(lo_crystalstructure) :: uc
class(lo_qpoint_mesh), allocatable :: qp
type(lo_phonon_dispersions) :: dr
type(lo_forceconstant_secondorder) :: fc
type(lo_loto) :: loto

! read the unitcell
call uc%readfromfile('infile.ucposcar')
! read the forceconstant
call fc%readfromfile(uc,'infile.forceconstant')
! skip lo-to splitting for now, get an empty one
call loto%initempty()
! generate a q-point mesh
call lo_generate_qmesh(qp,uc,[24,24,24],'monkhorst')
! phonon dispersions on this mesh
call dr%generate(qp,fc,uc,loto)
! get the phonon free energy at 300K
write(*,*) 'phonon free energy at 300K:',dr%phonon_free_energy(300.0_flyt)

end program

```

