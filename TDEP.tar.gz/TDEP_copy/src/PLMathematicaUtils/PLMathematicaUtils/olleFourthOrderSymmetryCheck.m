(* ::Package:: *)

(* Mathematica package *)

Begin["PLMathematicaUtils`"];
loTriangleRotate::usage=""
loTetrahedronRotate::usage=""
loTetrahedronPermutationsThatMakesThemMatch::usage=""
loTetrahedronMatchKvalisort::usage=""
loTetrahedronShiftKvalisort::usage=""
loApplySymopToFourthOrderFc::usage=""
loFourthOrderAcousticSumRule::usage=""
loFourthOrderTransposeSymmetry::usage=""
loFourthOrderTranslationalSymmetry::usage=""
loFourthOrderPointGroupSymmetry::usage=""
End[];

loTetrahedronRotate[t_, op_] := Module[{},
   loRotateKvalisortVector[#, op] & /@ t
   ];

loTetrahedronPermutationsThatMakesThemMatch[t1_, t2_] := Module[
   {perms, i},
   perms = Permutations[{1, 2, 3, 4}];
   i = Flatten[
     Position[
      SquaredEuclideanDistance[t1, t2[[#]]] < 10^-4 & /@ perms, True]];
   perms[[i]]
   ];

loTetrahedronMatchKvalisort[t1_, t2_] := Module[
   {},
   SquaredEuclideanDistance[t1, t2] < 10^-4
   ];

loTetrahedronShiftKvalisort[t_, v_] := Module[
   {tt},
   tt = # - v & /@ t;
   tt[[;; , 4]] = t[[;; , 4]];
   tt
   ];

loApplySymopToFourthOrderFc[m_, op_] := Module[
   {},
   Table[Sum[m[[j1, j2, j3, j4]]*
      op[[j1, i1]]*op[[j2, i2]]*op[[j3, i3]]*op[[j4, i4]],
     {j1, 1, 3}, {j2, 1, 3}, {j3, 1, 3}, {j4, 1, 3}],
    {i1, 1, 3}, {i2, 1, 3}, {i3, 1, 3}, {i4, 1, 3}]
   ];

loFourthOrderAcousticSumRule[tet_, star_] := Module[
   {na, ntet, a1, i, j, tetrahedrons, tetrahedronIndices, 
    tetrahedronsKvalisort, forceconstants, solutions, vectors, nv, 
    vec, relevanttetrahedrons, fcsum, fc},
   na = Dimensions[tet][[2]];
   newtet = ConstantArray[{}, {4, na}];
   
   fc = tet[[4]];
   
   For[a1 = 1, a1 <= na, a1++,
    tetrahedrons = tet[[1, a1]];
    tetrahedronIndices = tet[[2, a1]];
    tetrahedronsKvalisort = tet[[3, a1]];
    forceconstants = tet[[4, a1]];
    vectors = star[[2, a1]];
    ntet = Length[tetrahedrons];
    nv = Length[vectors];
    (**)
    
    For[j = 1, j <= 3, j++,
     For[vec = 1, vec <= nv, vec++,
       fcsum = ConstantArray[0, {3, 3, 3, 3}];
       relevanttetrahedrons = 
        Flatten[Position[tetrahedronIndices[[;; , j]], vec]];
       For[i = 1, i <= Length[relevanttetrahedrons], i++,
        fcsum = fcsum + fc[[a1]][[ relevanttetrahedrons[[i]] ]];
        ];
       
       fcsum = Union[Flatten[fcsum]];
       solutions = 
        Flatten[Solve[fcsum == Table[0, {i, 1, Length[fcsum]}]]];
       fc = fc /. solutions;
       ];
     ];
    
    newtet[[1, a1]] = tetrahedrons;
    newtet[[2, a1]] = tetrahedronIndices;
    newtet[[3, a1]] = tetrahedronsKvalisort;
    newtet[[4, a1]] = fc[[a1]];
    ];
   newtet
   ];

loFourthOrderTransposeSymmetry[tet_] := Module[
   {na, ntet, a1, t1, t2, tetrahedrons, tetrahedronIndices, 
    tetrahedronsKvalisort, s, p, shiftTet, shifts, m1, m2, equations, 
    solutions, perm, fc},
   na = Dimensions[tet][[2]];
   newtet = ConstantArray[{}, {4, na}];
   
   fc = tet[[4]];
   For[a1 = 1, a1 <= na, a1++,
    tetrahedrons = tet[[1, a1]];
    tetrahedronIndices = tet[[2, a1]];
    tetrahedronsKvalisort = tet[[3, a1]];
    ntet = Length[tetrahedrons];
    (* Test all tetrahedrons vs all others *)
    
    For[t1 = 1, t1 <= ntet, t1++,
     For[t2 = t1, t2 <= ntet, t2++,
      (* Here I should add a volume check, 
      or some other clever check *)
      
      (* Shift the tetrahedron a bit, 
      no point to shift it with the same vector more than once. *)
   
      shifts = 
       Union[tetrahedronsKvalisort[[t2]], 
        SameTest -> loKvalisortVectorTest];
      
      For[s = 1, s <= Length[shifts], s++,
       shiftTet = 
        loTetrahedronShiftKvalisort[tetrahedronsKvalisort[[t2]], 
         shifts[[s]]];
       perm = 
        loTetrahedronPermutationsThatMakesThemMatch[
         tetrahedronsKvalisort[[t1]], shiftTet];
       (* Now I have the matching permutations *)
       
       For[p = 1, p <= Length[perm], p++,
        m1 = fc[[a1]][[t1]];
        m2 = TensorTranspose[fc[[a1]][[t2]], perm[[p]]];
        solutions = Flatten[Solve[m1 == m2]];
        fc = fc /. solutions;
        ];
       ];
      ];
     (* end t1 t2 loops*)
     ];
    
    newtet[[1, a1]] = tetrahedrons;
    newtet[[2, a1]] = tetrahedronIndices;
    newtet[[3, a1]] = tetrahedronsKvalisort;
    newtet[[4, a1]] = fc[[a1]];
    ];
   newtet
   ];

loFourthOrderTranslationalSymmetry[tet_, star_, uc_] := Module[
   {na, symops, tetrahedrons1, tetrahedrons2, tetrahedronIndices1, 
    tetrahedronIndices2, tetrahedronsKvalisort1, 
    tetrahedronsKvalisort2, forceconstants1, forceconstants2, ntet, 
    vectorsKvalisort1, vectorsKvalisort2, a1, a2, op, rotTetra, 
    matchtable, m1, m2, equations, matchingOperations, p, solutions,fc},
   
   na = Dimensions[tet][[2]];
   newtet = ConstantArray[{}, {4, na}];
   symops = loReturnValidSymmetryOperations[uc];
   fc=tet[[4]];
   
   For[a1 = 1, a1 <= na, a1++,
    tetrahedrons1 = tet[[1, a1]];
    tetrahedronIndices1 = tet[[2, a1]];
    tetrahedronsKvalisort1 = tet[[3, a1]];
    forceconstants1 = tet[[4, a1]];
    vectorsKvalisort1 = star[[7, a1]];
    
    For[a2 = a1+1, a2 <= na, a2++, If[star[[6, a1]] == star[[6, a2]],
       
       tetrahedrons2 = tet[[1, a2]];
       tetrahedronIndices2 = tet[[2, a2]];
       tetrahedronsKvalisort2 = tet[[3, a2]];
       forceconstants2 = tet[[4, a2]];
       vectorsKvalisort2 = star[[7, a2]];
       ntet = Length[tetrahedrons2];
       (* 
       Returns the symmetry operations that turns star 2 into star 1 *)

              matchingOperations = symops[[Flatten[
           Position[
            Table[
             Length[Union[
                Join[vectorsKvalisort1, 
                 loRotateKvalisortVector[#, symops[[i]]] & /@ 
                  vectorsKvalisort2], 
                SameTest -> loKvalisortVectorTest]] == 
              Length[vectorsKvalisort2]
             , {i, 1, Length[symops]}], True]]]];
       
       For[p = 1, p <= Min[48, Length[matchingOperations]], p++,
        op = matchingOperations[[p]];
        (* Rotate the tetrahedrons *)
        
        rotTetra = 
         loTetrahedronRotate[#, op] & /@ tetrahedronsKvalisort2;
        (* List that matches tetrahedrons *)
        
        matchtable = 
         Position[
          Table[loTetrahedronMatchKvalisort[ 
            tetrahedronsKvalisort1[[i]], rotTetra[[j]] ], {i, 1, 
            ntet}, {j, 1, ntet}], True];
        
        (* apply the equations *)
        For[i = 1, i <= ntet, i++,
          m1=fc[[a1]][[ matchtable[[i, 1]] ]];
          m2=fc[[a2]][[ matchtable[[i, 2]] ]];
          m2=loApplySymopToFourthOrderFc[m2,op];
         (*m1 = forceconstants1[[ matchtable[[i, 1]] ]];
         m2 = 
          loApplySymopToFourthOrderFc[
           forceconstants2[[ matchtable[[i, 2]] ]], op];*)
         
         solutions = Flatten[Solve[m1 == m2]];
         If[Length[solutions] > 0,
          fc = fc /. solutions;
          ];
         ];
        ];
       
       ];];
    newtet[[1, a1]] = tetrahedrons1;
    newtet[[2, a1]] = tetrahedronIndices1;
    newtet[[3, a1]] = tetrahedronsKvalisort1;
    newtet[[4, a1]] = fc[[a1]]; 
    ];
   newtet
   ];

loFourthOrderPointGroupSymmetry[tet_, symops_, star_] := Module[
   {na, ntet, a1, i, t1, t2, tetrahedrons, tetrahedronIndices, 
    tetrahedronsKvalisort, forceconstants, s, m1, m2, equations, 
    solutions, perm, symrot, op, uk, rotTetra, matchtable},
   na = Dimensions[tet][[2]];
   newtet = ConstantArray[{}, {4, na}];
   symrot = Union[symops[[;; , 1]]];
   
    For[a1 = 1, a1 <= na, a1++,
      tetrahedrons = tet[[1, a1]];
      tetrahedronIndices = tet[[2, a1]];
      tetrahedronsKvalisort = tet[[3, a1]];
      forceconstants = tet[[4, a1]];
      ntet = Length[tetrahedrons];
      
      For[s = 1, s <= Min[48, Length[symrot]], s++,
       op = symrot[[s]];
       rotTetra = 
        loTetrahedronRotate[#, op] & /@ tetrahedronsKvalisort;
       matchtable = 
        Position[
         Table[loTetrahedronMatchKvalisort[ 
           tetrahedronsKvalisort[[i]], rotTetra[[j]] ], {i, 1, 
           ntet}, {j, 1, ntet}], True];
       
       For[i = 1, i <= Length[matchtable], i++,
        m1 = forceconstants[[ matchtable[[i, 1]] ]];
        m2 = 
         loApplySymopToFourthOrderFc[
          forceconstants[[ matchtable[[i, 2]] ]], op];
        
        solutions = Flatten[Solve[m2 == m1]];
        If[Length[solutions] > 0,
         forceconstants = forceconstants /. solutions;
         ];
        ];
       ];
      
      newtet[[1, a1]] = tetrahedrons;
      newtet[[2, a1]] = tetrahedronIndices;
      newtet[[3, a1]] = tetrahedronsKvalisort;
      newtet[[4, a1]] = forceconstants;
      ];
   newtet
   ];
